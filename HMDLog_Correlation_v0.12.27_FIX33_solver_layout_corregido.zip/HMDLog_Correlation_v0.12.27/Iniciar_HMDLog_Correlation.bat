@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo No se encontro el entorno virtual.
    echo Ejecute primero: .\Instalar.ps1
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -c "import matplotlib, PySide6, numpy, pandas, lasio, openpyxl, pyproj" >nul 2>&1
if errorlevel 1 (
    echo La instalacion esta incompleta o danada.
    echo Ejecute nuevamente desde PowerShell: .\Instalar.ps1
    pause
    exit /b 1
)
".venv\Scripts\python.exe" app.py
if errorlevel 1 pause
