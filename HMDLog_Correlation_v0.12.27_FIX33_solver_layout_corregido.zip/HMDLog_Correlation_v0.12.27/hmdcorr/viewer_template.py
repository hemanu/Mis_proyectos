import json
from copy import deepcopy
from pathlib import Path


DEFAULT_TEMPLATE = {
    "schema": "hmdlog.viewer-template",
    "version": 1,
    "tracks": [{"key": "TRACK_001", "name": "Track 1", "width": 1.0,
                "min_width": 150, "background": "#FFFFFF",
                "border_visible": True, "border_color": "#9CA3AF", "border_width": 0.7,
                "grid_enabled": True, "grid_color": "#B8C0CC", "grid_width": 0.5,
                "grid_alpha": 0.5, "grid_minor_color": "#D8DEE8",
                "grid_minor_width": 0.3, "grid_minor_alpha": 0.25,
                "grid_same_color": False, "horizontal_grid_enabled": True,
                "horizontal_grid_interval": 0.0, "horizontal_grid_subdivisions": 0,
                "horizontal_grid_style": "solid", "vertical_grid_enabled": True,
                "vertical_grid_divisions": 5, "vertical_grid_subdivisions": 0,
                "vertical_grid_style": "solid", "vertical_grid_reference": "",
                "vertical_grid_scale_mode": "auto", "vertical_grid_log_detail": "2_5",
                "vertical_grid_show_labels": True, "depth_scale": "first", "separation": 3,
                "header_height": 64, "header_background": "#FFFFFF", "header_font_size": 9}],
    "curves": [{"source": "GR", "track_key": "TRACK_001", "presentation": "normal",
                "xlim": [0.0, 150.0], "scale": "linear", "color": "#007f00",
                "linestyle": "-", "linewidth": 1.2, "fill_enabled": False,
                "fill_to": "xmin", "fill_alpha": 0.25, "auto_range": False}],
    "viewer": {"gray_background": False, "major_grid": True, "minor_grid": True,
               "grid_tone": 60, "technical_headers": True},
}


def load_template(path):
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if payload.get("schema") != "hmdlog.viewer-template" or int(payload.get("version", -1)) != 1:
        raise ValueError("El archivo no es una plantilla HMDLog compatible.")
    if not payload.get("tracks"):
        raise ValueError("La plantilla no contiene tracks.")
    keys = {str(item["key"]) for item in payload["tracks"]}
    for curve in payload.get("curves", []):
        if curve.get("track_key") not in keys:
            raise ValueError("La plantilla contiene una curva asignada a un track inexistente.")
        xmin, xmax = map(float, curve.get("xlim", (0, 1)))
        if xmax <= xmin:
            raise ValueError(f"Escala inválida para {curve.get('source')}.")
    return deepcopy(payload)


def save_template(path, payload):
    Path(path).write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def curve_settings(template, source, track_key=None):
    source = str(source).upper()
    return next((deepcopy(c) for c in template.get("curves", [])
                 if str(c.get("source", "")).upper() == source
                 and (track_key is None or str(c.get("track_key")) == str(track_key))), None)


def default_curve_settings(source, track_key):
    """Presentation defaults used when any LAS curve is assigned to any track."""
    source = str(source).upper()
    presets = {
        "GR": ([0.0, 150.0], "linear", "#007f00"),
        "SP": ([-160.0, 40.0], "linear", "#1d4ed8"),
        "RHOB": ([1.95, 2.95], "linear", "#dc2626"),
        "NPHI": ([-0.15, 0.45], "linear", "#2563eb"),
        "DT": ([40.0, 140.0], "linear", "#111827"),
        "CALI": ([6.0, 16.0], "linear", "#7c3aed"),
    }
    resistive = source in {"ILD", "ILM", "IL", "SFL", "SFLU", "LLD", "LLS", "MSFL", "RT", "CILD"} or source.startswith("AT")
    xlim, scale, color = ([0.2, 2000.0], "log", "#b45309") if resistive else presets.get(source, ([0.0, 1.0], "linear", "#374151"))
    return {"source": source, "track_key": str(track_key), "presentation": "normal",
            "xlim": list(xlim), "scale": scale, "color": color, "linestyle": "-",
            "linewidth": 1.0, "fill_enabled": False, "fill_to": "xmin",
            "fill_alpha": 0.25, "auto_range": source not in presets and not resistive}
