"""Repositorio local persistente de archivos LAS, indexado por UWI."""
from __future__ import annotations

import hashlib
import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path


class WellRepository:
    def __init__(self, root: str | Path):
        self.root=Path(root);self.files_dir=self.root/"las";self.index_path=self.root/"index.json"
        self.files_dir.mkdir(parents=True,exist_ok=True)

    def _read(self) -> dict:
        if not self.index_path.exists():return {"schema":"hmdlog.well-repository","version":1,"wells":{}}
        try:return json.loads(self.index_path.read_text(encoding="utf-8"))
        except (OSError,json.JSONDecodeError):return {"schema":"hmdlog.well-repository","version":1,"wells":{}}

    def _write(self,payload: dict):
        temporary=self.index_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(payload,indent=2,ensure_ascii=False),encoding="utf-8")
        temporary.replace(self.index_path)

    def register(self, source_path: str | Path, well) -> dict:
        source=Path(source_path);uwi=str(well.uwi or well.name).strip()
        if not uwi:raise ValueError("El pozo no contiene UWI ni nombre.")
        slug=re.sub(r"[^A-Za-z0-9_.-]+","_",uwi).strip("_")[:60] or "POZO"
        tag=hashlib.sha1(uwi.encode("utf-8")).hexdigest()[:10]
        destination=self.files_dir/f"{slug}_{tag}.las"
        shutil.copy2(source,destination)
        payload=self._read();entries=payload.setdefault("wells",{})
        entries[uwi]={"uwi":uwi,"name":str(well.name),"las_path":str(destination),
                      "source_name":source.name,"x":well.x,"y":well.y,
                      "updated_utc":datetime.now(timezone.utc).isoformat()}
        self._write(payload);return dict(entries[uwi])

    def entries(self) -> list[dict]:
        return sorted((dict(value) for value in self._read().get("wells",{}).values()),key=lambda item:(item.get("name","").casefold(),item.get("uwi","")))

    def load_well(self, uwi: str):
        from .importers import load_las
        entry=self._read().get("wells",{}).get(str(uwi))
        if not entry:raise KeyError(f"El UWI {uwi} no existe en el repositorio.")
        path=Path(entry["las_path"])
        if not path.exists():raise FileNotFoundError(f"No se encontró la copia LAS de {uwi}.")
        return load_las(path)

    def delete(self,uwi: str):
        payload=self._read();entry=payload.get("wells",{}).pop(str(uwi),None)
        if entry:
            path=Path(entry.get("las_path",""))
            if path.is_file():path.unlink()
            self._write(payload)
