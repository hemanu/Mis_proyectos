"""Diálogo único para propiedades, CRS y referencias del proyecto."""
from __future__ import annotations

from PySide6.QtWidgets import (QCheckBox,QComboBox,QDialog,QDialogButtonBox,QFormLayout,QLabel,QLineEdit,
    QMessageBox,QTabWidget,QTextEdit,QVBoxLayout,QWidget)

from .spatial_reference import DEFAULT_PROJECT_METADATA,DEFAULT_SPATIAL_REFERENCE,describe_crs,refresh_project_coordinate_cache


class ProjectPropertiesDialog(QDialog):
    def __init__(self,project,parent=None):
        super().__init__(parent);self.project=project;self.setWindowTitle("Propiedades del proyecto");self.resize(560,520)
        root=QVBoxLayout(self);tabs=QTabWidget();root.addWidget(tabs)
        metadata=dict(DEFAULT_PROJECT_METADATA);metadata.update(project.project_metadata or {})
        reference=dict(DEFAULT_SPATIAL_REFERENCE);reference.update(project.spatial_reference or {})

        identity=QWidget();form=QFormLayout(identity);self.name=QLineEdit(project.name);self.area=QLineEdit(metadata["area"]);self.field=QLineEdit(metadata["field"])
        self.operator=QLineEdit(metadata["operator"]);self.author=QLineEdit(metadata["author"]);self.description=QTextEdit(metadata["description"])
        for label,widget in (("Nombre del proyecto",self.name),("Área o cuenca",self.area),("Campo",self.field),("Operador",self.operator),("Autor",self.author),("Descripción",self.description)):form.addRow(label,widget)
        tabs.addTab(identity,"Identificación")

        horizontal=QWidget();form=QFormLayout(horizontal);self.crs=QLineEdit(reference["horizontal_crs"]);self.crs_description=QLabel();self.crs_description.setWordWrap(True)
        self.transform=QCheckBox("Transformar automáticamente las coordenadas válidas");self.transform.setChecked(bool(reference["transform_coordinates"]))
        self.show_original=QCheckBox("Mostrar también los valores originales importados");self.show_original.setChecked(bool(reference["show_original_coordinates"]))
        form.addRow("CRS horizontal principal",self.crs);form.addRow("Sistema identificado",self.crs_description);form.addRow(self.transform);form.addRow(self.show_original)
        tabs.addTab(horizontal,"Sistema de coordenadas")

        vertical=QWidget();form=QFormLayout(vertical);self.vertical_reference=QComboBox();self.vertical_reference.addItems(["MSL","KB","DF","GL","Otro"])
        current=self.vertical_reference.findText(str(reference["vertical_reference"]));self.vertical_reference.setCurrentIndex(max(0,current))
        self.vertical_units=QComboBox();self.vertical_units.addItems(["ft","m"]);self.vertical_units.setCurrentText(str(reference["vertical_units"]))
        self.elevation=QLineEdit("" if reference["default_elevation"] is None else str(reference["default_elevation"]))
        form.addRow("Referencia vertical",self.vertical_reference);form.addRow("Unidad vertical",self.vertical_units);form.addRow("Elevación predeterminada",self.elevation)
        tabs.addTab(vertical,"Referencia vertical")

        section=QWidget();form=QFormLayout(section);self.spacing=QComboBox();self.spacing.addItem("Proporcional","proportional");self.spacing.addItem("Uniforme","uniform")
        self.spacing.setCurrentIndex(max(0,self.spacing.findData(project.spacing_mode)));form.addRow("Separación inicial",self.spacing)
        tabs.addTab(section,"Sección")
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.button(QDialogButtonBox.Save).setText("Guardar propiedades");buttons.button(QDialogButtonBox.Cancel).setText("Cancelar")
        buttons.accepted.connect(self._save);buttons.rejected.connect(self.reject);root.addWidget(buttons);self.crs.textChanged.connect(self._describe);self._describe()

    def _describe(self):
        try:
            info=describe_crs(self.crs.text());self.crs_description.setText(f'{info["name"]} · {info["type"]} · {info["units"]}')
        except ValueError as exc:self.crs_description.setText(str(exc))

    def _save(self):
        if not self.name.text().strip():QMessageBox.warning(self,"Nombre requerido","Introduzca el nombre del proyecto.");return
        try:info=describe_crs(self.crs.text())
        except ValueError as exc:QMessageBox.warning(self,"CRS no válido",str(exc));return
        try:elevation=float(self.elevation.text()) if self.elevation.text().strip() else None
        except ValueError:QMessageBox.warning(self,"Elevación no válida","Introduzca un número o deje el campo vacío.");return
        self.project.name=self.name.text().strip();self.project.project_metadata={"area":self.area.text().strip(),"field":self.field.text().strip(),
            "operator":self.operator.text().strip(),"author":self.author.text().strip(),"description":self.description.toPlainText().strip()}
        self.project.spatial_reference={"horizontal_crs":info["code"],"horizontal_name":info["name"],"horizontal_type":info["type"],
            "coordinate_units":info["units"],"transform_coordinates":self.transform.isChecked(),"show_original_coordinates":self.show_original.isChecked(),
            "vertical_reference":self.vertical_reference.currentText(),"vertical_units":self.vertical_units.currentText(),"default_elevation":elevation}
        self.project.spacing_mode=str(self.spacing.currentData());refresh_project_coordinate_cache(self.project);self.accept()
