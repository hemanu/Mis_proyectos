from __future__ import annotations
import math
import numpy as np
from matplotlib.patches import FancyArrowPatch
from matplotlib.lines import Line2D
from matplotlib.ticker import AutoMinorLocator,MultipleLocator
from matplotlib.transforms import blended_transform_factory, Bbox
from .models import CorrelationProject, Well
from .coordinates import is_valid_geographic,haversine_meters

TOP_COLORS=["#B91C1C","#D97706","#2563EB","#15803D","#7E22CE"]
FORMATION_COLORS=["#E8F1F8","#FFF4D6","#EDF7ED","#F4ECF7"]

def _distance(a:Well,b:Well):
    if is_valid_geographic(a.coordinate_data) and is_valid_geographic(b.coordinate_data):
        d=haversine_meters(a.coordinate_data,b.coordinate_data);return f"{d/1000:.2f} km" if d>=1000 else f"{d:.0f} m"
    if a.coordinate_data or b.coordinate_data:return "Distancia"
    if None in (a.x,a.y,b.x,b.y): return "Distancia"
    d=math.hypot(b.x-a.x,b.y-a.y); return f"{d/1000:.2f} km" if d>=1000 else f"{d:.0f} m"
def _distance_value(a:Well,b:Well):
    if is_valid_geographic(a.coordinate_data) and is_valid_geographic(b.coordinate_data):return haversine_meters(a.coordinate_data,b.coordinate_data)
    if a.coordinate_data or b.coordinate_data:return None
    if None in (a.x,a.y,b.x,b.y): return None
    return math.hypot(b.x-a.x,b.y-a.y)
def _depth(w,datum): return w.depth-(w.tops.get(datum,0.0) if datum else 0.0)
def _top(w,name,datum):
    return None if name not in w.tops else w.tops[name]-(w.tops.get(datum,0.0) if datum else 0.0)
def _figure_point(figure,axis,x,y):
    # X is an axes fraction (0=left edge, 1=right edge), while Y remains in
    # geological depth coordinates. This is independent of linear/log curve scales.
    transform=blended_transform_factory(axis.transAxes,axis.transData)
    return figure.transFigure.inverted().transform(transform.transform((x,y)))

def update_correlation_artists(figure):
    """Keep geological correlation overlays attached after interactive zoom/pan."""
    for artist,definition in getattr(figure,"_hmd_correlation_definitions",[]):
        points=[_figure_point(figure,axis,x_fraction,depth) for axis,x_fraction,depth in definition]
        artist.set_data([point[0] for point in points],[point[1] for point in points])

def apply_area_viewport(figure,x0,x1,y0,y1):
    """Magnify the complete figure-space rectangle, including multiple wells."""
    width=x1-x0;height=y1-y0
    if width<=0 or height<=0:return
    map_x=lambda value:(value-x0)/width
    map_y=lambda value:(value-y0)/height
    for axis in figure.axes:
        position=axis.get_position()
        axis.set_position(Bbox.from_extents(map_x(position.x0),map_y(position.y0),map_x(position.x1),map_y(position.y1)))
    for text in figure.texts:
        tx,ty=text.get_position();text.set_position((map_x(tx),map_y(ty)))
    for arrow in getattr(figure,"_hmd_free_arrows",[]):
        try:
            start,end=arrow._posA_posB;arrow.set_positions((map_x(start[0]),map_y(start[1])),(map_x(end[0]),map_y(end[1])))
        except (AttributeError,TypeError,IndexError):pass
    update_correlation_artists(figure)

def _plot_curve(base,well,depth,s,index):
    source=str(s["source"]).upper()
    if source not in well.curves:return None
    values=np.asarray(well.curves[source],float); scale=str(s.get("scale","linear"))
    if scale=="log": values=np.where(values>0,values,np.nan)
    ax=base if index==0 else base.twiny()
    if index: ax.patch.set_visible(False)
    xmin,xmax=map(float,s.get("xlim",(0,1)))
    if s.get("auto_range",False):
        valid=values[np.isfinite(values)]; valid=valid[valid>0] if scale=="log" else valid
        if valid.size:
            xmin,xmax=map(float,np.nanpercentile(valid,[1,99]));
            if xmax<=xmin:xmax=xmin*10 if scale=="log" else xmin+1
    ax.set_xscale(scale); inverted=s.get("presentation")=="axis_inverted"
    ax.set_xlim((xmax,xmin) if inverted else (xmin,xmax)); color=s.get("color","#1f77b4")
    ax.plot(values,depth,color=color,linestyle=s.get("linestyle","-"),linewidth=float(s.get("linewidth",1)),zorder=5)
    if s.get("fill_enabled",False):
        anchor=xmin if s.get("fill_to","xmin")=="xmin" else xmax
        ax.fill_betweenx(depth,anchor,values,where=np.isfinite(values),color=color,alpha=float(s.get("fill_alpha",.25)),linewidth=0)
    ax.tick_params(axis="x",which="both",top=False,bottom=False,labeltop=False,labelbottom=False)
    ax.spines[["top","bottom"]].set_visible(False)
    return ax

def _apply_track_discretization(ax,well,depth,settings,config):
    """Fill the geometric left/right areas between a curve and its reference."""
    source=str(config.get("source","")).upper()
    if not config.get("enabled",True) or source not in well.curves:return
    values=np.asarray(well.curves[source],float);reference=float(config.get("reference",0.0));scale=str(settings.get("scale","linear"))
    valid=np.isfinite(values)
    if scale=="log":valid&=(values>0)&(reference>0)
    inverted=settings.get("presentation")=="axis_inverted"
    left=valid&(values>=reference if inverted else values<=reference);right=valid&~left
    alpha=float(config.get("alpha",.38))
    for mask,key in ((left,"left"),(right,"right")):
        style=config.get(key,{})
        fill=ax.fill_betweenx(depth,reference,values,where=mask,interpolate=True,
                              facecolor=style.get("color","#D1D5DB"),edgecolor=style.get("color","#6B7280"),
                              hatch=style.get("pattern","") or None,alpha=alpha,linewidth=.25,zorder=2,
                              rasterized=True,antialiased=False)
        fill.set_gid("hmd-discretization-fill")
        if not hasattr(ax.figure,"_hmd_discretization_artists"):ax.figure._hmd_discretization_artists=[]
        ax.figure._hmd_discretization_artists.append(fill)
    ax.axvline(reference,color=config.get("line_color","#111827"),lw=float(config.get("line_width",1.0)),
               ls=config.get("line_style","--"),zorder=4)

def _header(ax,rows,properties=None):
    properties=properties or {}
    ax.set_xlim(0,1);ax.set_ylim(0,1);ax.set_xticks([]);ax.set_yticks([])
    ax.set_facecolor(properties.get("header_background","#FFFFFF"));font_size=float(properties.get("header_font_size",9))
    for sp in ax.spines.values():sp.set_visible(bool(properties.get("border_visible",True)));sp.set_color(properties.get("border_color","#6B7280"));sp.set_linewidth(float(properties.get("border_width",.7)))
    ax.text(.5,.94,str(properties.get("name","Track")),ha="center",va="top",fontsize=max(5,font_size-1),color="#475569")
    for i,s in enumerate(rows):
        y=.72-(i+.5)*.62/max(1,len(rows));lo,hi=map(float,s.get("xlim",(0,1)))
        if s.get("presentation")=="axis_inverted":lo,hi=hi,lo
        color=s.get("color",".2");label=str(s.get("source",""))+(" LOG" if s.get("scale")=="log" else "")
        ax.text(.02,y,f"{lo:g}",ha="left",va="center",fontsize=max(5,font_size-2),color=color)
        ax.text(.5,y,label,ha="center",va="center",fontsize=max(5,font_size-1),color=color)
        ax.text(.98,y,f"{hi:g}",ha="right",va="center",fontsize=max(5,font_size-2),color=color)

def _header_fraction(project,wells,tracks):
    """Return only the vertical space required by the active header rows."""
    max_rows=0
    for track in tracks:
        sources=[str(c.get("source","")) for c in project.viewer_template.get("curves",[])
                 if c.get("track_key")==track.get("key") and project.curve_visible(str(c.get("source","")))]
        for well in wells:
            max_rows=max(max_rows,sum(source.upper() in well.curves for source in sources))
    # Reserve room for the well title/distance plus one compact line per curve.
    configured=max([project.effective_track_properties(str(track.get("key")))["header_height"] for track in tracks] or [64])
    return min(.28,max(.065+.027*max(1,max_rows),configured/760.0))

def _plot_lithology(ax,well,depth):
    mnemonic=CorrelationProject.lithology_mnemonic(well)
    if mnemonic is None:
        ax.text(.5,.5,"Sin litología",transform=ax.transAxes,rotation=90,ha="center",va="center",fontsize=6,color=".45")
        return
    values=np.asarray(well.curves[mnemonic],float)
    colors={0:"#ffffff",1:"#F4A460",2:"#2BFFFF",3:"#808080",4:"#E277E3",5:"#00FF00"}
    for code,color in colors.items():
        mask=np.isfinite(values)&np.isclose(values,code)
        ax.fill_betweenx(depth,0,1,where=mask,step="mid",color=color,linewidth=0)
    ax.text(.5,1.01,mnemonic,transform=ax.transAxes,ha="center",va="bottom",fontsize=5.8,fontweight="bold")

def draw_correlation_figure(figure,project:CorrelationProject,curve_name="GR",datum_top=None):
    figure.clear();figure._hmd_discretization_artists=[];available={str(well.uwi):well for well in project.wells if well.has_log_data and project.well_visible_in_section(well.uwi)}
    if project.active_section_well_order:wells=[available[uwi] for uwi in project.active_section_well_order if uwi in available]
    else:wells=[well for well in project.wells if str(well.uwi) in available]
    tracks=project.visible_tracks();viewer=project.viewer_template.get("viewer",{})
    figure.patch.set_facecolor(viewer.get("workspace_background","white"))
    has_lithology=project.show_lithology and any(project.lithology_mnemonic(w) for w in wells)
    if not wells or (not tracks and not has_lithology):
        ax=figure.add_subplot(111);ax.text(.5,.5,"Cargue pozos LAS y una plantilla\nLos pozos sin registro permanecen disponibles en el Administrador y el Mapa.",ha="center");ax.axis("off");return
    n=len(wells);base_widths=[project.effective_track_properties(str(t.get("key")))["width"] for t in tracks]
    widths=base_widths+([.36] if has_lithology else [])
    distances=[_distance_value(wells[i],wells[i+1]) for i in range(n-1)]
    valid=[d for d in distances if d is not None and d>0]
    median=float(np.median(valid)) if valid else 1.0
    gap_widths=[.34 if project.spacing_mode=="uniform" else max(.18,min(.85,.34*((d or median)/median))) for d in distances]
    outer_widths=[.28]
    for i in range(n):
        outer_widths.append(sum(widths))
        if i<n-1: outer_widths.append(gap_widths[i])
    outer_widths.append(.38)
    header_fraction=_header_fraction(project,wells,tracks)
    outer=figure.add_gridspec(2,len(outer_widths),width_ratios=outer_widths,height_ratios=[header_fraction,1-header_fraction],left=.035,right=.97,top=.96,bottom=.07,wspace=.03,hspace=.02)
    reg=figure.add_subplot(outer[1,0]);reg.set_xlim(0,1);reg.set_ylim(0,1);reg.set_xticks([]);reg.set_ylabel("Posición estratigráfica",fontsize=7,fontweight="bold");reg.tick_params(labelsize=6);reg.spines[["top","bottom","right"]].set_visible(False)
    figure.add_subplot(outer[0,0]).axis("off");well_axes=[];head_groups=[];track_axis_groups=[];axis_depths={};group_info={};header_wells={}
    depth_arrays=[_depth(well,datum_top) for well in wells]
    common_ylim=None
    if datum_top:
        low=min(float(np.nanmin(values)) for values in depth_arrays)
        high=max(float(np.nanmax(values)) for values in depth_arrays)
        margin=max((high-low)*.02,1.0)
        common_ylim=(high+margin,low-margin)
    for wi,well in enumerate(wells):
        column=1+2*wi
        well_properties=[project.effective_track_properties(str(t.get("key")),well.uwi) for t in tracks]
        separation=max([props["separation"] for props in well_properties] or [3])/100
        well_widths=[props["width"] for props in well_properties]+([.36] if has_lithology else [])
        bg=outer[1,column].subgridspec(1,len(well_widths),width_ratios=well_widths,wspace=separation);hg=outer[0,column].subgridspec(1,len(well_widths),width_ratios=well_widths,wspace=separation)
        axes=[];heads=[];depth=depth_arrays[wi]
        display_tracks=tracks+([{"key":"__LITHOLOGY__","width":.36}] if has_lithology else [])
        for ti,track in enumerate(display_tracks):
            ax=figure.add_subplot(bg[0,ti]);hd=figure.add_subplot(hg[0,ti]);axes.append(ax);heads.append(hd);rows=[]
            props=project.effective_track_properties(str(track.get("key")),well.uwi) if track.get("key")!="__LITHOLOGY__" else project.default_track_properties()
            if str(props.get("name","")).strip().lower()=="track":props=dict(props,name=f"Track {ti+1}")
            if track.get("key")=="__LITHOLOGY__":
                _plot_lithology(ax,well,depth);_header(hd,[],props);sources=[CorrelationProject.lithology_mnemonic(well)]
            else:
              for c in project.viewer_template.get("curves",[]):
                if c.get("track_key")==track.get("key") and project.curve_visible(str(c.get("source",""))):
                    s=project.effective_curve_settings(well.uwi,str(c.get("source")),str(track.get("key")))
                    if s and str(s["source"]).upper() in well.curves:rows.append(s)
              plotted=[]
              for ci,s in enumerate(rows):
                  curve_axis=_plot_curve(ax,well,depth,s,ci)
                  if curve_axis is not None:
                      discretization=project.well_track_discretization(well.uwi,str(track.get("key")))
                      if discretization and str(discretization.get("source","")).upper()==str(s.get("source","")).upper():_apply_track_discretization(curve_axis,well,depth,s,discretization)
                      if curve_axis not in plotted:plotted.append(curve_axis)
              _header(hd,rows,props)
              sources=[str(settings.get("source","")).upper() for settings in rows]
            ax.set_facecolor(props.get("background",viewer.get("track_background","white")))
            scale_mode=props.get("depth_scale","first");show_depth=scale_mode=="all" or (scale_mode=="first" and ti==0)
            ax.set_ylim(common_ylim if common_ylim else (float(np.nanmax(depth)),float(np.nanmin(depth))));ax.set_xticks([]);ax.tick_params(axis="y",labelsize=5.8,direction="in",labelleft=show_depth)
            if props.get("grid_enabled",True):
                grid_color=props.get("grid_color",viewer.get("grid_color",".75"));grid_width=float(props.get("grid_width",.5));grid_alpha=float(props.get("grid_alpha",.5));minor_color=grid_color if props.get("grid_same_color",False) else props.get("grid_minor_color","#D8DEE8");minor_width=float(props.get("grid_minor_width",.3));minor_alpha=float(props.get("grid_minor_alpha",.25));styles={"solid":"-","dashed":"--","dotted":":"}
                if props.get("horizontal_grid_enabled",True):
                    interval=float(props.get("horizontal_grid_interval",0.0))
                    if interval>0:ax.yaxis.set_major_locator(MultipleLocator(interval))
                    hsub=int(props.get("horizontal_grid_subdivisions",0))
                    if hsub:ax.yaxis.set_minor_locator(AutoMinorLocator(hsub+1))
                    ax.grid(True,axis="y",which="major",color=grid_color,lw=grid_width,alpha=grid_alpha,linestyle=styles.get(props.get("horizontal_grid_style"),"-"))
                    if hsub:ax.grid(True,axis="y",which="minor",color=minor_color,lw=minor_width,alpha=minor_alpha,linestyle=styles.get(props.get("horizontal_grid_style"),"-"))
                if props.get("vertical_grid_enabled",True):
                    divisions=int(props.get("vertical_grid_divisions",5));xlo,xhi=ax.get_xlim();ax.set_xticks(np.linspace(xlo,xhi,divisions+1)[1:-1]);ax.tick_params(axis="x",labelbottom=False,bottom=False)
                    vsub=int(props.get("vertical_grid_subdivisions",0))
                    if vsub:ax.xaxis.set_minor_locator(AutoMinorLocator(vsub+1))
                    ax.grid(True,axis="x",which="major",color=grid_color,lw=grid_width,alpha=grid_alpha,linestyle=styles.get(props.get("vertical_grid_style"),"-"))
                    if vsub:ax.grid(True,axis="x",which="minor",color=minor_color,lw=minor_width,alpha=minor_alpha,linestyle=styles.get(props.get("vertical_grid_style"),"-"))
            for sp in ax.spines.values():sp.set_visible(bool(props.get("border_visible",True)));sp.set_color(props.get("border_color","#6B7280"));sp.set_linewidth(float(props.get("border_width",.7)))
            group=plotted if track.get("key")!="__LITHOLOGY__" and plotted else [ax]
            track_axis_groups.append(group)
            for group_axis in group:axis_depths[group_axis]=np.asarray(depth,float)
            group_info[group[0]]={"well":well,"track_key":str(track.get("key")),"depth":np.asarray(depth,float),
                                  "raw_depth":np.asarray(well.depth,float),"sources":[source for source in sources if source]}
        title_axis=heads[len(heads)//2];title_props=project.effective_track_properties(str(display_tracks[len(heads)//2].get("key")),well.uwi) if display_tracks[len(heads)//2].get("key")!="__LITHOLOGY__" else project.default_track_properties();title_axis.set_title(project.well_header_label(well),fontsize=title_props.get("header_font_size",9),fontweight="bold",pad=13)
        for head in heads:header_wells[head]=well
        well_axes.append(axes);head_groups.append(heads)
        if wi<n-1:
            figure.add_subplot(outer[0,column+1]).axis("off");figure.add_subplot(outer[1,column+1]).axis("off")
    figure.canvas.draw()
    free_arrows=[]
    for wi in range(n-1):
        a=head_groups[wi][-1].get_position();b=head_groups[wi+1][0].get_position();y=a.y1+.012
        arrow=FancyArrowPatch((a.x1,y),(b.x0,y),transform=figure.transFigure,arrowstyle="<->",mutation_scale=6,lw=.7)
        figure.add_artist(arrow);free_arrows.append(arrow);figure.text((a.x1+b.x0)/2,y+.006,_distance(wells[wi],wells[wi+1]),ha="center",fontsize=5.5)
    correlation_definitions=[]
    for ni,name in enumerate(project.top_names if project.show_tops else []):
        color=project.top_colors.get(name,TOP_COLORS[ni%len(TOP_COLORS)])
        style=project.effective_top_style(name);text_color=style.get("text_color") or color
        segments=[];points=[]
        for well,axes in zip(wells,well_axes):
            y=_top(well,name,datum_top)
            if y is None:
                if points:segments.append(points);points=[]
                continue
            for track_axis in axes:
                points.append((track_axis,0,y));points.append((track_axis,1,y))
            label_transform=blended_transform_factory(axes[-1].transAxes,axes[-1].transData)
            background=style.get("background_color","#FFF59D") if style.get("highlight") else "white"
            axes[-1].text(.98,y,name,transform=label_transform,ha="right",va="bottom",
                          fontsize=float(style.get("font_size",5.2)),fontstyle="italic" if style.get("italic") else "normal",
                          fontweight="bold" if style.get("bold") else "normal",color=text_color,zorder=10,clip_on=True,
                          bbox=dict(facecolor=background,edgecolor="none",alpha=.90 if style.get("highlight") else .72,pad=.7 if style.get("highlight") else .4))
        if points:segments.append(points)
        for segment in segments:
            if len(segment)>=2:
                coordinates=[_figure_point(figure,axis,x_fraction,depth) for axis,x_fraction,depth in segment]
                artist=Line2D([point[0] for point in coordinates],[point[1] for point in coordinates],transform=figure.transFigure,color=color,lw=project.correlation_linewidth,zorder=9,clip_on=False)
                figure.add_artist(artist);correlation_definitions.append((artist,segment))
    lith=figure.add_subplot(outer[1,-1]);lith.set_xlim(0,1);lith.set_xticks([]);lith.set_yticks([]);lith.set_ylim(well_axes[-1][0].get_ylim());names=project.top_names
    for i in range(len(names)-1 if project.show_tops else 0):
        a=_top(wells[-1],names[i],datum_top);b=_top(wells[-1],names[i+1],datum_top)
        if a is not None and b is not None:lith.axhspan(a,b,color=FORMATION_COLORS[i%len(FORMATION_COLORS)],alpha=.8);lith.text(.5,(a+b)/2,names[i],rotation=-90,ha="center",va="center",fontsize=6,fontweight="bold")
    figure.add_subplot(outer[0,-1]).axis("off")
    figure._hmd_depth_axes=[axis for axes in well_axes for axis in axes]
    figure._hmd_track_axis_groups=track_axis_groups
    figure._hmd_axis_depths=axis_depths
    figure._hmd_correlation_definitions=correlation_definitions
    figure._hmd_free_arrows=free_arrows
    figure._hmd_group_info=group_info
    figure._hmd_header_wells=header_wells
