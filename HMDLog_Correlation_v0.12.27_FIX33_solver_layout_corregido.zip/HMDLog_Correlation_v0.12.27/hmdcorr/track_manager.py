from __future__ import annotations

import copy

from PySide6.QtCore import Qt,QTimer
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QCheckBox,QColorDialog,QComboBox,QDialog,QDoubleSpinBox,
    QFormLayout,QFrame,QHBoxLayout,QLabel,QLineEdit,QMessageBox,QPushButton,QScrollArea,
    QSpinBox,QTabWidget,QVBoxLayout,QWidget)

from .viewer_template import default_curve_settings


class TrackManagerDialog(QDialog):
    """Configurador compacto de track, escalas de curvas y retícula."""
    def __init__(self,project,preview_callback,parent=None,initial_track_key=None,initial_well_uwi=None):
        super().__init__(parent);self._target_project=project;self.preview_callback=preview_callback
        # La ventana trabaja sobre una copia ligera: comparte los registros LAS,
        # pero aísla las cuatro estructuras de configuración que puede editar.
        # Así ningún valueChanged toca el proyecto que el visor está dibujando.
        self.project=copy.copy(project)
        self.project.viewer_template=copy.deepcopy(project.viewer_template)
        self.project.well_track_properties=copy.deepcopy(project.well_track_properties)
        self.project.hidden_tracks=set(project.hidden_tracks)
        self.project.curve_overrides=copy.deepcopy(project.curve_overrides)
        self.setWindowTitle("Configurar tracks y retícula");self.resize(650,610);self.setMinimumSize(560,480)
        self._loading=False;self._undo=[];self._pending_undo=None
        self._undo_timer=QTimer(self);self._undo_timer.setSingleShot(True);self._undo_timer.setInterval(300);self._undo_timer.timeout.connect(self._finish_undo_group)
        self._original=self._snapshot()
        root=QVBoxLayout(self);selectors=QFormLayout()
        self.track=QComboBox()
        for index,item in enumerate(project.viewer_template.get("tracks",[])):
            key=str(item.get("key"));self.track.addItem(self._friendly_track_label(index,item),key)
        self.scope=QComboBox();self.scope.addItem("Este track en todos los pozos","track");self.scope.addItem("Solo este track y pozo","well");self.scope.addItem("Todos los tracks de la plantilla","template")
        self.well=QComboBox();[self.well.addItem(w.name or w.uwi,str(w.uwi)) for w in project.wells]
        selectors.addRow("Track",self.track);selectors.addRow("Aplicar a",self.scope);selectors.addRow("Pozo",self.well);root.addLayout(selectors)
        hint=QLabel("Los cambios se guardan localmente y la sección se redibuja una sola vez al pulsar Aplicar.");hint.setWordWrap(True);hint.setStyleSheet("color:#475569;padding:3px");root.addWidget(hint)
        self.tabs=QTabWidget();root.addWidget(self.tabs,1);self._build_track_tab();self._build_curve_tab();self._build_grid_tab()
        actions=QHBoxLayout();self.up=QPushButton("← Mover");self.down=QPushButton("Mover →");self.defaults=QPushButton("Restaurar");self.undo=QPushButton("Deshacer");self.apply=QPushButton("Aplicar");self.cancel=QPushButton("Cancelar")
        for button in (self.up,self.down,self.defaults,self.undo):actions.addWidget(button)
        actions.addStretch();actions.addWidget(self.apply);actions.addWidget(self.cancel);root.addLayout(actions)
        self.track.currentIndexChanged.connect(self._load);self.scope.currentIndexChanged.connect(self._scope_changed);self.well.currentIndexChanged.connect(self._load)
        self.up.clicked.connect(lambda:self._move(-1));self.down.clicked.connect(lambda:self._move(1));self.defaults.clicked.connect(self._restore_defaults);self.undo.clicked.connect(self._undo_once);self.apply.clicked.connect(self._apply_and_accept);self.cancel.clicked.connect(self.reject)
        self._connect_track_controls();self._connect_curve_controls();self._connect_grid_controls()
        if initial_track_key:
            index=self.track.findData(str(initial_track_key))
            if index>=0:self.track.setCurrentIndex(index)
        if initial_well_uwi:
            index=self.well.findData(str(initial_well_uwi))
            if index>=0:self.well.setCurrentIndex(index)
        self._scope_changed()

    def _add_scroll_tab(self,page,title):
        """Aísla el tamaño del contenido para conservar visibles las acciones."""
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff);scroll.setWidget(page)
        self.tabs.addTab(scroll,title)

    def _friendly_track_label(self,index,item):
        key=str(item.get("key"));configured=str(self.project.effective_track_properties(key).get("name","") or "").strip()
        sources=[str(curve.get("source","")).upper() for curve in self.project.viewer_template.get("curves",[]) if str(curve.get("track_key"))==key]
        resistive=any(source.startswith("AT") or source in {"ILD","ILM","IL","SFL","SFLU","LLD","LLS","MSFL","RT","CILD"} for source in sources)
        descriptor="Resistividad" if resistive else ("Densidad–Neutrón" if {"RHOB","NPHI"}.issubset(sources) else (" / ".join(sources[:2]) if sources else "Sin curvas"))
        visible_name=configured if configured and configured.lower() not in {"track",f"track {index+1}"} else f"Track {index+1}"
        return f"{visible_name} — {descriptor}"

    def _build_track_tab(self):
        page=QWidget();layout=QVBoxLayout(page);form=QFormLayout();layout.addLayout(form)
        self.name=QLineEdit();self.visible=QCheckBox("Mostrar track")
        self.width_preset=QComboBox();self.width_preset.addItem("Estrecho",.7);self.width_preset.addItem("Normal",1.0);self.width_preset.addItem("Ancho",1.5);self.width_preset.addItem("Personalizado",None)
        self.width=QDoubleSpinBox();self.width.setRange(.1,10);self.width.setSingleStep(.1)
        self.depth_scale=QComboBox();self.depth_scale.addItem("Solo en el primer track","first");self.depth_scale.addItem("En todos los tracks","all");self.depth_scale.addItem("Oculta","none")
        self.background=self._color_button();self.header_background=self._color_button()
        for label,widget in (("Nombre",self.name),("Visibilidad",self.visible),("Ancho",self.width_preset),("Ancho personalizado",self.width),("Escala de profundidad",self.depth_scale),("Fondo",self.background),("Fondo del encabezado",self.header_background)):form.addRow(label,widget)
        self.advanced_toggle=QCheckBox("Mostrar opciones avanzadas");layout.addWidget(self.advanced_toggle)
        self.advanced=QWidget();advanced_form=QFormLayout(self.advanced)
        self.min_width=QSpinBox();self.min_width.setRange(50,1200);self.min_width.setSuffix(" px");self.border_visible=QCheckBox("Mostrar borde");self.border_color=self._color_button();self.border_width=QDoubleSpinBox();self.border_width.setRange(0,8);self.border_width.setSingleStep(.1)
        self.separation=QSpinBox();self.separation.setRange(0,40);self.separation.setSuffix(" px");self.header_height=QSpinBox();self.header_height.setRange(36,180);self.header_height.setSuffix(" px");self.header_font_size=QSpinBox();self.header_font_size.setRange(6,24);self.header_font_size.setSuffix(" pt")
        for label,widget in (("Ancho mínimo",self.min_width),("Borde",self.border_visible),("Color del borde",self.border_color),("Grosor del borde",self.border_width),("Separación",self.separation),("Altura del encabezado",self.header_height),("Texto del encabezado",self.header_font_size)):advanced_form.addRow(label,widget)
        self.advanced.setVisible(False);self.advanced_toggle.toggled.connect(self.advanced.setVisible);layout.addWidget(self.advanced);layout.addStretch();self._add_scroll_tab(page,"Track")

    def _build_curve_tab(self):
        page=QWidget();layout=QVBoxLayout(page);form=QFormLayout();layout.addLayout(form)
        self.curve=QComboBox();self.curve_scale=QComboBox();self.curve_scale.addItem("Lineal","linear");self.curve_scale.addItem("Logarítmica","log")
        self.curve_min=QDoubleSpinBox();self.curve_min.setRange(-1e9,1e9);self.curve_min.setDecimals(6);self.curve_max=QDoubleSpinBox();self.curve_max.setRange(-1e9,1e9);self.curve_max.setDecimals(6);self.curve_inverted=QCheckBox("Invertir eje de la curva")
        for label,widget in (("Curva",self.curve),("Tipo de escala",self.curve_scale),("Límite mínimo",self.curve_min),("Límite máximo",self.curve_max),("Presentación",self.curve_inverted)):form.addRow(label,widget)
        self.curve_recommendation=QLabel();self.curve_recommendation.setWordWrap(True);self.curve_recommendation.setStyleSheet("color:#475569;background:#F1F5F9;padding:8px;border-radius:4px");layout.addWidget(self.curve_recommendation)
        self.restore_curve=QPushButton("Restaurar valores recomendados");layout.addWidget(self.restore_curve);layout.addStretch();note=QLabel("La escala pertenece a cada curva. Una curva logarítmica requiere límites positivos.");note.setWordWrap(True);note.setStyleSheet("color:#475569");layout.addWidget(note);self._add_scroll_tab(page,"Curvas y escalas")

    def _build_grid_tab(self):
        page=QWidget();layout=QVBoxLayout(page);form=QFormLayout();layout.addLayout(form)
        self.grid_preset=QComboBox();self.grid_preset.addItem("Sin retícula","off");self.grid_preset.addItem("Retícula básica","basic");self.grid_preset.addItem("Retícula técnica","technical");self.grid_preset.addItem("Personalizada","custom")
        self.grid_enabled=QCheckBox("Activar retícula");self.horizontal_grid_enabled=QCheckBox("Mostrar líneas horizontales");self.vertical_grid_enabled=QCheckBox("Mostrar líneas verticales")
        self.horizontal_grid_interval=QDoubleSpinBox();self.horizontal_grid_interval.setRange(0,100000);self.horizontal_grid_interval.setDecimals(2);self.horizontal_grid_interval.setSpecialValueText("Automático");self.horizontal_grid_subdivisions=QSpinBox();self.horizontal_grid_subdivisions.setRange(0,10)
        self.vertical_grid_divisions=QSpinBox();self.vertical_grid_divisions.setRange(1,20);self.vertical_grid_subdivisions=QSpinBox();self.vertical_grid_subdivisions.setRange(0,10)
        self.vertical_grid_reference=QComboBox();self.vertical_grid_scale_mode=QComboBox();self.vertical_grid_scale_mode.addItem("Automática según la curva","auto");self.vertical_grid_scale_mode.addItem("Lineal","linear");self.vertical_grid_scale_mode.addItem("Logarítmica","log");self.vertical_grid_scale_mode.addItem("Personalizada","custom")
        self.vertical_grid_log_detail=QComboBox();self.vertical_grid_log_detail.addItem("Solo décadas","decades");self.vertical_grid_log_detail.addItem("Décadas + 2 y 5","2_5");self.vertical_grid_log_detail.addItem("Décadas + 2–9","2_9")
        self.vertical_grid_show_labels=QCheckBox("Mostrar valores principales en el encabezado")
        for label,widget in (("Configuración",self.grid_preset),("Retícula",self.grid_enabled),("Horizontal",self.horizontal_grid_enabled),("Intervalo de profundidad",self.horizontal_grid_interval),("Subdivisiones horizontales",self.horizontal_grid_subdivisions),("Vertical",self.vertical_grid_enabled),("Curva de referencia",self.vertical_grid_reference),("Distribución vertical",self.vertical_grid_scale_mode),("Detalle logarítmico",self.vertical_grid_log_detail),("Etiquetas",self.vertical_grid_show_labels),("Divisiones personalizadas",self.vertical_grid_divisions),("Subdivisiones personalizadas",self.vertical_grid_subdivisions)):form.addRow(label,widget)
        self.grid_color=self._color_button();self.grid_minor_color=self._color_button();self.grid_same_color=QCheckBox("Usar el mismo color para ambas");self.restore_grid_colors=QPushButton("Restaurar colores recomendados")
        self.grid_width=QDoubleSpinBox();self.grid_width.setRange(0,5);self.grid_width.setSingleStep(.1);self.grid_alpha=QDoubleSpinBox();self.grid_alpha.setRange(0,1);self.grid_alpha.setSingleStep(.05)
        self.grid_minor_width=QDoubleSpinBox();self.grid_minor_width.setRange(0,5);self.grid_minor_width.setSingleStep(.1);self.grid_minor_alpha=QDoubleSpinBox();self.grid_minor_alpha.setRange(0,1);self.grid_minor_alpha.setSingleStep(.05)
        for label,widget in (("Color principal",self.grid_color),("Color secundario",self.grid_minor_color),("Colores",self.grid_same_color),("",self.restore_grid_colors),("Grosor principal",self.grid_width),("Grosor secundario",self.grid_minor_width),("Opacidad principal",self.grid_alpha),("Opacidad secundaria",self.grid_minor_alpha)):form.addRow(label,widget)
        self.custom_grid=QWidget();custom=QFormLayout(self.custom_grid);self.horizontal_grid_style=QComboBox();self.vertical_grid_style=QComboBox()
        for combo in (self.horizontal_grid_style,self.vertical_grid_style):combo.addItem("Continua","solid");combo.addItem("Discontinua","dashed");combo.addItem("Punteada","dotted")
        for label,widget in (("Estilo horizontal",self.horizontal_grid_style),("Estilo vertical",self.vertical_grid_style)):custom.addRow(label,widget)
        layout.addWidget(self.custom_grid);layout.addStretch();self._add_scroll_tab(page,"Retícula")

    def _connect_track_controls(self):
        self.name.textChanged.connect(self._stage_track);self.width_preset.currentIndexChanged.connect(self._width_preset_changed)
        for widget in (self.width,self.min_width,self.border_width,self.separation,self.header_height,self.header_font_size):widget.valueChanged.connect(self._stage_track)
        for widget in (self.visible,self.border_visible):widget.toggled.connect(self._stage_track)
        self.depth_scale.currentIndexChanged.connect(self._stage_track)
    def _connect_curve_controls(self):
        self.curve.currentIndexChanged.connect(self._load_curve);self.curve_scale.currentIndexChanged.connect(self._stage_curve);self.curve_min.valueChanged.connect(self._stage_curve);self.curve_max.valueChanged.connect(self._stage_curve);self.curve_inverted.toggled.connect(self._stage_curve);self.restore_curve.clicked.connect(self._restore_curve_recommendation)
    def _connect_grid_controls(self):
        self.grid_preset.currentIndexChanged.connect(self._apply_grid_preset)
        for widget in (self.grid_width,self.grid_alpha,self.grid_minor_width,self.grid_minor_alpha,self.horizontal_grid_interval,self.horizontal_grid_subdivisions,self.vertical_grid_divisions,self.vertical_grid_subdivisions):widget.valueChanged.connect(self._grid_changed)
        for widget in (self.grid_enabled,self.grid_same_color,self.horizontal_grid_enabled,self.vertical_grid_enabled,self.vertical_grid_show_labels):widget.toggled.connect(self._grid_changed)
        for widget in (self.vertical_grid_reference,self.vertical_grid_scale_mode,self.vertical_grid_log_detail,self.horizontal_grid_style,self.vertical_grid_style):widget.currentIndexChanged.connect(self._grid_changed)
        self.restore_grid_colors.clicked.connect(self._restore_grid_colors)

    def _color_button(self):
        button=QPushButton();button.clicked.connect(lambda:self._pick_color(button));self._set_color(button,"#FFFFFF");return button
    def _set_color(self,button,value):
        value=QColor(str(value)).name().upper();button.setProperty("color",value);button.setText(value);button.setStyleSheet(f"text-align:left;background:{value};")
    def _pick_color(self,button):
        color=QColorDialog.getColor(QColor(button.property("color")),self,"Seleccionar color")
        if color.isValid():self._set_color(button,color.name());self._stage_track() if button in (self.background,self.header_background,self.border_color) else self._grid_changed()
    def _current_key(self):return self.track.currentData()
    def _scope_changed(self,*_):
        local=self.scope.currentData()=="well";self.well.setEnabled(local);self.visible.setEnabled(not local);self._load()
    def _load(self,*_):
        key=self._current_key()
        if not key:return
        self._loading=True;uwi=self.well.currentData() if self.scope.currentData()=="well" else None;p=self.project.effective_track_properties(key,uwi)
        configured=str(p["name"]);self.name.setText(f"Track {self.track.currentIndex()+1}" if configured.strip().lower()=="track" else configured);self.visible.setChecked(self.project.track_visible(key));self.width.setValue(p["width"]);self._set_width_preset(p["width"]);self.depth_scale.setCurrentIndex(max(0,self.depth_scale.findData(p["depth_scale"])));self._set_color(self.background,p["background"]);self._set_color(self.header_background,p["header_background"]);self.min_width.setValue(p["min_width"]);self.border_visible.setChecked(bool(p["border_visible"]));self._set_color(self.border_color,p["border_color"]);self.border_width.setValue(p["border_width"]);self.separation.setValue(int(p["separation"]));self.header_height.setValue(p["header_height"]);self.header_font_size.setValue(p["header_font_size"])
        self.grid_enabled.setChecked(bool(p["grid_enabled"]));self._set_color(self.grid_color,p["grid_color"]);self._set_color(self.grid_minor_color,p.get("grid_minor_color","#D8DEE8"));self.grid_same_color.setChecked(bool(p.get("grid_same_color",False)));self.grid_minor_color.setEnabled(not self.grid_same_color.isChecked());self.grid_width.setValue(p["grid_width"]);self.grid_alpha.setValue(p["grid_alpha"]);self.grid_minor_width.setValue(p.get("grid_minor_width",.3));self.grid_minor_alpha.setValue(p.get("grid_minor_alpha",.25));self.horizontal_grid_enabled.setChecked(bool(p["horizontal_grid_enabled"]));self.horizontal_grid_interval.setValue(p["horizontal_grid_interval"]);self.horizontal_grid_subdivisions.setValue(p["horizontal_grid_subdivisions"]);self.horizontal_grid_style.setCurrentIndex(max(0,self.horizontal_grid_style.findData(p["horizontal_grid_style"])));self.vertical_grid_enabled.setChecked(bool(p["vertical_grid_enabled"]));self.vertical_grid_divisions.setValue(p["vertical_grid_divisions"]);self.vertical_grid_subdivisions.setValue(p["vertical_grid_subdivisions"]);self.vertical_grid_style.setCurrentIndex(max(0,self.vertical_grid_style.findData(p["vertical_grid_style"])));self._populate_grid_references(p.get("vertical_grid_reference",""));self.vertical_grid_scale_mode.setCurrentIndex(max(0,self.vertical_grid_scale_mode.findData(p.get("vertical_grid_scale_mode","auto"))));self.vertical_grid_log_detail.setCurrentIndex(max(0,self.vertical_grid_log_detail.findData(p.get("vertical_grid_log_detail","2_5"))));self.vertical_grid_show_labels.setChecked(bool(p.get("vertical_grid_show_labels",True)));self._set_grid_preset(p);self._populate_curves();self._loading=False;self._load_curve()
    def _set_width_preset(self,value):
        index=next((i for i in range(3) if abs(float(self.width_preset.itemData(i))-float(value))<.001),3);self.width_preset.setCurrentIndex(index)
    def _width_preset_changed(self,*_):
        value=self.width_preset.currentData()
        if value is not None:self.width.setValue(float(value))
        self.width.setEnabled(value is None);self._stage_track()
    def _track_values(self):
        return {"name":self.name.text().strip() or f"Track {self.track.currentIndex()+1}","width":self.width.value(),"min_width":self.min_width.value(),"background":self.background.property("color"),"border_visible":self.border_visible.isChecked(),"border_color":self.border_color.property("color"),"border_width":self.border_width.value(),"grid_enabled":self.grid_enabled.isChecked(),"grid_color":self.grid_color.property("color"),"grid_width":self.grid_width.value(),"grid_alpha":self.grid_alpha.value(),"grid_minor_color":self.grid_minor_color.property("color"),"grid_minor_width":self.grid_minor_width.value(),"grid_minor_alpha":self.grid_minor_alpha.value(),"grid_same_color":self.grid_same_color.isChecked(),"horizontal_grid_enabled":self.horizontal_grid_enabled.isChecked(),"horizontal_grid_interval":self.horizontal_grid_interval.value(),"horizontal_grid_subdivisions":self.horizontal_grid_subdivisions.value(),"horizontal_grid_style":self.horizontal_grid_style.currentData(),"vertical_grid_enabled":self.vertical_grid_enabled.isChecked(),"vertical_grid_divisions":self.vertical_grid_divisions.value(),"vertical_grid_subdivisions":self.vertical_grid_subdivisions.value(),"vertical_grid_style":self.vertical_grid_style.currentData(),"vertical_grid_reference":self.vertical_grid_reference.currentData() or "","vertical_grid_scale_mode":self.vertical_grid_scale_mode.currentData(),"vertical_grid_log_detail":self.vertical_grid_log_detail.currentData(),"vertical_grid_show_labels":self.vertical_grid_show_labels.isChecked(),"depth_scale":self.depth_scale.currentData(),"separation":self.separation.value(),"header_height":self.header_height.value(),"header_background":self.header_background.property("color"),"header_font_size":self.header_font_size.value()}
    def _snapshot(self):return (copy.deepcopy(self.project.viewer_template),copy.deepcopy(self.project.well_track_properties),set(self.project.hidden_tracks),copy.deepcopy(self.project.curve_overrides))
    def _change_before(self):
        return self._pending_undo if self._pending_undo is not None else self._snapshot()
    def _remember(self,before):
        if self._pending_undo is None:self._pending_undo=before
        self._undo_timer.start()
    def _finish_undo_group(self):
        before=self._pending_undo;self._pending_undo=None
        if before is not None and before!=self._snapshot():self._undo.append(before);self._undo=self._undo[-30:]
    def _stage_track(self,*_):
        if self._loading:return
        key=self._current_key();before=self._change_before();values=self._track_values();scope=self.scope.currentData()
        if scope=="well":self.project.set_track_properties(key,values,str(self.well.currentData()))
        elif scope=="template":
            for item in self.project.viewer_template.get("tracks",[]):self.project.set_track_properties(str(item.get("key")),values)
        else:self.project.set_track_properties(key,values)
        keys=[str(item.get("key")) for item in self.project.viewer_template.get("tracks",[])] if scope=="template" else [str(key)]
        for visible_key in keys:
            if self.visible.isChecked():self.project.hidden_tracks.discard(visible_key)
            else:self.project.hidden_tracks.add(visible_key)
        self._remember(before)
    def _populate_grid_references(self,selected=""):
        key=self._current_key();self.vertical_grid_reference.blockSignals(True);self.vertical_grid_reference.clear()
        for item in self.project.viewer_template.get("curves",[]):
            if str(item.get("track_key"))==str(key):
                source=str(item.get("source","")).upper();self.vertical_grid_reference.addItem(source,source)
        index=self.vertical_grid_reference.findData(str(selected).upper());self.vertical_grid_reference.setCurrentIndex(max(0,index));self.vertical_grid_reference.blockSignals(False)
    def _populate_curves(self):
        key=self._current_key();current=self.curve.currentData();self.curve.blockSignals(True);self.curve.clear()
        for item in self.project.viewer_template.get("curves",[]):
            if str(item.get("track_key"))==str(key):self.curve.addItem(str(item.get("source","")),str(item.get("source","")).upper())
        index=self.curve.findData(current);self.curve.setCurrentIndex(max(0,index));self.curve.blockSignals(False)
    def _load_curve(self,*_):
        source=self.curve.currentData();key=self._current_key();enabled=bool(source)
        for widget in (self.curve_scale,self.curve_min,self.curve_max,self.curve_inverted,self.restore_curve):widget.setEnabled(enabled)
        if not source:return
        self._loading=True;uwi=str(self.well.currentData() or (self.project.wells[0].uwi if self.project.wells else ""));settings=self.project.effective_curve_settings(uwi,source,key) or default_curve_settings(source,key);lo,hi=map(float,settings.get("xlim",(0,1)));self.curve_scale.setCurrentIndex(max(0,self.curve_scale.findData(settings.get("scale","linear"))));self.curve_min.setValue(lo);self.curve_max.setValue(hi);self.curve_inverted.setChecked(settings.get("presentation")=="axis_inverted")
        recommended=default_curve_settings(source,key);rlo,rhi=recommended["xlim"];kind="logarítmica" if recommended["scale"]=="log" else "lineal";self.curve_recommendation.setText(f"Recomendación para {source}: escala {kind}, límites {rlo:g} – {rhi:g}.");self._loading=False
    def _stage_curve(self,*_,warn=False):
        if self._loading:return True
        source=self.curve.currentData();key=self._current_key()
        if not source:return True
        lo=self.curve_min.value();hi=self.curve_max.value();scale=str(self.curve_scale.currentData());error="El límite máximo debe ser mayor que el mínimo." if hi<=lo else ("La escala logarítmica requiere límites mínimo y máximo positivos." if scale=="log" and lo<=0 else "")
        if error:
            self.curve_recommendation.setText(error)
            if warn:QMessageBox.warning(self,"Escala no válida",error)
            return False
        before=self._change_before();uwi=str(self.well.currentData()) if self.scope.currentData()=="well" else None;self.project.set_curve_override(source,{"xlim":[lo,hi],"auto_range":False,"scale":scale},uwi);self.project.set_curve_presentation(str(key),source,"axis_inverted" if self.curve_inverted.isChecked() else "normal");self._remember(before);return True
    def _restore_curve_recommendation(self):
        source=self.curve.currentData();key=self._current_key()
        if not source:return
        settings=default_curve_settings(source,key);self._loading=True;self.curve_scale.setCurrentIndex(max(0,self.curve_scale.findData(settings["scale"])));self.curve_min.setValue(settings["xlim"][0]);self.curve_max.setValue(settings["xlim"][1]);self.curve_inverted.setChecked(False);self._loading=False;self._stage_curve()
    def _set_grid_preset(self,p):
        if not p.get("grid_enabled",True):value="off"
        elif p.get("horizontal_grid_subdivisions",0)==0 and p.get("vertical_grid_subdivisions",0)==0:value="basic"
        elif p.get("horizontal_grid_subdivisions",0)==4 and p.get("vertical_grid_subdivisions",0)==4:value="technical"
        else:value="custom"
        self.grid_preset.setCurrentIndex(max(0,self.grid_preset.findData(value)));self.custom_grid.setVisible(value=="custom")
    def _apply_grid_preset(self,*_):
        if self._loading:return
        preset=self.grid_preset.currentData();self._loading=True
        if preset=="off":self.grid_enabled.setChecked(False)
        elif preset in {"basic","technical"}:
            self.grid_enabled.setChecked(True);self.horizontal_grid_enabled.setChecked(True);self.vertical_grid_enabled.setChecked(True);self.horizontal_grid_interval.setValue(0);self.vertical_grid_divisions.setValue(5);sub=4 if preset=="technical" else 0;self.horizontal_grid_subdivisions.setValue(sub);self.vertical_grid_subdivisions.setValue(sub);self.horizontal_grid_style.setCurrentIndex(0);self.vertical_grid_style.setCurrentIndex(0)
        self.custom_grid.setVisible(preset=="custom");self._loading=False;self._stage_track()
    def _grid_changed(self,*_):
        if self._loading:return
        self.grid_minor_color.setEnabled(not self.grid_same_color.isChecked())
        self.grid_preset.blockSignals(True);self.grid_preset.setCurrentIndex(max(0,self.grid_preset.findData("custom")));self.grid_preset.blockSignals(False);self.custom_grid.setVisible(True);self._stage_track()
    def _restore_grid_colors(self):
        self._loading=True;self._set_color(self.grid_color,"#B8C0CC");self._set_color(self.grid_minor_color,"#D8DEE8");self.grid_width.setValue(.5);self.grid_minor_width.setValue(.3);self.grid_alpha.setValue(.5);self.grid_minor_alpha.setValue(.25);self.grid_same_color.setChecked(False);self.grid_minor_color.setEnabled(True);self._loading=False;self._grid_changed()
    def _move(self,direction):
        key=self._current_key();tracks=self.project.viewer_template.get("tracks",[]);row=next((i for i,item in enumerate(tracks) if str(item.get("key"))==str(key)),-1);target=row+direction
        if row<0 or target<0 or target>=len(tracks):return
        before=self._change_before();tracks[row],tracks[target]=tracks[target],tracks[row];self._remember(before);self.track.blockSignals(True);text=self.track.itemText(row);data=self.track.itemData(row);self.track.removeItem(row);self.track.insertItem(target,text,data);self.track.setCurrentIndex(target);self.track.blockSignals(False)
    def _restore_defaults(self):
        key=self._current_key();before=self._change_before();defaults=self.project.default_track_properties();defaults["name"]=self.project.effective_track_properties(key)["name"]
        if self.scope.currentData()=="well":self.project.remove_well_track_properties(str(self.well.currentData()),key)
        else:self.project.set_track_properties(key,defaults)
        self.project.hidden_tracks.discard(str(key));self._remember(before);self._load()
    def _undo_once(self):
        self._finish_undo_group()
        if not self._undo:return
        self.project.viewer_template,self.project.well_track_properties,self.project.hidden_tracks,self.project.curve_overrides=self._undo.pop();self._load()
    def _apply_and_accept(self):
        self._stage_track()
        if self._stage_curve(warn=True):
            self._finish_undo_group();target=self._target_project
            target.viewer_template=copy.deepcopy(self.project.viewer_template)
            target.well_track_properties=copy.deepcopy(self.project.well_track_properties)
            target.hidden_tracks=set(self.project.hidden_tracks)
            target.curve_overrides=copy.deepcopy(self.project.curve_overrides)
            self.accept()
    def reject(self):
        self._undo_timer.stop();super().reject()
