"""Backends gráficos desacoplados de HMDLog Correlation."""

from .backend import BackendStatus, probe_vispy

__all__ = ["BackendStatus", "probe_vispy"]
