from __future__ import annotations

import math
import time
from pathlib import Path
import numpy as np
from PySide6.QtCore import QSize,Qt,QTimer
from PySide6.QtGui import QIcon,QKeySequence,QShortcut
from PySide6.QtWidgets import (QButtonGroup,QDialog,QDialogButtonBox,QHBoxLayout,
                               QInputDialog,QLabel,QMessageBox,QToolButton,QVBoxLayout)
from ..coordinates import is_valid_geographic,haversine_meters


def _visible_wells(project):
    available = {
        str(well.uwi): well for well in project.wells
        if well.has_log_data and project.well_visible_in_section(well.uwi)
    }
    if project.active_section_well_order:
        return [available[uwi] for uwi in project.active_section_well_order if uwi in available]
    return list(available.values())


def _curve_settings(project, well, preferred="GR"):
    candidates = [preferred]
    candidates.extend(
        str(item.get("source", "")).upper()
        for item in project.viewer_template.get("curves", [])
        if project.curve_visible(str(item.get("source", "")))
    )
    for source in dict.fromkeys(candidates):
        if source in well.curves:
            settings = project.effective_curve_settings(well.uwi, source) or {}
            return source, settings
    return None, None


def _track_curve_settings(project,well,track_key):
    rows=[]
    for item in project.viewer_template.get("curves",[]):
        source=str(item.get("source","")).upper()
        if str(item.get("track_key"))!=str(track_key) or not project.curve_visible(source) or source not in well.curves:continue
        settings=project.effective_curve_settings(well.uwi,source,track_key)
        if settings:rows.append((source,settings))
    return rows


def _header_scale(settings):
    lo,hi=map(float,settings.get("xlim",(0.0,1.0)))
    if settings.get("presentation")=="axis_inverted":lo,hi=hi,lo
    return f"{lo:g}",f"{hi:g}"


def _axis_positions(values,settings,scale_mode=None):
    """Transformación X única para curva, retícula y encabezado (0..1)."""
    lo,hi=map(float,settings.get("xlim",(0.0,1.0)))
    mode=str(scale_mode or settings.get("scale","linear"))
    data=np.asarray(values,dtype=float)
    if hi<=lo:return np.full(data.shape,np.nan,dtype=float)
    if mode=="log":
        if lo<=0:return np.full(data.shape,np.nan,dtype=float)
        with np.errstate(divide="ignore",invalid="ignore"):
            position=(np.log10(data)-math.log10(lo))/(math.log10(hi)-math.log10(lo))
        position=np.where(data>0,position,np.nan)
    else:position=(data-lo)/(hi-lo)
    if settings.get("presentation")=="axis_inverted":position=1.0-position
    return position


def _well_distance(a,b):
    if is_valid_geographic(a.coordinate_data) and is_valid_geographic(b.coordinate_data):return float(haversine_meters(a.coordinate_data,b.coordinate_data))
    if a.coordinate_data or b.coordinate_data:return None
    if None in (a.x,a.y,b.x,b.y):return None
    return float(math.hypot(float(b.x)-float(a.x),float(b.y)-float(a.y)))


def _distance_label(value):
    if value is None:return "Distancia no disponible"
    return f"{value/1000:.2f} km" if value>=1000 else f"{value:.0f} m"


def _scene_structure_signature(project,datum_top):
    """Identifica sólo cambios que exigen reconstruir el árbol de ViewBox."""
    wells=_visible_wells(project);tracks=project.visible_tracks()
    track_keys=tuple(str(track.get("key")) for track in tracks)
    assignments=tuple((str(item.get("track_key")),str(item.get("source","")).upper()) for item in project.viewer_template.get("curves",[]))
    rows=tuple((str(well.uwi),tuple((key,tuple(source for assigned,source in assignments if assigned==key and project.curve_visible(source) and source in well.curves)) for key in track_keys)) for well in wells)
    layout=[]
    for well in wells:
        for key in track_keys:
            props=project.effective_track_properties(key,well.uwi)
            layout.append((str(well.uwi),key,float(props.get("width",1)),int(props.get("min_width",150)),
                int(props.get("separation",3)),int(props.get("header_height",64)),str(props.get("depth_scale","first")),
                str(props.get("background","")),str(props.get("header_background","")),bool(props.get("border_visible",True)),
                str(props.get("border_color","")),float(props.get("border_width",.7)),str(props.get("name","")),int(props.get("header_font_size",9))))
    well_data=tuple((str(well.uwi),id(well.depth),len(well.depth),tuple(sorted(well.curves))) for well in wells)
    distances=tuple(_well_distance(wells[index],wells[index+1]) for index in range(max(0,len(wells)-1)))
    return (id(project),str(datum_top or ""),project.spacing_mode,track_keys,rows,tuple(layout),well_data,distances,
            tuple(project.well_header_label(well) for well in wells))


def _curve_render_signature(well,source,settings):
    values=well.curves[source];xlim=tuple(float(value) for value in settings.get("xlim",(0,1)))
    return (id(well.depth),len(well.depth),id(values),len(values),xlim,str(settings.get("scale","linear")),
            str(settings.get("presentation","normal")),str(settings.get("color","#008000")),float(settings.get("linewidth",1.0)))


def _grid_render_signature(props,settings):
    keys=("grid_enabled","grid_color","grid_width","grid_alpha","grid_minor_color","grid_minor_width",
          "grid_minor_alpha","grid_same_color","horizontal_grid_enabled","horizontal_grid_interval",
          "horizontal_grid_subdivisions","horizontal_grid_style","vertical_grid_enabled","vertical_grid_divisions",
          "vertical_grid_subdivisions","vertical_grid_style","vertical_grid_reference","vertical_grid_scale_mode",
          "vertical_grid_log_detail","vertical_grid_show_labels")
    return (tuple((key,props.get(key)) for key in keys),tuple(float(value) for value in settings.get("xlim",(0,1))),
            str(settings.get("scale","linear")),str(settings.get("presentation","normal")))


def _append_grid_segment(target,start,end,style):
    """Añade una línea o sus trazos a un único lote OpenGL."""
    if style=="solid":target.extend((start,end));return
    parts=12 if style=="dashed" else 24
    duty=.58 if style=="dashed" else .16
    x0,y0=start;x1,y1=end
    for index in range(parts):
        begin=index/parts;finish=min(1.0,begin+duty/parts)
        target.extend(((x0+(x1-x0)*begin,y0+(y1-y0)*begin),
                       (x0+(x1-x0)*finish,y0+(y1-y0)*finish)))


def _vertical_grid_positions(project,well,track_key,props,fallback_source):
    """Retorna posiciones normalizadas principales/secundarias según la curva."""
    source=str(props.get("vertical_grid_reference") or fallback_source).upper()
    settings=project.effective_curve_settings(str(well.uwi),source,track_key)
    if not settings:
        source=str(fallback_source).upper();settings=project.effective_curve_settings(str(well.uwi),source,track_key)
    if not settings:return [],[]
    lo,hi=map(float,settings.get("xlim",(0,1)))
    if hi<=lo:return [],[]
    mode=str(props.get("vertical_grid_scale_mode","auto"))
    if mode=="auto":mode=str(settings.get("scale","linear"))
    if mode=="log" and lo<=0:mode="linear"
    def normalized(value):
        return float(_axis_positions([value],settings,mode)[0])
    if mode=="log" and lo>0:
        powers=range(math.ceil(math.log10(lo)),math.floor(math.log10(hi))+1)
        major_values=[10.0**power for power in powers if lo<10.0**power<hi]
        detail=str(props.get("vertical_grid_log_detail","2_5"));multipliers=[] if detail=="decades" else ([2,5] if detail=="2_5" else list(range(2,10)))
        minor_values=[]
        for power in range(math.floor(math.log10(lo))-1,math.ceil(math.log10(hi))+1):
            minor_values.extend(value for multiplier in multipliers if lo<(value:=multiplier*10.0**power)<hi)
        return [(normalized(value),f"{value:g}") for value in major_values],[normalized(value) for value in minor_values]
    divisions=int(props.get("vertical_grid_divisions",5));values=np.linspace(lo,hi,divisions+1);major_values=values[1:-1]
    subdivisions=int(props.get("vertical_grid_subdivisions",0));minor_values=[]
    for start,end in zip(values[:-1],values[1:]):
        if subdivisions:minor_values.extend(np.linspace(start,end,subdivisions+2)[1:-1])
    return [(normalized(float(value)),f"{float(value):g}") for value in major_values],[normalized(float(value)) for value in minor_values]


_ICON_DIR=Path(__file__).resolve().parent/"icons"


class _LayoutHandle:
    """Aplica una restricción de columna a todos sus widgets, sin otro Grid."""
    def __init__(self,*widgets):
        self.widgets=list(widgets);self._stretch=(1,1);self._visible=True
    def add(self,*widgets):self.widgets.extend(widgets)
    @property
    def visible(self):return self._visible
    @visible.setter
    def visible(self,value):
        self._visible=bool(value)
        for widget in self.widgets:widget.visible=self._visible
    @property
    def width_min(self):return self.widgets[0].width_min if self.widgets else 0
    @width_min.setter
    def width_min(self,value):
        for widget in self.widgets:widget.width_min=value
    @property
    def width_max(self):return self.widgets[0].width_max if self.widgets else None
    @width_max.setter
    def width_max(self,value):
        for widget in self.widgets:widget.width_max=value
    @property
    def stretch(self):return self._stretch
    @stretch.setter
    def stretch(self,value):
        self._stretch=value
        for widget in self.widgets:widget.stretch=value


def _tool_button(icon_name,tooltip,checkable=False):
    button=QToolButton()
    button.setIcon(QIcon(str(_ICON_DIR/f"{icon_name}.svg")))
    button.setIconSize(QSize(22,22));button.setFixedSize(38,38)
    button.setToolTip(tooltip);button.setStatusTip(tooltip)
    button.setAccessibleName(tooltip);button.setCheckable(checkable)
    button.setAutoRaise(False)
    button.setStyleSheet(
        "QToolButton{background:#FFFFFF;border:1px solid #AEB7C2;border-radius:4px;padding:5px;}"
        "QToolButton:hover{background:#EAF4FC;border-color:#4A90C2;}"
        "QToolButton:pressed{background:#CFE6F7;}"
        "QToolButton:checked{background:#D8ECFF;border:2px solid #1976B9;padding:4px;}"
        "QToolButton:disabled{background:#F1F3F5;border-color:#D5D9DE;}"
    )
    return button


class VisPyCorrelationDialog(QDialog):
    """Visor GPU compuesto: cada columna contiene encabezado y track propios."""

    def __init__(self, project, datum_top=None, parent=None,embedded=False,change_callback=None,configuration_callback=None):
        super().__init__(parent)
        self.embedded=bool(embedded);self.change_callback=change_callback;self.configuration_callback=configuration_callback
        if self.embedded:self.setWindowFlags(Qt.Widget)
        self.setWindowTitle("Visor GPU compuesto v0.12.27 — Restricciones de layout corregidas")
        self.resize(1180, 760)
        layout = QVBoxLayout(self)
        note = QLabel(
            "VISOR COMPUESTO v0.12.27 · Compositor horizontal sin restricciones incompatibles. "
            "Mueva el cursor sobre un track para consultar profundidad y curvas; Ctrl+clic fija o libera la lectura."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        navigation=QHBoxLayout();navigation.setSpacing(6)
        self.area_zoom_button=_tool_button("zoom-area","Zoom areal (A)",True)
        self.interval_zoom_button=_tool_button("zoom-interval","Zoom por intervalo (I)",True)
        self.zoom_button_group=QButtonGroup(self);self.zoom_button_group.setExclusive(True)
        self.zoom_button_group.addButton(self.area_zoom_button);self.zoom_button_group.addButton(self.interval_zoom_button)
        self.interval_zoom_button.setChecked(True)
        self.reset_zoom_button=_tool_button("reset-view","Restablecer vista (R)")
        self.edit_tops_button=_tool_button("edit-tops","Editar cimas (E)",True)
        self.assisted_button=_tool_button("assisted-correlation","Correlación asistida (C)")
        self.correlation_lines_button=_tool_button("geologic-correlation","Mostrar/ocultar líneas de correlación (L)",True)
        self.correlation_lines_button.setChecked(bool(project.show_correlation_lines))
        self.configure_grid_button=_tool_button("configure-grid","Configurar tracks y retícula")
        self.configure_grid_button.setEnabled(callable(self.configuration_callback))
        navigation.addWidget(self.area_zoom_button);navigation.addWidget(self.interval_zoom_button);navigation.addWidget(self.reset_zoom_button)
        separator=QLabel();separator.setFixedSize(1,28);separator.setStyleSheet("background:#B7BEC8;margin:0 3px;");navigation.addWidget(separator)
        navigation.addWidget(self.edit_tops_button);navigation.addWidget(self.assisted_button);navigation.addWidget(self.correlation_lines_button);navigation.addWidget(self.configure_grid_button)
        self.active_mode_label=QLabel("Modo activo: Zoom por intervalo");self.active_mode_label.setStyleSheet("color:#59636F;margin-left:8px;")
        navigation.addWidget(self.active_mode_label);navigation.addStretch();layout.addLayout(navigation)
        try:
            from vispy import scene
            from vispy.color import Color
        except Exception as exc:
            raise RuntimeError(f"No fue posible cargar VisPy: {exc}") from exc

        self.project_changed=False;self.top_edit_enabled=False;self._top_drag=None;self.assisted_state=None
        self.full_scene_rebuilds=0;self.incremental_updates=0;self.last_refresh_ms=0.0
        self.cursor_pinned=False;self.pinned_cursor_hit=None
        try:
            self.canvas = scene.SceneCanvas(keys="interactive", bgcolor="#EEF2F7", show=False)
            self._camera_refresh_timer=QTimer(self);self._camera_refresh_timer.setSingleShot(True);self._camera_refresh_timer.setInterval(16);self._camera_refresh_timer.timeout.connect(self._update_correlation_lines)
            self.canvas.native.setFocusPolicy(Qt.StrongFocus)
            layout.addWidget(self.canvas.native, 1)
            self._draw_project(scene, Color, project, datum_top)
            self._structure_signature=_scene_structure_signature(project,datum_top)
            self.canvas.events.mouse_move.connect(self._on_mouse_move)
            self.canvas.events.mouse_press.connect(self._on_mouse_press)
            self.canvas.events.mouse_release.connect(self._on_mouse_release)
            self.canvas.events.mouse_wheel.connect(self._on_mouse_wheel)
            self.canvas.events.key_press.connect(self._on_key_press)
            # Al maximizar/restaurar, VisPy emite resize antes de que todos los
            # ViewBox hayan terminado de adoptar su geometría definitiva. El
            # refresco diferido evita reutilizar transformaciones del tamaño
            # anterior para marcos, cimas, etiquetas y correlaciones.
            self._resize_refresh_timer=QTimer(self)
            self._resize_refresh_timer.setSingleShot(True)
            self._resize_refresh_timer.timeout.connect(self._refresh_overlays_after_resize)
            self.canvas.events.resize.connect(self._on_canvas_resize)
            QTimer.singleShot(0,self._update_correlation_lines)
            QTimer.singleShot(75,self._update_correlation_lines)
        except Exception as exc:
            raise RuntimeError(
                "VisPy está instalado, pero no fue posible inicializar la vista GPU. "
                f"Detalle: {exc}"
            ) from exc

        if not self.embedded:
            buttons = QDialogButtonBox(QDialogButtonBox.Close)
            buttons.rejected.connect(self.reject)
            layout.addWidget(buttons)
        self.zoom_mode="interval";self._zoom_drag=None;self._pan_drag=None
        self.area_zoom_button.clicked.connect(lambda:self._set_zoom_mode("area"))
        self.interval_zoom_button.clicked.connect(lambda:self._set_zoom_mode("interval"))
        self.reset_zoom_button.clicked.connect(self._reset_gpu_zoom)
        self.edit_tops_button.toggled.connect(self._set_top_edit_enabled)
        self.assisted_button.clicked.connect(self._configure_assisted_correlation)
        self.correlation_lines_button.toggled.connect(self._set_correlation_lines_visible)
        self.configure_grid_button.clicked.connect(self._open_track_grid_configuration)
        if not self.embedded:
            self.interval_shortcut=QShortcut(QKeySequence("I"),self);self.interval_shortcut.setContext(Qt.WindowShortcut)
            self.area_shortcut=QShortcut(QKeySequence("A"),self);self.area_shortcut.setContext(Qt.WindowShortcut)
            self.reset_shortcut=QShortcut(QKeySequence("R"),self);self.reset_shortcut.setContext(Qt.WindowShortcut)
            self.edit_shortcut=QShortcut(QKeySequence("E"),self);self.edit_shortcut.setContext(Qt.WindowShortcut)
            self.assisted_shortcut=QShortcut(QKeySequence("C"),self);self.assisted_shortcut.setContext(Qt.WindowShortcut)
            self.interval_shortcut.activated.connect(lambda:self._activate_zoom_mode("interval"))
            self.area_shortcut.activated.connect(lambda:self._activate_zoom_mode("area"))
            self.reset_shortcut.activated.connect(self._reset_gpu_zoom)
            self.edit_shortcut.activated.connect(lambda:self.edit_tops_button.toggle())
            self.assisted_shortcut.activated.connect(self._configure_assisted_correlation)
        self.cancel_shortcut=QShortcut(QKeySequence("Esc"),self);self.cancel_shortcut.setContext(Qt.WidgetWithChildrenShortcut if self.embedded else Qt.WindowShortcut)
        self.cancel_shortcut.activated.connect(self._cancel_gpu_interaction)
        self.lines_shortcut=QShortcut(QKeySequence("L"),self);self.lines_shortcut.setContext(Qt.WidgetWithChildrenShortcut if self.embedded else Qt.WindowShortcut)
        self.lines_shortcut.activated.connect(lambda:self.correlation_lines_button.toggle())
        QTimer.singleShot(0,self.canvas.native.setFocus)

    def _on_canvas_resize(self,*_args):
        """Sincroniza overlays con la geometría final tras maximizar/restaurar."""
        self._enforce_exact_horizontal_domains()
        self.canvas.update()
        QTimer.singleShot(0,self._refresh_overlays_after_resize)
        self._resize_refresh_timer.start(80)

    def _open_track_grid_configuration(self):
        if not callable(self.configuration_callback):return
        active=getattr(self,"active_track_group",None)
        self.configuration_callback(active.get("track_key") if active else None,
                                    str(active["well"].uwi) if active else None)

    def _refresh_overlays_after_resize(self):
        if getattr(self,"_area_focus_active",False):
            self._refresh_area_focus_geometry()
        self._enforce_exact_horizontal_domains()
        self._resolve_grid_geometry()
        self.canvas.update()
        self._update_correlation_lines()

    @staticmethod
    def _set_exact_camera_rect(camera,low,high):
        """Evita el margen implícito de set_range y fija X exactamente en 0..1."""
        low,high=sorted((float(low),float(high)))
        camera.rect=(0.0,low,1.0,max(high-low,1e-12))

    def _enforce_exact_horizontal_domains(self):
        """Alinea físicamente encabezado, ticks, retícula y canvas del track."""
        for group in getattr(self,"well_groups",[]):
            rect=group["track"].camera.rect
            self._set_exact_camera_rect(group["track"].camera,rect.bottom,rect.top)
            group["header"].camera.rect=(0.0,0.0,1.0,1.0)

    def _apply_responsive_track_minimums(self):
        """Mantiene el mínimo técnico fijado al construir la geometría."""
        if getattr(self,"_area_focus_active",False):return
        for group in getattr(self,"well_groups",[]):
            group["grid"].width_min=group.get("base_width_min",42);group["grid"].width_max=None

    def _resolve_grid_geometry(self):
        """Aplica una sola solución coherente a encabezados, tracks y gaps."""
        layouts=[getattr(self,"root_grid",None)]
        layouts.extend(item["widget"] for item in getattr(self,"area_layout_items",[]))
        layouts.extend(group["grid"] for group in getattr(self,"well_groups",[]))
        seen=set()
        for layout in layouts:
            if layout is None or id(layout) in seen:continue
            seen.add(id(layout))
            recreate=getattr(layout,"_recreate_solver",None);update=getattr(layout,"_update_child_widget_dim",None)
            if callable(recreate):recreate()
            if callable(update):update()

    def capture_navigation_state(self):
        state={}
        for group in getattr(self,"well_groups",[]):
            rect=group["track"].camera.rect
            state[f'{group["well"].uwi}::{group.get("track_key","")}']=(float(rect.left),float(rect.bottom),float(rect.width),float(rect.height))
        return {"rects":state,"zoom_mode":getattr(self,"zoom_mode","interval")}

    def restore_navigation_state(self,state):
        if not state:return
        rects=state.get("rects",{})
        if isinstance(rects,dict):
            for group in getattr(self,"well_groups",[]):
                rect=rects.get(f'{group["well"].uwi}::{group.get("track_key","")}')
                if rect:self._set_exact_camera_rect(group["track"].camera,float(rect[1]),float(rect[1])+float(rect[3]))
        else:
            for group,rect in zip(getattr(self,"well_groups",[]),rects):self._set_exact_camera_rect(group["track"].camera,float(rect[1]),float(rect[1])+float(rect[3]))
        self._activate_zoom_mode(state.get("zoom_mode","interval"))
        self.canvas.update()

    def _draw_project(self, scene, Color, project, datum_top):
        self.scene=scene;self.Color=Color
        self.datum_top=datum_top
        self.project=project
        wells = _visible_wells(project)
        if not wells:
            view=self.canvas.central_widget.add_view();view.camera=scene.PanZoomCamera(aspect=None)
            scene.visuals.Text("No hay pozos visibles con datos LAS",color="#374151",pos=(0,0),parent=view.scene)
            return

        display_depths=[]
        for well in wells:
            depth=np.asarray(well.depth,dtype=np.float32)
            if datum_top:depth=depth-float(well.tops.get(datum_top,0.0))
            valid_depth=depth[np.isfinite(depth)]
            if valid_depth.size:display_depths.append(valid_depth)
        if not display_depths:return

        low=min(float(np.nanmin(depth)) for depth in display_depths)
        high=max(float(np.nanmax(depth)) for depth in display_depths)
        margin=max((high-low)*.02,1.0)
        grid=self.canvas.central_widget.add_grid(spacing=0,margin=4)
        self.root_grid=grid;self.initial_depth_range=(low-margin,high+margin)
        self.well_groups=[];self.area_layout_items=[];self.correlation_gap_views=[];self._area_focus_active=False;master_camera=None
        top_names = sorted({name for well in wells for name in well.tops})
        top_colors = ["#B91C1C", "#D97706", "#2563EB", "#15803D", "#7E22CE"]
        self.top_names=top_names;self.default_top_colors=top_colors

        visible_tracks=project.visible_tracks();self.well_track_groups=[]
        distances=[_well_distance(wells[i],wells[i+1]) for i in range(len(wells)-1)]
        valid_distances=[value for value in distances if value is not None and value>0];median_distance=float(np.median(valid_distances)) if valid_distances else 1.0
        header_height=max([project.effective_track_properties(str(track.get("key")))["header_height"] for track in visible_tracks] or [64])
        well_layouts=[]
        for well in wells:
            tracks=[]
            for track in visible_tracks:
                track_key=str(track.get("key"));rows=_track_curve_settings(project,well,track_key)
                if rows:tracks.append((track,track_key,rows))
            weight=max(.1,sum(float(project.effective_track_properties(key,well.uwi).get("width",1.0)) for _track,key,_rows in tracks))
            well_layouts.append((well,tracks,weight))
        root_column=0
        for index,(well,well_tracks,well_weight) in enumerate(well_layouts):
            depth = np.asarray(well.depth, dtype=np.float32)
            if datum_top:depth=depth-float(well.tops.get(datum_top,0.0))
            if index:
                distance=distances[index-1];ratio=1.0 if project.spacing_mode=="uniform" else ((distance or median_distance)/median_distance)
                gap_stretch=max(.12,min(.85,.28*ratio))
                # Su altura es exactamente la suma de las dos filas. Imponer
                # además 64 px hacía insoluble la ecuación del solver.
                gap_header=grid.add_view(row=0,col=root_column,row_span=2,bgcolor="#EEF2F7");gap_header.camera=scene.PanZoomCamera(aspect=None,interactive=False);gap_header.camera.set_range(x=(0,1),y=(0,1),margin=0)
                gap_view=grid.add_view(row=2,col=root_column,bgcolor="#EEF2F7");gap_view.camera=scene.PanZoomCamera(aspect=None,interactive=False)
                gap_handle=_LayoutHandle(gap_header,gap_view);gap_handle.stretch=(gap_stretch,1);gap_handle.width_min=44
                gap_record={"widget":gap_handle,"kind":"gap","stretch":gap_handle.stretch,
                            "base_width_min":44,"left_uwi":str(wells[index-1].uwi),"right_uwi":str(well.uwi)}
                self.area_layout_items.append(gap_record)
                scene.visuals.Text(_distance_label(distance),pos=(.5,.5),anchor_x="center",anchor_y="center",color="#475569",font_size=7,parent=gap_header.scene)
                gap_view.camera.rect=(0.0,low-margin,1.0,(high-low)+2*margin);gap_view.camera.flip=(False,True,False)
                if master_camera is not None:gap_view.camera.link(master_camera,axis="y")
                gap_record["view"]=gap_view;self.correlation_gap_views.append(gap_record)
                root_column+=1
            current_well_groups=[];well_widgets=[];well_grid=grid
            if not well_tracks:continue
            common_header_height=max(24,min(30,int(round(header_height*.42))))
            # Cuatro niveles legibles: nombre de track, curva, límites y
            # valores internos de la retícula (décadas en escala logarítmica).
            track_header_height=max(48,header_height-common_header_height)
            common_props=project.effective_track_properties(well_tracks[0][1],well.uwi)
            common_background=common_props.get("header_background","#FFFFFF")
            common_border="#6B7280" if common_props.get("border_visible",True) else common_background
            well_header_view=grid.add_view(row=0,col=root_column,col_span=len(well_tracks),
                bgcolor=common_background,border_color=common_border)
            well_header_view.height_min=common_header_height;well_header_view.height_max=common_header_height
            well_header_view.camera=scene.PanZoomCamera(aspect=None,interactive=False)
            well_header_view.camera.rect=(0.0,0.0,1.0,1.0)
            scene.visuals.Text(project.well_header_label(well),pos=(.5,.5),anchor_x="center",anchor_y="center",
                color="#111827",font_size=float(common_props.get("header_font_size",9)),parent=well_header_view.scene)
            for track_index,(track,track_key,rows) in enumerate(well_tracks):
                props=project.effective_track_properties(track_key,well.uwi);source,settings=rows[0]
                is_first_track=track_index==0;is_last_track=track_index==len(well_tracks)-1
                configured_width_min=int(props.get("min_width",150));technical_width_min=42
                show_axis=str(props.get("depth_scale","first"))=="all" or (str(props.get("depth_scale","first"))=="first" and not current_well_groups)
                border=props.get("border_color","#6B7280") if props.get("border_visible",True) else props.get("header_background","#FFFFFF")
                track_column=root_column+track_index
                header_view=grid.add_view(row=1,col=track_column,bgcolor=props.get("header_background","#FFFFFF"),border_color=border)
                header_view.height_min=track_header_height;header_view.height_max=track_header_height;header_view.camera=scene.PanZoomCamera(aspect=None,interactive=False);header_view.camera.rect=(0.0,0.0,1.0,1.0)
                # El borde configurable se dibuja una sola vez como LineVisual.
                # La cámara coincide exactamente con 0..1: no existe margen
                # lateral entre el ViewBox y el dominio normalizado del track.
                plot_view=grid.add_view(row=2,col=track_column,bgcolor=props.get("background","#FFFFFF"));plot_view.camera=scene.PanZoomCamera(aspect=None,interactive=False);plot_view.camera.rect=(0.0,low-margin,1.0,(high-low)+2*margin);plot_view.camera.flip=(False,True,False)
                track_grid=_LayoutHandle(header_view,plot_view);track_grid.stretch=(float(props.get("width",1.0)),1);track_grid.width_min=technical_width_min
                well_widgets.extend((header_view,plot_view))
                if master_camera is None:master_camera=plot_view.camera
                else:plot_view.camera.link(master_camera,axis="y")
                header_font=float(props.get("header_font_size",9));configured_track_name=str(props.get("name",track_key));track_name=f"Track {track_index+1}" if configured_track_name.strip().lower()=="track" else configured_track_name
                scene.visuals.Text(track_name,pos=(.5,.82),anchor_x="center",anchor_y="center",color="#475569",font_size=max(6,header_font-1),parent=header_view.scene)
                lo_label,hi_label=_header_scale(settings);curve_color=Color(settings.get("color","#008000"));curve_label=source+(" LOG" if settings.get("scale")=="log" else "")
                scale_font=max(6,header_font-2)
                lo_scale_text=scene.visuals.Text(lo_label,pos=(0,.28),anchor_x="left",anchor_y="center",color=curve_color,font_size=scale_font,parent=header_view.scene);curve_label_text=scene.visuals.Text(curve_label,pos=(.5,.55),anchor_x="center",anchor_y="center",color=curve_color,font_size=scale_font,parent=header_view.scene);hi_scale_text=scene.visuals.Text(hi_label,pos=(1,.28),anchor_x="right",anchor_y="center",color=curve_color,font_size=scale_font,parent=header_view.scene)
                vmajor_positions,vminor_positions=_vertical_grid_positions(project,well,track_key,props,source)
                grid_header_labels=[]
                if props.get("vertical_grid_show_labels",True):
                    for position,label_text in vmajor_positions:
                        label_font=max(5,header_font-3);label_visual=scene.visuals.Text(label_text,pos=(position,.08),anchor_x="center",anchor_y="center",color="#64748B",font_size=label_font,parent=header_view.scene)
                        grid_header_labels.append({"visual":label_visual,"position":float(position),"text":str(label_text),"font_size":float(label_font)})
                header_tick_visual=scene.visuals.Line(pos=np.zeros((2,2),dtype=np.float32),
                    color=border,width=max(.5,float(props.get("border_width",.7))),connect="segments",method="gl",parent=header_view.scene)
                curve_visuals={};curve_signatures={}
                for curve_source,curve_settings in rows:
                    values=np.asarray(well.curves[curve_source],dtype=np.float32)
                    normalized=_axis_positions(values,curve_settings);valid=np.isfinite(depth)&np.isfinite(normalized)
                    if valid.sum()<2:
                        visual=scene.visuals.Line(pos=np.zeros((2,2),dtype=np.float32),color=Color(curve_settings.get("color","#008000")),width=max(1.0,float(curve_settings.get("linewidth",1.0))),method="gl",parent=plot_view.scene);visual.visible=False
                        curve_visuals[curve_source]=visual;curve_signatures[curve_source]=_curve_render_signature(well,curve_source,curve_settings);continue
                    pos=np.column_stack((np.clip(normalized,-.15,1.15)[valid],depth[valid])).astype(np.float32,copy=False)
                    curve_visuals[curve_source]=scene.visuals.Line(pos=pos,color=Color(curve_settings.get("color","#008000")),width=max(1.0,float(curve_settings.get("linewidth",1.0))),method="gl",parent=plot_view.scene)
                    curve_signatures[curve_source]=_curve_render_signature(well,curve_source,curve_settings)
                grid_color=Color(props.get("grid_color","#B8C0CC"));grid_color.alpha=float(props.get("grid_alpha",.5))
                hgrid_visual=scene.visuals.Line(pos=np.zeros((2,2),dtype=np.float32),color=grid_color,width=max(.1,float(props.get("grid_width",.5))),connect="segments",method="gl",parent=plot_view.scene)
                vgrid_visual=scene.visuals.Line(pos=np.zeros((2,2),dtype=np.float32),color=grid_color,width=max(.1,float(props.get("grid_width",.5))),connect="segments",method="gl",parent=plot_view.scene)
                minor_color=Color(props.get("grid_color","#B8C0CC") if props.get("grid_same_color",False) else props.get("grid_minor_color","#D8DEE8"));minor_color.alpha=float(props.get("grid_minor_alpha",.25))
                hminor_grid_visual=scene.visuals.Line(pos=np.zeros((2,2),dtype=np.float32),color=minor_color,width=max(.1,float(props.get("grid_minor_width",.3))),connect="segments",method="gl",parent=plot_view.scene)
                vminor_grid_visual=scene.visuals.Line(pos=np.zeros((2,2),dtype=np.float32),color=minor_color,width=max(.1,float(props.get("grid_minor_width",.3))),connect="segments",method="gl",parent=plot_view.scene)
                hgrid_visual.visible=bool(props.get("grid_enabled",True) and props.get("horizontal_grid_enabled",True));hminor_grid_visual.visible=hgrid_visual.visible;vgrid_visual.visible=bool(props.get("grid_enabled",True) and props.get("vertical_grid_enabled",True));vminor_grid_visual.visible=vgrid_visual.visible
                hgrid_visual.set_gl_state(blend=True);hminor_grid_visual.set_gl_state(blend=True);vgrid_visual.set_gl_state(blend=True);vminor_grid_visual.set_gl_state(blend=True)
                border_visual=scene.visuals.Line(pos=np.zeros((4,2),dtype=np.float32),color="#9CA3AF",
                    width=max(.1,float(props.get("border_width",.7))),connect="segments",method="gl",parent=plot_view.scene)
                border_visual.visible=bool(props.get("border_visible",True))
                # Límites X persistentes: equivalen a los spines izquierdo y
                # derecho de Matplotlib y representan mínimo/máximo de curva.
                scale_limit_visual=scene.visuals.Line(pos=np.zeros((4,2),dtype=np.float32),
                    color=props.get("border_color","#6B7280"),width=max(.1,float(props.get("border_width",.7))),
                    connect="segments",method="gl",parent=plot_view.scene)
                scale_limit_visual.visible=bool(props.get("border_visible",True))
                separator_visual=scene.visuals.Line(pos=np.zeros((2,2),dtype=np.float32),color="#4B5563",
                    width=max(1.4,float(props.get("border_width",.7))*1.8),method="gl",parent=plot_view.scene)
                separator_visual.visible=not is_last_track
                depth_tick_line=scene.visuals.Line(pos=np.zeros((2,2),dtype=np.float32),color="#64748B",width=.8,connect="segments",method="gl",parent=plot_view.scene);depth_tick_line.visible=show_axis
                depth_tick_texts=[scene.visuals.Text("",pos=(.045,low),anchor_x="left",anchor_y="center",color="#334155",font_size=6,parent=plot_view.scene) for _ in range(7)] if show_axis else []
                cursor_line=scene.visuals.Line(pos=np.asarray([[0,low],[1,low]],dtype=np.float32),color="#2563EB",width=1.0,method="gl",parent=plot_view.scene);cursor_line.visible=False
                cursor_text=scene.visuals.Text("",pos=(.03,low),anchor_x="left",anchor_y="bottom",color="#1D4ED8",font_size=7,parent=plot_view.scene);cursor_text.visible=False
                curve_data={curve_source:{"values":np.asarray(well.curves[curve_source],dtype=np.float32),"unit":str(well.curve_units.get(curve_source,"") or "")} for curve_source,_ in rows}
                reference_source=str(props.get("vertical_grid_reference") or source).upper();reference_settings=project.effective_curve_settings(well.uwi,reference_source,track_key) or settings
                group={"well":well,"grid":track_grid,"well_grid":well_grid,"header":header_view,"track":plot_view,"axis":None,"source":source,"display_depth":depth,"raw_depth":np.asarray(well.depth,dtype=np.float32),"raw_values":np.asarray(well.curves[source],dtype=np.float32),"curve_data":curve_data,"curve_visuals":curve_visuals,"curve_signatures":curve_signatures,"curve_label_text":curve_label_text,"_header_signature":_curve_render_signature(well,source,settings),"_grid_config_signature":_grid_render_signature(props,reference_settings),"cursor_line":cursor_line,"cursor_text":cursor_text,"top_depths":{},"track_key":track_key,"props":props,"configured_width_min":configured_width_min,"base_width_min":technical_width_min,"base_stretch":track_grid.stretch,"hgrid_visual":hgrid_visual,"hminor_grid_visual":hminor_grid_visual,"vgrid_visual":vgrid_visual,"vminor_grid_visual":vminor_grid_visual,"vmajor_positions":vmajor_positions,"vminor_positions":vminor_positions,"grid_header_labels":grid_header_labels,"header_tick_visual":header_tick_visual,"_grid_label_signature":(bool(props.get("vertical_grid_show_labels",True)),tuple((float(position),str(label)) for position,label in vmajor_positions)),"lo_scale_text":lo_scale_text,"hi_scale_text":hi_scale_text,"lo_scale_label":str(lo_label),"hi_scale_label":str(hi_label),"scale_font":float(scale_font),"border_visual":border_visual,"scale_limit_visual":scale_limit_visual,"separator_visual":separator_visual,"depth_tick_line":depth_tick_line,"depth_tick_texts":depth_tick_texts,"is_first_track":is_first_track,"is_last_track":is_last_track}
                self.well_groups.append(group);current_well_groups.append(group);plot_view.camera.events.transform_change.connect(self._schedule_camera_refresh)
                for top_index,name in enumerate(top_names):
                    if name not in well.tops:continue
                    y=float(well.tops[name])-(float(well.tops.get(datum_top,0.0)) if datum_top else 0.0)
                    group["top_depths"][name]=y
            if current_well_groups:
                self.well_track_groups.append(current_well_groups)
                well_handle=_LayoutHandle(well_header_view,*well_widgets);well_handle.stretch=(well_weight,1)
                self.area_layout_items.append({"widget":well_handle,"kind":"well","uwi":str(well.uwi),"stretch":well_handle.stretch,"base_width_min":0})
            root_column+=len(well_tracks)

        self._apply_responsive_track_minimums()
        self._resolve_grid_geometry()

        self._build_well_top_overlay(scene,project,top_names,top_colors)
        self._build_correlation_overlay(scene,project,top_names,top_colors)
        self.zoom_selection=scene.visuals.Rectangle(center=(0,0),width=1,height=1,
            color=(.15,.45,1,.13),border_color="#2563EB",border_width=1,parent=self.canvas.scene)
        self.zoom_selection.visible=False
        self.ghost_line=scene.visuals.Line(pos=np.zeros((2,2),dtype=np.float32),color="#7C3AED",width=1.6,
            method="gl",parent=self.canvas.scene);self.ghost_line.visible=False
        self.ghost_label=scene.visuals.Text("",pos=(0,0),anchor_x="left",anchor_y="bottom",
            color="#6D28D9",font_size=8,parent=self.canvas.scene);self.ghost_label.visible=False
        self._topology_signature=self._current_topology_signature(project)

    @staticmethod
    def _current_topology_signature(project):
        return tuple((str(well.uwi),tuple(sorted(well.tops))) for well in _visible_wells(project))

    @staticmethod
    def _normalized_curve_position(depth,values,settings):
        values=np.asarray(values,dtype=np.float32);depth=np.asarray(depth,dtype=np.float32)
        normalized=_axis_positions(values,settings);valid=np.isfinite(depth)&np.isfinite(normalized)
        if valid.sum()<2:return None
        return np.column_stack((np.clip(normalized,-.15,1.15)[valid],depth[valid])).astype(np.float32,copy=False)

    def _replace_grid_header_labels(self,group,positions):
        for record in group.get("grid_header_labels",[]):record["visual"].parent=None
        labels=[];font=max(5,float(group.get("scale_font",6))-1)
        if group["props"].get("vertical_grid_show_labels",True):
            for position,label_text in positions:
                visual=self.scene.visuals.Text(label_text,pos=(position,.08),anchor_x="center",anchor_y="center",
                    color="#64748B",font_size=font,parent=group["header"].scene)
                labels.append({"visual":visual,"position":float(position),"text":str(label_text),"font_size":float(font)})
        group["grid_header_labels"]=labels

    def _detach_overlay_visuals(self):
        for collection in (getattr(self,"well_top_overlays",[]),getattr(self,"correlation_overlays",[])):
            for record in collection:
                for key in ("line","label"):
                    visual=record.get(key)
                    if visual is not None:visual.parent=None

    def _rebuild_scene(self,project,datum_top):
        navigation=self.capture_navigation_state();self._cancel_gpu_interaction();self._detach_overlay_visuals()
        for name in ("zoom_selection","ghost_line","ghost_label"):
            visual=getattr(self,name,None)
            if visual is not None:visual.parent=None
        for child in list(self.canvas.central_widget.children):child.parent=None
        self._draw_project(self.scene,self.Color,project,datum_top)
        self._structure_signature=_scene_structure_signature(project,datum_top)
        self.full_scene_rebuilds+=1;self.restore_navigation_state(navigation)
        QTimer.singleShot(0,self._update_correlation_lines)

    def refresh_project(self,project,datum_top=None):
        """Actualiza datos sobre el contexto OpenGL existente siempre que sea posible."""
        started=time.perf_counter();signature=_scene_structure_signature(project,datum_top)
        if signature!=getattr(self,"_structure_signature",None):
            self._rebuild_scene(project,datum_top);mode="scene"
        else:
            self.project=project;self.datum_top=datum_top;well_by_uwi={str(well.uwi):well for well in _visible_wells(project)}
            for group in self.well_groups:
                well=well_by_uwi[str(group["well"].uwi)];group["well"]=well
                depth=np.asarray(well.depth,dtype=np.float32)
                if datum_top:depth=depth-float(well.tops.get(datum_top,0.0))
                group["display_depth"]=depth;group["raw_depth"]=np.asarray(well.depth,dtype=np.float32)
                group["curve_data"]={source:{"values":np.asarray(well.curves[source],dtype=np.float32),"unit":str(well.curve_units.get(source,"") or "")} for source in group["curve_visuals"]}
                for source,visual in group["curve_visuals"].items():
                    settings=project.effective_curve_settings(well.uwi,source,group["track_key"]) or {}
                    curve_signature=_curve_render_signature(well,source,settings)
                    if group["curve_signatures"].get(source)!=curve_signature:
                        position=self._normalized_curve_position(depth,well.curves[source],settings)
                        if position is None:visual.visible=False
                        else:
                            visual.set_data(pos=position,color=self.Color(settings.get("color","#008000")),width=max(1.0,float(settings.get("linewidth",1.0))));visual.visible=True
                        group["curve_signatures"][source]=curve_signature
                source=group["source"];settings=project.effective_curve_settings(well.uwi,source,group["track_key"]) or {}
                group["raw_values"]=np.asarray(well.curves[source],dtype=np.float32)
                props=project.effective_track_properties(group["track_key"],well.uwi);group["props"]=props
                header_signature=_curve_render_signature(well,source,settings)
                if group.get("_header_signature")!=header_signature:
                    lo_label,hi_label=_header_scale(settings);curve_color=self.Color(settings.get("color","#008000"))
                    group["lo_scale_text"].text=lo_label;group["hi_scale_text"].text=hi_label
                    group["lo_scale_text"].color=curve_color;group["hi_scale_text"].color=curve_color
                    group["curve_label_text"].text=source+(" LOG" if settings.get("scale")=="log" else "");group["curve_label_text"].color=curve_color
                    group["lo_scale_label"]=str(lo_label);group["hi_scale_label"]=str(hi_label);group["_header_signature"]=header_signature
                reference_source=str(props.get("vertical_grid_reference") or source).upper();reference_settings=project.effective_curve_settings(well.uwi,reference_source,group["track_key"]) or settings
                grid_signature=_grid_render_signature(props,reference_settings)
                if group.get("_grid_config_signature")!=grid_signature:
                    major,minor=_vertical_grid_positions(project,well,group["track_key"],props,source)
                    new_signature=tuple((float(position),str(label)) for position,label in major)
                    group["vmajor_positions"]=major;group["vminor_positions"]=minor
                    label_signature=(bool(props.get("vertical_grid_show_labels",True)),new_signature)
                    if group.get("_grid_label_signature")!=label_signature:
                        self._replace_grid_header_labels(group,major);group["_grid_label_signature"]=label_signature
                    grid_color=self.Color(props.get("grid_color","#B8C0CC"));grid_color.alpha=float(props.get("grid_alpha",.5))
                    minor_color=self.Color(props.get("grid_color","#B8C0CC") if props.get("grid_same_color",False) else props.get("grid_minor_color","#D8DEE8"));minor_color.alpha=float(props.get("grid_minor_alpha",.25))
                    for visual in (group["hgrid_visual"],group["vgrid_visual"]):visual.set_data(color=grid_color,width=max(.1,float(props.get("grid_width",.5))))
                    for visual in (group["hminor_grid_visual"],group["vminor_grid_visual"]):visual.set_data(color=minor_color,width=max(.1,float(props.get("grid_minor_width",.3))))
                    group.pop("_grid_signature",None);group["_grid_config_signature"]=grid_signature
                group["top_depths"]={name:float(value)-(float(well.tops.get(datum_top,0.0)) if datum_top else 0.0) for name,value in well.tops.items()}
            topology=self._current_topology_signature(project)
            needs_overlays=topology!=getattr(self,"_topology_signature",None) or (project.show_tops and not getattr(self,"well_top_overlays",[]))
            if needs_overlays:
                self.top_names=sorted({name for well in _visible_wells(project) for name in well.tops});self._rebuild_correlation_overlay();self._topology_signature=topology
            self.correlation_lines_button.blockSignals(True);self.correlation_lines_button.setChecked(bool(project.show_correlation_lines));self.correlation_lines_button.blockSignals(False)
            self._update_overlay_styles();self._update_correlation_lines();self.incremental_updates+=1;mode="incremental"
        self.last_refresh_ms=(time.perf_counter()-started)*1000.0
        return mode

    def _update_overlay_styles(self):
        for collection in (getattr(self,"well_top_overlays",[]),getattr(self,"correlation_overlays",[])):
            for record in collection:
                name=record["name"];index=self.top_names.index(name) if name in self.top_names else 0
                color=self.project.top_colors.get(name,self.default_top_colors[index%len(self.default_top_colors)])
                record["line"].set_data(color=self.Color(color),width=max(.6,float(self.project.correlation_linewidth)))
                label=record.get("label")
                if label is not None:
                    style=self.project.effective_top_style(name);label.color=style.get("text_color") or color
                    label.font_size=max(6,float(style.get("font_size",6)));label.bold=bool(style.get("bold",False));label.italic=bool(style.get("italic",False))

    def _build_well_top_overlay(self,scene,project,top_names,default_colors):
        self.well_top_overlays=[]
        if not project.show_tops:return
        for tracks in getattr(self,"well_track_groups",[]):
            if not tracks:continue
            for top_index,name in enumerate(top_names):
                if name not in tracks[0]["top_depths"]:continue
                color=project.top_colors.get(name,default_colors[top_index%len(default_colors)])
                style=project.effective_top_style(name)
                for track_index,group in enumerate(tracks):
                    line=scene.visuals.Line(pos=np.zeros((2,2),dtype=np.float32),color=color,
                        width=max(.6,float(project.correlation_linewidth)),method="gl",parent=group["track"].scene)
                    line.order=900;line.set_gl_state(blend=True,depth_test=False);line.visible=False
                    label=None
                    if track_index==len(tracks)-1:
                        label=scene.visuals.Text(name,pos=(1.0,0.0),anchor_x="right",anchor_y="bottom",
                            color=style.get("text_color") or color,font_size=max(6,float(style.get("font_size",6))),
                            bold=bool(style.get("bold",False)),italic=bool(style.get("italic",False)),parent=group["track"].scene)
                        label.order=901;label.visible=False
                    self.well_top_overlays.append({"line":line,"label":label,"group":group,"name":name})

    def _build_correlation_overlay(self,scene,project,top_names,default_colors):
        self.correlation_overlays=[]
        if not project.show_tops:return
        pairs=[]
        gaps=getattr(self,"correlation_gap_views",[])
        for pair_index,(left_tracks,right_tracks) in enumerate(zip(getattr(self,"well_track_groups",[]),getattr(self,"well_track_groups",[])[1:])):
            if left_tracks and right_tracks and pair_index<len(gaps):pairs.append((left_tracks[-1],right_tracks[0],gaps[pair_index]))
        for left,right,gap in pairs:
            for top_index,name in enumerate(top_names):
                if name not in left["top_depths"] or name not in right["top_depths"]:continue
                color=project.top_colors.get(name,default_colors[top_index % len(default_colors)])
                line=scene.visuals.Line(pos=np.zeros((2,2),dtype=np.float32),color=color,
                    width=max(.6,float(project.correlation_linewidth)),method="gl",parent=gap["view"].scene)
                line.order=1000;line.set_gl_state(blend=True,depth_test=False);line.visible=False
                self.correlation_overlays.append({"line":line,"left":left,"right":right,"left_tracks":left_tracks,"right_tracks":right_tracks,"gap":gap,"name":name})

    def _schedule_camera_refresh(self,*_args):
        """Agrupa ráfagas de eventos de cámara en un refresco por cuadro."""
        if not self._camera_refresh_timer.isActive():self._camera_refresh_timer.start()

    @staticmethod
    def _set_segment_visual(visual,segments,enabled=True):
        """Nunca entrega geometría vacía a VisPy: evita fallos de bounds()."""
        if not enabled or not segments:
            visual.visible=False;return
        visual.set_data(pos=np.asarray(segments,dtype=np.float32).reshape((-1,2)),connect="segments");visual.visible=True

    def _update_track_grid(self,group,rect,low,high,left,right):
        props=group["props"]
        signature=(float(rect.left),float(rect.right),float(rect.bottom),float(rect.top))
        if group.get("_grid_signature")==signature:return
        group["_grid_signature"]=signature
        interval=float(props.get("horizontal_grid_interval",0.0));hsub=int(props.get("horizontal_grid_subdivisions",0))
        if interval>0:
            first=math.ceil(low/interval)*interval;levels=np.arange(first,high+interval*.25,interval)
            if len(levels)>64:levels=np.linspace(low,high,11)
        else:levels=np.linspace(low,high,11)
        horizontal=[];horizontal_minor=[];hstyle=str(props.get("horizontal_grid_style","solid"))
        for level in levels:_append_grid_segment(horizontal,(left,float(level)),(right,float(level)),hstyle)
        if hsub:
            for start,end in zip(levels[:-1],levels[1:]):
                for level in np.linspace(start,end,hsub+2)[1:-1]:_append_grid_segment(horizontal_minor,(left,float(level)),(right,float(level)),hstyle)
        vertical=[];vertical_minor=[];vstyle=str(props.get("vertical_grid_style","solid"))
        for level,_label in group.get("vmajor_positions",[]):
            if left<level<right:_append_grid_segment(vertical,(level,low),(level,high),vstyle)
        for level in group.get("vminor_positions",[]):
            if left<level<right:_append_grid_segment(vertical_minor,(level,low),(level,high),vstyle)
        master=bool(props.get("grid_enabled",True));horizontal_enabled=master and bool(props.get("horizontal_grid_enabled",True));vertical_enabled=master and bool(props.get("vertical_grid_enabled",True))
        self._set_segment_visual(group["hgrid_visual"],horizontal,horizontal_enabled)
        self._set_segment_visual(group["hminor_grid_visual"],horizontal_minor,horizontal_enabled)
        self._set_segment_visual(group["vgrid_visual"],vertical,vertical_enabled)
        self._set_segment_visual(group["vminor_grid_visual"],vertical_minor,vertical_enabled)

    def _update_grid_header_labels(self,group):
        """Oculta sólo rótulos que colisionan; nunca elimina su línea de grid."""
        labels=group.get("grid_header_labels",[])
        if not labels:return
        try:
            transform=group["header"].scene.node_transform(self.canvas.scene)
            x0=float(transform.map((0.0,0.0))[0]);x1=float(transform.map((1.0,0.0))[0]);width=abs(x1-x0)
            if not np.isfinite(width) or width<=1:raise ValueError("Encabezado sin ancho")
            font=float(group.get("scale_font",6));padding=3.0
            lo_width=max(8.0,len(group.get("lo_scale_label",""))*font*.62);hi_width=max(8.0,len(group.get("hi_scale_label",""))*font*.62)
            occupied=[(-padding,lo_width+padding),(width-hi_width-padding,width+padding)]
            for record in sorted(labels,key=lambda item:item["position"]):
                center=float(record["position"])*width;label_width=max(8.0,len(record["text"])*float(record["font_size"])*.62)
                interval=(center-label_width/2-padding,center+label_width/2+padding);visible=not any(interval[1]>=start and interval[0]<=end for start,end in occupied)
                record["visual"].visible=visible
                if visible:occupied.append(interval)
        except (AttributeError,TypeError,ValueError):
            for record in labels:record["visual"].visible=False

    def _update_correlation_lines(self,*_args):
        for group in getattr(self,"well_groups",[]):
            rect=group["track"].camera.rect;low=min(float(rect.bottom),float(rect.top));high=max(float(rect.bottom),float(rect.top))
            left,right=sorted((float(rect.left),float(rect.right)));props=group["props"]
            self._update_track_grid(group,rect,low,high,left,right)
            self._update_grid_header_labels(group)
            border_segments=[(float(rect.left),low),(float(rect.right),low),
                             (float(rect.left),high),(float(rect.right),high)]
            group["border_visual"].set_data(pos=np.asarray(border_segments,dtype=np.float32),connect="segments")
            scale_limits=[]
            _append_grid_segment(scale_limits,(0.0,low),(0.0,high),"solid")
            _append_grid_segment(scale_limits,(1.0,low),(1.0,high),"solid")
            group["scale_limit_visual"].set_data(pos=np.asarray(scale_limits,dtype=np.float32),connect="segments",
                color=props.get("border_color","#6B7280"),width=max(.1,float(props.get("border_width",.7))))
            group["scale_limit_visual"].visible=bool(props.get("border_visible",True))
            group["separator_visual"].set_data(pos=np.asarray([(1.0,low),(1.0,high)],dtype=np.float32),
                color="#4B5563",width=max(1.4,float(props.get("border_width",.7))*1.8))
            group["separator_visual"].visible=not group.get("is_last_track",False)
            tick_segments=[(0.0,0.0),(0.0,.14),(1.0,0.0),(1.0,.14)]
            for position,_label in group.get("vmajor_positions",[]):
                if 0.0<position<1.0:tick_segments.extend(((float(position),0.0),(float(position),.055)))
            group["header_tick_visual"].set_data(pos=np.asarray(tick_segments,dtype=np.float32),connect="segments",
                color=props.get("border_color","#6B7280"),width=max(.5,float(props.get("border_width",.7))))
            group["header_tick_visual"].visible=True
            tick_texts=group.get("depth_tick_texts",[])
            if tick_texts:
                tick_levels=np.linspace(low,high,len(tick_texts));tick_segments=[]
                for text_visual,level in zip(tick_texts,tick_levels):
                    tick_segments.extend(((0.0,level),(.035,level)));text_visual.text=f"{level:g}";text_visual.pos=(.045,level);text_visual.visible=True
                group["depth_tick_line"].set_data(pos=np.asarray(tick_segments,dtype=np.float32),connect="segments")
        for record in getattr(self,"well_top_overlays",[]):
            group=record["group"];label=record.get("label");name=record["name"]
            if not group["grid"].visible or name not in group.get("top_depths",{}):
                record["line"].visible=False
                if label is not None:label.visible=False
                continue
            depth=float(group["top_depths"][name]);rect=group["track"].camera.rect
            visible=self.project.show_tops and min(rect.bottom,rect.top)<=depth<=max(rect.bottom,rect.top)
            if not visible:
                record["line"].visible=False
                if label is not None:label.visible=False
                continue
            record["line"].set_data(pos=np.asarray([(0.0,depth),(1.0,depth)],dtype=np.float32));record["line"].visible=True
            if label is not None:label.pos=(.985,depth);label.visible=True
        for record in getattr(self,"correlation_overlays",[]):
            if not self.project.show_correlation_lines:
                record["line"].visible=False;continue
            left_tracks=[group for group in record.get("left_tracks",[]) if group["grid"].visible]
            right_tracks=[group for group in record.get("right_tracks",[]) if group["grid"].visible]
            if not left_tracks or not right_tracks:record["line"].visible=False;continue
            left=left_tracks[-1];right=right_tracks[0];name=record["name"]
            gap=record.get("gap")
            if not gap or not gap["widget"].visible:record["line"].visible=False;continue
            if name not in left.get("top_depths",{}) or name not in right.get("top_depths",{}):
                record["line"].visible=False;continue
            left_depth=float(left["top_depths"][name]);right_depth=float(right["top_depths"][name])
            left_rect=left["track"].camera.rect;right_rect=right["track"].camera.rect
            left_visible=min(left_rect.bottom,left_rect.top)<=left_depth<=max(left_rect.bottom,left_rect.top)
            right_visible=min(right_rect.bottom,right_rect.top)<=right_depth<=max(right_rect.bottom,right_rect.top)
            if not (left_visible and right_visible):record["line"].visible=False;continue
            try:
                # Cada segmento vive dentro del ViewBox de su separación. Así
                # ningún fondo de gap puede cubrirlo, incluso si la distancia
                # proporcional entre los dos primeros pozos es grande.
                points=np.asarray([(0.0,left_depth),(1.0,right_depth)],dtype=np.float32)
                if not np.isfinite(points).all():raise ValueError("Coordenadas de correlación no finitas")
                record["line"].set_data(pos=points);record["line"].visible=True
            except (AttributeError,TypeError,ValueError):record["line"].visible=False
        self.canvas.update()

    def _set_top_edit_enabled(self,enabled):
        self.top_edit_enabled=bool(enabled)
        if enabled:self._cancel_assisted_correlation()

    def _set_correlation_lines_visible(self,visible):
        visible=bool(visible)
        if self.project.show_correlation_lines==visible:
            self._update_correlation_lines();QTimer.singleShot(0,self._update_correlation_lines);return
        self.project.show_correlation_lines=visible
        self._update_correlation_lines();QTimer.singleShot(0,self._update_correlation_lines);self._notify_project_changed()

    def _nearest_top(self,group,pos,tolerance=10):
        if not group.get("top_depths"):return None
        inverse=self.canvas.scene.node_transform(group["track"].scene).inverse
        candidates=[]
        for name,depth in group["top_depths"].items():
            pixel=inverse.map((.5,float(depth)));candidates.append((abs(float(pixel[1])-float(pos[1])),name,float(depth)))
        distance,name,depth=min(candidates)
        return (name,depth) if distance<=tolerance else None

    def _move_top_visual(self,group,name,depth):
        for target in self.well_groups:
            if str(target["well"].uwi)!=str(group["well"].uwi):continue
            target["top_depths"][name]=float(depth)
        self._update_correlation_lines()

    def _add_or_update_top_visual(self,group,name,depth):
        if name in group.get("top_depths",{}):self._move_top_visual(group,name,depth);return
        if name not in self.top_names:self.top_names.append(name)
        for target in self.well_groups:
            if str(target["well"].uwi)==str(group["well"].uwi):target["top_depths"][name]=float(depth)

    def _rebuild_correlation_overlay(self):
        for record in getattr(self,"well_top_overlays",[]):
            record["line"].parent=None
            if record.get("label") is not None:record["label"].parent=None
        for record in getattr(self,"correlation_overlays",[]):record["line"].parent=None
        self._build_well_top_overlay(self.scene,self.project,self.top_names,self.default_top_colors)
        self._build_correlation_overlay(self.scene,self.project,self.top_names,self.default_top_colors)
        self._update_correlation_lines()

    def _notify_project_changed(self):
        self.project_changed=True
        if self.change_callback:self.change_callback()

    def _configure_assisted_correlation(self):
        groups=[group for group in self.well_groups if group["well"].tops]
        if not groups:QMessageBox.information(self,"Correlación asistida","No existen cimas disponibles.");return
        labels=[f'{g["well"].name} · {g["well"].uwi} · {g.get("track_key","")} · {g["source"]}' for g in groups]
        selected,ok=QInputDialog.getItem(self,"Correlación asistida GPU","Pozo de origen:",labels,0,False)
        if not ok:return
        source=groups[labels.index(selected)];tops=sorted(source["well"].tops)
        top_name,ok=QInputDialog.getItem(self,"Correlación asistida GPU","Cima de origen:",tops,0,False)
        if not ok:return
        curve=source["source"]
        above,ok=QInputDialog.getDouble(self,"Intervalo patrón","Distancia por arriba:",100,0,100000,2)
        if not ok:return
        below,ok=QInputDialog.getDouble(self,"Intervalo patrón","Distancia por abajo:",100,0,100000,2)
        if not ok:return
        top=float(source["well"].tops[top_name]);raw_depth=source["raw_depth"];raw_values=source["raw_values"]
        mask=np.isfinite(raw_depth)&np.isfinite(raw_values)&(raw_depth>=top-above)&(raw_depth<=top+below)
        if mask.sum()<2:QMessageBox.warning(self,"Intervalo no válido","El intervalo no contiene suficientes datos.");return
        settings=self.project.effective_curve_settings(source["well"].uwi,curve,source.get("track_key")) or {"xlim":[np.nanmin(raw_values[mask]),np.nanmax(raw_values[mask])]}
        sample=raw_values[mask].astype(float);normalized=_axis_positions(sample,settings)
        display_top=top-(float(source["well"].tops.get(self.datum_top,0)) if self.datum_top else 0)
        self.assisted_state={"source":source,"top_name":top_name,"curve":curve,"source_md":top,
            "display_top":display_top,"x":normalized,"offsets":raw_depth[mask]-top,"interval":(above,below)}
        self.edit_tops_button.setChecked(False);self._draw_ghost_at_source()

    def _draw_ghost_at_source(self):
        state=self.assisted_state
        if not state:return
        source=state["source"];inverse=self.canvas.scene.node_transform(source["track"].scene).inverse
        points=np.column_stack((state["x"],state["display_top"]+state["offsets"]))
        canvas_points=inverse.map(points)[:,:2];self.ghost_line.set_data(pos=np.asarray(canvas_points,dtype=np.float32));self.ghost_line.visible=True
        origin=inverse.map((.02,state["display_top"]))[:2];self.ghost_label.text=f'{state["top_name"]} · ORIGEN';self.ghost_label.pos=origin;self.ghost_label.visible=True

    def _move_ghost(self,pos):
        state=self.assisted_state
        if not state:return
        source=state["source"];inverse=self.canvas.scene.node_transform(source["track"].scene).inverse
        points=np.column_stack((state["x"],state["display_top"]+state["offsets"]));canvas_points=inverse.map(points)[:,:2]
        origin=inverse.map((.5,state["display_top"]))[:2];delta=np.asarray(pos,float)-np.asarray(origin,float)
        canvas_points+=delta;self.ghost_line.set_data(pos=np.asarray(canvas_points,dtype=np.float32));self.ghost_line.visible=True
        self.ghost_label.text=f'{state["top_name"]} · EN TRÁNSITO';self.ghost_label.pos=np.asarray(pos,float)+(8,-8);self.ghost_label.visible=True

    def _commit_assisted_correlation(self,hit):
        state=self.assisted_state;target=hit[0]
        if not state or target is state["source"]:return
        shown=target["display_depth"];valid=np.flatnonzero(np.isfinite(shown));sample=int(valid[np.argmin(np.abs(shown[valid]-hit[2]))])
        target_md=float(target["raw_depth"][sample])
        answer=QMessageBox.question(self,"Confirmar cima interpretada",
            f'Crear "{state["top_name"]}" en {target["well"].name} a MD {target_md:.2f}?',QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)
        if answer!=QMessageBox.Yes:return
        self.project.transfer_top(state["source"]["well"].uwi,target["well"].uwi,state["top_name"],target_md,
            state["curve"],state["interval"])
        display=target_md-(float(target["well"].tops.get(self.datum_top,0)) if self.datum_top else 0)
        self._add_or_update_top_visual(target,state["top_name"],display);self._notify_project_changed()
        self._cancel_assisted_correlation();self._rebuild_correlation_overlay()

    def _cancel_assisted_correlation(self):
        self.assisted_state=None
        if hasattr(self,"ghost_line"):self.ghost_line.visible=False;self.ghost_label.visible=False

    def _cancel_gpu_interaction(self):
        self._cancel_assisted_correlation();self._top_drag=None;self._zoom_drag=None;self._pan_drag=None
        self.cursor_pinned=False;self.pinned_cursor_hit=None;self._clear_cursor_readout()
        if hasattr(self,"zoom_selection"):self.zoom_selection.visible=False

    def _clear_cursor_readout(self):
        for group in getattr(self,"well_groups",[]):group["cursor_line"].visible=False;group["cursor_text"].visible=False

    @staticmethod
    def _control_pressed(event):
        return any("CONTROL" in str(value).upper() or "CTRL" in str(value).upper() for value in (getattr(event,"modifiers",()) or ()))

    def _update_cursor_readout(self,hit,pinned=False):
        if not hit:return
        hovered,x_position,display_depth=hit
        for group in self.well_groups:
            shown=group["display_depth"];valid=np.flatnonzero(np.isfinite(shown))
            if not valid.size:continue
            sample=int(valid[np.argmin(np.abs(shown[valid]-display_depth))]);snapped=float(shown[sample])
            group["cursor_line"].set_data(pos=np.asarray([[0,snapped],[1,snapped]],dtype=np.float32));group["cursor_line"].visible=True;group["cursor_text"].visible=False
        shown=hovered["display_depth"];valid=np.flatnonzero(np.isfinite(shown))
        if not valid.size:return
        sample=int(valid[np.argmin(np.abs(shown[valid]-display_depth))]);snapped=float(shown[sample]);raw_md=float(hovered["raw_depth"][sample])
        depth_unit=str(getattr(hovered["well"],"depth_unit","") or "");lines=[f'MD {raw_md:g} {depth_unit}'.rstrip()]
        if self.datum_top:lines.append(f'Relativa {snapped:g} {depth_unit}'.rstrip())
        for source,data in hovered.get("curve_data",{}).items():
            values=data.get("values")
            if values is None or sample>=len(values):continue
            value=float(values[sample]);value_text="—" if not np.isfinite(value) else f"{value:g}";unit=data.get("unit","")
            lines.append(f'{source} {value_text} {unit}'.rstrip())
        if pinned:lines[0]="● FIJO · "+lines[0]
        # Algunas versiones estables de VisPy no permiten modificar anchor_x/
        # anchor_y después de crear TextVisual. Se conservan los anclajes de
        # construcción y solo se actualizan texto y posición.
        label=hovered["cursor_text"];label.text="\n".join(lines);label.pos=(.03,snapped);label.visible=True

    def _safe_update_cursor_readout(self,hit,pinned=False):
        try:self._update_cursor_readout(hit,pinned);return True
        except (AttributeError,IndexError,TypeError,ValueError,RuntimeError):self._clear_cursor_readout();return False

    def _track_at(self,pos):
        for group in getattr(self,"well_groups",[]):
            try:
                transform=self.canvas.scene.node_transform(group["track"].scene)
                point=transform.map(pos);x=float(point[0]);y=float(point[1])
            except (AttributeError,TypeError,ValueError):continue
            rect=group["track"].camera.rect
            ymin=min(float(rect.bottom),float(rect.top));ymax=max(float(rect.bottom),float(rect.top))
            if -.08<=x<=1.08 and ymin<=y<=ymax:
                self.active_track_group=group
                return group,x,y
        return None

    def _set_zoom_mode(self,mode):
        if mode not in {"interval","area"}:return
        self.zoom_mode=mode;self._zoom_drag=None
        if hasattr(self,"zoom_selection"):self.zoom_selection.visible=False
        self.active_mode_label.setText("Modo activo: "+("Zoom areal" if mode=="area" else "Zoom por intervalo"))

    def _activate_zoom_mode(self,mode):
        if mode not in {"interval","area"}:return
        button=self.area_zoom_button if mode=="area" else self.interval_zoom_button
        button.setChecked(True);self._set_zoom_mode(mode)

    def _on_mouse_press(self,event):
        hit=self._track_at(event.pos)
        if event.button==1 and hit and self._control_pressed(event) and not self.assisted_state and not self.top_edit_enabled:
            if self.cursor_pinned:self.cursor_pinned=False;self.pinned_cursor_hit=None;self._clear_cursor_readout()
            else:self.cursor_pinned=True;self.pinned_cursor_hit=hit;self._safe_update_cursor_readout(hit,True)
            event.handled=True;return
        if event.button==1 and self.assisted_state and hit:
            self._commit_assisted_correlation(hit);event.handled=True;return
        if event.button==1 and self.top_edit_enabled and hit:
            nearest=self._nearest_top(hit[0],event.pos)
            if nearest:
                name,depth=nearest
                if name==self.datum_top:
                    QMessageBox.information(self,"Cima protegida","La cima usada como datum no puede editarse desde esta vista.");return
                self._top_drag={"group":hit[0],"name":name,"original":depth,"proposed":depth};event.handled=True;return
        if event.button==1 and hit:
            self._zoom_drag={"start":np.asarray(event.pos,dtype=float),"start_hit":hit}
            self.zoom_selection.center=event.pos;self.zoom_selection.width=1;self.zoom_selection.height=1;self.zoom_selection.visible=True
            event.handled=True
        elif event.button==3 and hit:
            self._pan_drag={"start":np.asarray(event.pos,dtype=float),"start_depth":hit[2],
                "ranges":[(float(g["track"].camera.rect.left),float(g["track"].camera.rect.right),
                           float(g["track"].camera.rect.bottom),float(g["track"].camera.rect.top)) for g in self.well_groups]}
            event.handled=True

    def _on_mouse_release(self,event):
        if event.button==1 and self._top_drag:
            state=self._top_drag;self._top_drag=None;group=state["group"];name=state["name"]
            shown=group["display_depth"];valid=np.flatnonzero(np.isfinite(shown));sample=int(valid[np.argmin(np.abs(shown[valid]-state["proposed"]))])
            target_md=float(group["raw_depth"][sample]);display=float(shown[sample])
            answer=QMessageBox.question(self,"Confirmar ajuste de cima",
                f'{group["well"].name} — {name}\nMD propuesta: {target_md:.2f}\n\n¿Aplicar este ajuste?',QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)
            if answer==QMessageBox.Yes:
                self.project.adjust_top(group["well"].uwi,name,target_md,"gpu_cursor_adjustment")
                self._move_top_visual(group,name,display);self._notify_project_changed();self._rebuild_correlation_overlay()
            else:self._move_top_visual(group,name,state["original"])
            event.handled=True;return
        if event.button==1 and self._zoom_drag:
            start=self._zoom_drag["start"];end=np.asarray(event.pos,dtype=float);self._zoom_drag=None;self.zoom_selection.visible=False
            if np.linalg.norm(end-start)<6:return
            if self.zoom_mode=="interval":self._apply_interval_zoom(start,end)
            else:self._apply_area_zoom(start,end)
            event.handled=True
        elif event.button==3 and self._pan_drag:
            self._pan_drag=None;event.handled=True

    def _on_mouse_wheel(self,event):
        hit=self._track_at(event.pos)
        if not hit:return
        center=hit[2];delta=float(event.delta[1]);factor=.82**delta
        for group in self.well_groups:
            rect=group["track"].camera.rect;low=min(rect.bottom,rect.top);high=max(rect.bottom,rect.top)
            new_low=center+(low-center)*factor;new_high=center+(high-center)*factor
            self._set_exact_camera_rect(group["track"].camera,new_low,new_high)
        self._update_correlation_lines();event.handled=True

    def _on_key_press(self,event):
        key=str(event.key).upper()
        if key=="I":self._activate_zoom_mode("interval")
        elif key=="A":self._activate_zoom_mode("area")
        elif key=="R":self._reset_gpu_zoom()

    def _apply_interval_zoom(self,start,end):
        first=self._track_at(start);last=self._track_at(end)
        if not first or not last:return
        low,high=sorted((first[2],last[2]))
        if high-low<=0:return
        for group in self.well_groups:self._set_exact_camera_rect(group["track"].camera,low,high)
        self._update_correlation_lines()

    def _apply_area_zoom(self,start,end):
        x0,x1=sorted((float(start[0]),float(end[0])));y0,y1=sorted((float(start[1]),float(end[1])))
        selected=[];depths=[]
        for group in self.well_groups:
            transform=self.canvas.scene.node_transform(group["track"].scene);inverse=transform.inverse
            rect=group["track"].camera.rect;mid=(float(rect.bottom)+float(rect.top))/2
            px0=float(inverse.map((0,mid))[0]);px1=float(inverse.map((1,mid))[0]);left,right=sorted((px0,px1))
            overlap=max(0.0,min(right,x1)-max(left,x0));minimum_overlap=max(3.0,(right-left)*.02)
            if overlap>=minimum_overlap:
                selected.append(group)
                p0=transform.map((max(x0,left),y0));p1=transform.map((min(x1,right),y1))
                depths.extend((float(p0[1]),float(p1[1])))
        if not selected or not depths:return
        low,high=min(depths),max(depths)
        if high-low<=0:return
        # El intervalo marcado debe ocupar el 94 % del alto útil del ViewBox.
        # El margen se calcula sobre ambos extremos, no como un porcentaje
        # arbitrario que cambie la magnificación percibida.
        focus_fraction=.94
        depth_padding=(high-low)*(1.0/focus_fraction-1.0)/2.0;low-=depth_padding;high+=depth_padding
        selected_ids={id(group) for group in selected};selected_uwis={str(group["well"].uwi) for group in selected}
        well_weights={uwi:sum(float(group["props"].get("width",1.0)) for group in selected if str(group["well"].uwi)==uwi) for uwi in selected_uwis}
        for group in self.well_groups:
            active=id(group) in selected_ids;group["grid"].visible=active
            if active:
                track_weight=float(group["props"].get("width",1.0));group["grid"].width_max=None;group["grid"].stretch=(max(track_weight,.001),1)
            else:
                group["grid"].width_min=0;group["grid"].width_max=0;group["grid"].stretch=(.001,1)
            if active:
                # Igual que Matplotlib: el zoom areal no cambia el eje X de la
                # curva. El encabezado, la retícula y el track conservan 0..1.
                self._set_exact_camera_rect(group["track"].camera,low,high)
        for item in getattr(self,"area_layout_items",[]):
            active=item["kind"]=="well" and item.get("uwi") in selected_uwis;widget=item["widget"]
            widget.visible=active
            if not active:
                widget.width_min=0;widget.width_max=0;widget.stretch=(.001,1)
        self._area_focus_state={"selected_ids":selected_ids,"selected_uwis":selected_uwis,"well_weights":well_weights}
        self._area_focus_active=True;self.active_mode_label.setText(f"Modo activo: Zoom areal · {len(selected)} track(s) en enfoque")
        self._refresh_area_focus_geometry()
        # El segundo pase ocurre cuando el solver de Grid ya retiró las
        # columnas ocultas. Es el que garantiza el 94 % real y el centrado.
        QTimer.singleShot(0,self._refresh_area_focus_geometry);QTimer.singleShot(60,self._refresh_area_focus_geometry)

    def _refresh_area_focus_geometry(self):
        """Mantiene la selección centrada al 94 % tras layout/resize."""
        state=getattr(self,"_area_focus_state",None)
        if not getattr(self,"_area_focus_active",False) or not state:return
        canvas_width=max(320.0,float(self.canvas.size[0]));focus_width=canvas_width*.94
        self.root_grid.margin=max(4.0,canvas_width*.03)
        total_weight=max(sum(state["well_weights"].values()),.1)
        for group in self.well_groups:
            if id(group) not in state["selected_ids"]:continue
            weight=float(group["props"].get("width",1.0));assigned=focus_width*weight/total_weight
            group["grid"].width_min=assigned;group["grid"].width_max=assigned
        # Los setters de tamaño actualizan las restricciones, pero Grid puede
        # conservar la solución anterior hasta otro resize. Forzamos aquí la
        # resolución desde el nivel raíz y luego en el pozo activo.
        layouts=[self.root_grid]
        layouts.extend(item["widget"] for item in getattr(self,"area_layout_items",[])
                       if item["kind"]=="well" and item.get("uwi") in state["selected_uwis"])
        for layout in layouts:
            recreate=getattr(layout,"_recreate_solver",None)
            update=getattr(layout,"_update_child_widget_dim",None)
            if callable(recreate):recreate()
            if callable(update):update()
        self.canvas.update();self._update_correlation_lines()

    def _reset_gpu_zoom(self):
        if not hasattr(self,"initial_depth_range"):return
        low,high=self.initial_depth_range
        for group in self.well_groups:
            group["grid"].visible=True;group["grid"].width_min=int(group.get("base_width_min",0));group["grid"].width_max=None;group["grid"].stretch=group.get("base_stretch",(1,1))
            self._set_exact_camera_rect(group["track"].camera,low,high)
        for item in getattr(self,"area_layout_items",[]):
            widget=item["widget"];widget.visible=True
            if item["kind"]=="gap":widget.width_min=item.get("base_width_min",44);widget.width_max=None;widget.stretch=item["stretch"]
        self.root_grid.margin=4
        self._area_focus_active=False;self._area_focus_state=None;self.active_mode_label.setText("Modo activo: "+("Zoom areal" if self.zoom_mode=="area" else "Zoom por intervalo"))
        self.zoom_selection.visible=False;self._zoom_drag=None;self._pan_drag=None
        self._refresh_full_layout_geometry()
        # La primera resolución libera los anchos fijos del modo enfocado; la
        # segunda se ejecuta cuando todos los widgets volvieron a ser visibles.
        QTimer.singleShot(0,self._refresh_full_layout_geometry);QTimer.singleShot(80,self._refresh_full_layout_geometry)

    def _refresh_full_layout_geometry(self):
        """Fuerza la geometría original completa después de abandonar el foco."""
        if getattr(self,"_area_focus_active",False):return
        self._resolve_grid_geometry()
        self.canvas.update();self._update_correlation_lines()

    def _on_mouse_move(self,event):
        if self._top_drag:
            hit=self._track_at(event.pos)
            if hit and hit[0] is self._top_drag["group"]:
                self._top_drag["proposed"]=hit[2];self._move_top_visual(hit[0],self._top_drag["name"],hit[2])
            event.handled=True;return
        if self.assisted_state:
            self._move_ghost(event.pos);event.handled=True;return
        if self._zoom_drag:
            start=self._zoom_drag["start"];end=np.asarray(event.pos,dtype=float)
            visual_start=start.copy();visual_end=end.copy()
            if self.zoom_mode=="interval":
                group=self._zoom_drag["start_hit"][0];depth=self._zoom_drag["start_hit"][2]
                inverse=self.canvas.scene.node_transform(group["track"].scene).inverse
                visual_start[0]=float(inverse.map((0,depth))[0]);visual_end[0]=float(inverse.map((1,depth))[0])
            self.zoom_selection.center=((visual_start[0]+visual_end[0])/2,(visual_start[1]+visual_end[1])/2)
            self.zoom_selection.width=max(abs(visual_end[0]-visual_start[0]),2);self.zoom_selection.height=max(abs(visual_end[1]-visual_start[1]),2)
            event.handled=True;return
        if self._pan_drag:
            hit=self._track_at(event.pos)
            if hit:
                delta=(self._pan_drag["start_depth"]-hit[2])*.35
                for group,saved in zip(self.well_groups,self._pan_drag["ranges"]):
                    low,high=sorted(saved[2:])
                    self._set_exact_camera_rect(group["track"].camera,low+delta,high+delta)
                self._update_correlation_lines()
            event.handled=True;return
        if not getattr(self,"well_groups",None) or event.pos is None:return
        if self.cursor_pinned:
            if self.pinned_cursor_hit:self._safe_update_cursor_readout(self.pinned_cursor_hit,True)
            return
        hit=self._track_at(event.pos);hovered=hit[0] if hit else None;display_depth=hit[2] if hit else None
        if hovered is None:
            self._clear_cursor_readout()
            return
        self._safe_update_cursor_readout(hit,False)
