from __future__ import annotations

from dataclasses import dataclass
from importlib.util import find_spec


@dataclass(frozen=True)
class BackendStatus:
    key: str
    available: bool
    label: str
    detail: str


def probe_vispy() -> BackendStatus:
    """Comprueba VisPy sin crear contexto OpenGL ni afectar el visor estable."""
    available = find_spec("vispy") is not None
    detail = (
        "VisPy está instalado. La compatibilidad real de OpenGL se verifica al abrir la vista GPU."
        if available else
        "VisPy no está instalado. Ejecute nuevamente Instalar.ps1 para agregar el motor GPU."
    )
    return BackendStatus("vispy", available, "VisPy / OpenGL (experimental)", detail)
