from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D
from matplotlib.transforms import blended_transform_factory
import numpy as np
from PySide6.QtCore import Qt,QTimer

from .models import CorrelationProject
from .renderer import draw_correlation_figure, update_correlation_artists, apply_area_viewport


class CorrelationCanvas(FigureCanvasQTAgg):
    def __init__(self, parent=None):
        self.figure = Figure(figsize=(12.5, 7.8), facecolor="white")
        super().__init__(self.figure)
        self.setParent(parent)
        self.interaction_mode = "interval"
        self._drag = None
        self._selection_patch = None
        self._cursor_artists = []
        self._cursor_kind = None
        self._overlay_background = None
        self._data_cursor_artists = []
        self._interval_picks = []
        self.data_cursor_enabled = True
        self.data_cursor_locked = False
        self.message_callback = None
        self._last_draw = None
        self.assisted_correlation = None
        self.correlation_callback = None
        self.top_edit_enabled = False
        self.protect_datum_top = True
        self.top_edit_state = None
        self.top_edit_callback = None
        self.header_edit_callback = None
        self._area_zoom_active = False
        self._area_viewport = (0.0,1.0,0.0,1.0)
        self._fast_navigation=False
        self._navigation_restore_timer=QTimer(self);self._navigation_restore_timer.setSingleShot(True);self._navigation_restore_timer.timeout.connect(self._end_fast_navigation)
        self.mpl_connect("button_press_event", self._on_press)
        self.mpl_connect("motion_notify_event", self._on_motion)
        self.mpl_connect("button_release_event", self._on_release)
        self.mpl_connect("scroll_event", self._on_scroll)
        self.mpl_connect("key_press_event", self._on_key_press)
        self.mpl_connect("draw_event", self._capture_overlay_background)

    def draw_project(self, project: CorrelationProject, curve_name: str = "GR", datum_top: str | None = None):
        # A redraw invalidates every Matplotlib artist from the previous figure.
        # Clear the interaction first so a later drag never retains stale artists.
        if self.assisted_correlation:self.cancel_assisted_correlation(redraw=False)
        if self.top_edit_state:self._clear_top_edit(redraw=False)
        self._clear_cursor();self._clear_data_cursor()
        self._last_draw=(project,curve_name,datum_top)
        self._navigation_restore_timer.stop();self._fast_navigation=False
        self._overlay_background=None
        draw_correlation_figure(self.figure, project, curve_name, datum_top)
        self._area_zoom_active=False;self._area_viewport=(0.0,1.0,0.0,1.0)
        self.draw_idle()

    def set_interaction_mode(self, mode: str):
        if mode not in {"interval","area"}:raise ValueError("Modo de zoom no válido.")
        if mode=="interval" and self._area_zoom_active and self._last_draw:self.draw_project(*self._last_draw)
        self.interaction_mode=mode;self._interval_picks=[];self._clear_cursor();self._cancel_selection()

    def set_top_edit_enabled(self,enabled: bool):
        if enabled and self.assisted_correlation:self.cancel_assisted_correlation(redraw=False)
        self.top_edit_enabled=bool(enabled)
        if not enabled:self._clear_top_edit()
        self.setCursor(Qt.SizeVerCursor if enabled else Qt.ArrowCursor)

    def _top_at(self,group,event,tolerance_pixels=9):
        info=getattr(self.figure,"_hmd_group_info",{}).get(group[0]) if group else None
        if not info:return None
        well=info["well"];datum=self._last_draw[2] if self._last_draw else None;candidates=[]
        for name,md in well.tops.items():
            display=float(md)-(well.tops.get(datum,0.0) if datum else 0.0)
            pixel_y=group[0].transData.transform((0,display))[1]
            candidates.append((abs(pixel_y-event.y),name,float(md),display))
        if not candidates:return None
        distance,name,md,display=min(candidates)
        return (info,name,md,display) if distance<=tolerance_pixels else None

    def _clear_top_edit(self,redraw=True):
        state=self.top_edit_state
        if state:
            for artist in state.get("artists",[]):
                try:artist.remove()
                except (ValueError,AttributeError,NotImplementedError):
                    try:artist.set_visible(False)
                    except (AttributeError,RuntimeError):pass
        self.top_edit_state=None
        if redraw:self.draw_idle()

    def _draw_top_edit_preview(self,display_depth,proposed_md):
        state=self.top_edit_state
        if not state:return
        for artist in state.get("artists",[]):
            try:artist.remove()
            except (ValueError,AttributeError,NotImplementedError):
                try:artist.set_visible(False)
                except (AttributeError,RuntimeError):pass
        state["artists"]=[];groups=[]
        for group in getattr(self.figure,"_hmd_track_axis_groups",[]):
            info=getattr(self.figure,"_hmd_group_info",{}).get(group[0])
            if info and str(info["well"].uwi)==state["well_uwi"]:groups.append(group)
        datum=self._last_draw[2] if self._last_draw else None
        original_display=state["original_md"]-(state["well"].tops.get(datum,0.0) if datum else 0.0)
        for group in groups:
            state["artists"].append(group[0].axhline(original_display,color="#6b7280",lw=.8,ls=":",alpha=.85,zorder=48))
            state["artists"].append(group[0].axhline(display_depth,color="#db2777",lw=1.4,alpha=.95,zorder=49))
        if groups:
            axis=groups[-1][0];transform=blended_transform_factory(axis.transAxes,axis.transData)
            label=axis.text(.98,display_depth,f'{state["top_name"]}: {state["original_md"]:.2f} → {proposed_md:.2f}',
                            transform=transform,ha="right",va="bottom",fontsize=6,color="#be185d",zorder=52,
                            bbox=dict(facecolor="white",edgecolor="#db2777",alpha=.9,pad=1))
            state["artists"].append(label)
        state["proposed_md"]=float(proposed_md);state["proposed_display"]=float(display_depth);self.draw_idle()

    def begin_assisted_correlation(self, source_uwi, top_name, curve, interval_above, interval_below):
        project,_,datum=self._last_draw
        source=next(w for w in project.wells if str(w.uwi)==str(source_uwi))
        top=float(source.tops[top_name]);values=np.asarray(source.curves[curve],float);depth=np.asarray(source.depth,float)
        mask=np.isfinite(values)&np.isfinite(depth)&(depth>=top-float(interval_above))&(depth<=top+float(interval_below))
        if mask.sum()<2:raise ValueError("El intervalo seleccionado no contiene suficientes datos válidos.")
        settings=project.effective_curve_settings(source.uwi,curve) or {"xlim":[float(np.nanmin(values[mask])),float(np.nanmax(values[mask]))],"scale":"linear"}
        sample=values[mask].copy();lo,hi=map(float,settings.get("xlim",(np.nanmin(sample),np.nanmax(sample))))
        if settings.get("scale")=="log":
            sample=np.log10(np.where(sample>0,sample,np.nan));lo,hi=np.log10([lo,hi])
        normalized=(sample-lo)/(hi-lo if hi!=lo else 1.0)
        if settings.get("presentation")=="axis_inverted":normalized=1-normalized
        source_group=next((group for group in getattr(self.figure,"_hmd_track_axis_groups",[])
            if (info:=getattr(self.figure,"_hmd_group_info",{}).get(group[0]))
            and str(info["well"].uwi)==str(source.uwi) and curve in info.get("sources",[])),None)
        if source_group is None:raise ValueError(f"La curva {curve} no está visible en un track del pozo de origen.")
        source_display_top=top-(source.tops.get(datum,0.0) if datum else 0.0)
        self.assisted_correlation={"source_uwi":str(source.uwi),"source_index":project.wells.index(source),"source_depth":top,"top_name":top_name,"curve":curve,
            "offsets":depth[mask]-top,"x":normalized,"interval":(-float(interval_above),float(interval_below)),
            "dragging":False,"artists":[],"target":None,"datum":datum,"source_group":source_group,
            "source_display_top":source_display_top}
        self.setCursor(Qt.CrossCursor)
        self._draw_ghost(source_group,source_display_top,valid_target=False)
        self._emit(f"Correlación asistida: arrastre {top_name} desde {source.name} hacia un pozo vecino. Esc cancela.")

    def cancel_assisted_correlation(self,redraw=True):
        self._clear_ghost_artists()
        self.assisted_correlation=None;self.unsetCursor()
        if redraw:self.draw_idle()

    def _clear_ghost_artists(self):
        state=self.assisted_correlation
        if not state:return
        for artist in state.get("artists",[]):
            try:artist.remove()
            except (ValueError,AttributeError,NotImplementedError):
                # Figure.clear() may already have detached the artist and reset
                # its removal callback. Hiding it is safe and keeps cleanup idempotent.
                try:artist.set_visible(False)
                except (AttributeError,RuntimeError):pass
        state["artists"]=[]

    def _draw_ghost(self,group,anchor,valid_target=True):
        state=self.assisted_correlation;info=getattr(self.figure,"_hmd_group_info",{}).get(group[0])
        if not state or not info:return
        self._clear_ghost_artists()
        transform=blended_transform_factory(group[0].transAxes,group[0].transData)
        line=Line2D(state["x"],anchor+state["offsets"],transform=transform,color="#7c3aed",lw=1.6,
                    alpha=.58,zorder=50,clip_on=True)
        marker=group[0].axhline(anchor,color="#7c3aed",lw=1.1,ls="--",alpha=.9,zorder=51)
        raw=np.asarray(info["raw_depth"],float);shown=np.asarray(info["depth"],float);valid=np.flatnonzero(np.isfinite(shown))
        target_md=float(raw[valid[np.argmin(np.abs(shown[valid]-anchor))]])
        delta=target_md-state["source_depth"]
        label_text=f'{state["top_name"]} · ORIGEN' if not valid_target else f'{state["top_name"]}  ΔMD {delta:+.2f}'
        label=group[0].text(.02,anchor,label_text,transform=transform,
                           ha="left",va="bottom",fontsize=6,color="#6d28d9",zorder=52,
                           bbox=dict(facecolor="white",edgecolor="#7c3aed",alpha=.85,pad=1))
        group[0].add_line(line);state["artists"]=[line,marker,label]
        state["target"]=(group,anchor) if valid_target else None;self.draw_idle()

    def _draw_free_ghost(self,event):
        """Keep the source pattern visible while it crosses gaps between wells."""
        state=self.assisted_correlation
        if not state:return
        self._clear_ghost_artists();state["target"]=None
        source_axis=state["source_group"][0]
        transform=blended_transform_factory(source_axis.transAxes,source_axis.transData)
        points=transform.transform(np.column_stack((state["x"],state["source_display_top"]+state["offsets"])))
        origin=transform.transform((.5,state["source_display_top"]))
        points[:,0]+=event.x-origin[0];points[:,1]+=event.y-origin[1]
        figure_points=self.figure.transFigure.inverted().transform(points)
        fx,fy=self.figure.transFigure.inverted().transform((event.x,event.y))
        line=Line2D(figure_points[:,0],figure_points[:,1],transform=self.figure.transFigure,
                    color="#7c3aed",lw=1.6,alpha=.58,zorder=55,clip_on=False)
        half_width=source_axis.bbox.width/(2*max(float(self.figure.bbox.width),1.0))
        marker=Line2D([fx-half_width,fx+half_width],[fy,fy],transform=self.figure.transFigure,
                      color="#7c3aed",lw=1.1,ls="--",alpha=.9,zorder=56,clip_on=False)
        label=self.figure.text(fx-half_width,fy,f'{state["top_name"]} · EN TRÁNSITO',ha="left",va="bottom",
                               fontsize=6,color="#6d28d9",zorder=57,
                               bbox=dict(facecolor="white",edgecolor="#7c3aed",alpha=.85,pad=1))
        self.figure.add_artist(line);self.figure.add_artist(marker);state["artists"]=[line,marker,label];self.draw_idle()

    def reset_zoom(self):
        if self._last_draw:self.draw_project(*self._last_draw)

    def capture_navigation_state(self):
        """Capture interval and area zoom without retaining obsolete artists."""
        return {"axes":[(axis.get_position().bounds,axis.get_xlim(),axis.get_ylim()) for axis in self.figure.axes],
                "texts":[text.get_position() for text in self.figure.texts],
                "arrows":[tuple(arrow._posA_posB) for arrow in getattr(self.figure,"_hmd_free_arrows",[])],
                "area_zoom_active":self._area_zoom_active,"area_viewport":self._area_viewport}

    def restore_navigation_state(self,state):
        if not state:return
        for axis,saved in zip(self.figure.axes,state.get("axes",[])):
            bounds,xlim,ylim=saved;axis.set_position(bounds);axis.set_xlim(xlim);axis.set_ylim(ylim)
        for label,position in zip(self.figure.texts,state.get("texts",[])):label.set_position(position)
        for arrow,positions in zip(getattr(self.figure,"_hmd_free_arrows",[]),state.get("arrows",[])):
            arrow.set_positions(*positions)
        self._area_zoom_active=bool(state.get("area_zoom_active",False))
        self._area_viewport=tuple(state.get("area_viewport",(0.0,1.0,0.0,1.0)))
        update_correlation_artists(self.figure);self.draw_idle()

    def _pan_area_by(self,delta_original):
        """Move the complete area viewport without separating figure elements."""
        x0,x1,y0,y1=self._area_viewport;span=y1-y0
        if not self._area_zoom_active or span>=1.0-1e-12:return 0.0
        target=float(np.clip(y0+delta_original,0.0,1.0-span));actual=target-y0
        if abs(actual)<1e-12:return 0.0
        relative=actual/span
        apply_area_viewport(self.figure,0.0,1.0,relative,1.0+relative)
        self._area_viewport=(x0,x1,target,target+span)
        return actual

    def set_data_cursor_enabled(self,enabled: bool):
        self.data_cursor_enabled=bool(enabled);self.data_cursor_locked=False
        if not enabled:self._clear_data_cursor();self.draw_idle()

    def _group_at(self,event):
        for group in getattr(self.figure,"_hmd_track_axis_groups",[]):
            if group and group[0].bbox.contains(event.x,event.y):return group
        return None

    def _inside_depth_workspace(self,event):
        axes=self._all_depth_axes()
        if not axes or event.x is None or event.y is None:return False
        return (min(axis.bbox.x0 for axis in axes)<=event.x<=max(axis.bbox.x1 for axis in axes)
                and min(axis.bbox.y0 for axis in axes)<=event.y<=max(axis.bbox.y1 for axis in axes))

    def _all_depth_axes(self):return getattr(self.figure,"_hmd_depth_axes",[])

    def _depth_bounds(self):
        arrays=[]
        for values in getattr(self.figure,"_hmd_axis_depths",{}).values():
            values=np.asarray(values,float);valid=values[np.isfinite(values)]
            if valid.size:arrays.append(valid)
        if not arrays:return None
        return min(float(values.min()) for values in arrays),max(float(values.max()) for values in arrays)

    def _bounded_depth_shift(self,requested,reference_limits):
        bounds=self._depth_bounds()
        if bounds is None:return float(requested)
        minimum,maximum=bounds;visible_min=min(reference_limits);visible_max=max(reference_limits)
        lower=minimum-visible_min;upper=maximum-visible_max
        if lower>upper:return 0.0
        return float(np.clip(requested,lower,upper))

    @staticmethod
    def _modifier_value(event,normal,fine,fast):
        key=str(getattr(event,"key","") or "").lower()
        if "shift" in key:return fine,"muy fino"
        if "control" in key or "ctrl" in key:return fast,"rápido"
        return normal,"fino"

    @staticmethod
    def _pixel_to_data(axis,x,y):return axis.transData.inverted().transform((x,y))

    def _emit(self,message):
        if callable(self.message_callback):self.message_callback(message)

    def _snapped_depth(self,group,x,y):
        axis=group[0];_,value=self._pixel_to_data(axis,x,y)
        depths=getattr(self.figure,"_hmd_axis_depths",{}).get(axis)
        if depths is None or not len(depths):return float(value)
        import numpy as np
        valid=depths[np.isfinite(depths)]
        return float(valid[np.argmin(np.abs(valid-value))]) if valid.size else float(value)

    @staticmethod
    def _clamp_to_axis(axis,x,y):
        bbox=axis.bbox
        return min(max(x,bbox.x0),bbox.x1),min(max(y,bbox.y0),bbox.y1)

    def _clear_cursor(self):
        self._restore_overlay_background()
        for artist in self._cursor_artists:
            try:artist.remove()
            except (ValueError,AttributeError):pass
        self._cursor_artists=[];self._cursor_kind=None
        self._blit_overlays()

    def _clear_data_cursor(self):
        self._restore_overlay_background()
        for artist in self._data_cursor_artists:
            try:artist.remove()
            except (ValueError,AttributeError):pass
        self._data_cursor_artists=[]
        self._blit_overlays()

    def _capture_overlay_background(self,event=None):
        try:self._overlay_background=self.copy_from_bbox(self.figure.bbox)
        except (RuntimeError,AttributeError):self._overlay_background=None

    def _restore_overlay_background(self):
        if self._overlay_background is not None:
            try:self.restore_region(self._overlay_background)
            except (RuntimeError,AttributeError):self._overlay_background=None

    def _blit_overlays(self):
        artists=self._cursor_artists+self._data_cursor_artists+([self._selection_patch] if self._selection_patch is not None else [])
        if self._overlay_background is None:
            self.draw_idle();return
        self._restore_overlay_background()
        try:
            for artist in artists:self.figure.draw_artist(artist)
            self.blit(self.figure.bbox)
        except (RuntimeError,AttributeError):self.draw_idle()

    def _begin_fast_navigation(self):
        artists=getattr(self.figure,"_hmd_discretization_artists",[])
        if self._fast_navigation or not artists:return
        self._fast_navigation=True
        for artist in artists:artist.set_visible(False)
        self.draw_idle()

    def _end_fast_navigation(self):
        if not self._fast_navigation:return
        self._fast_navigation=False
        for artist in getattr(self.figure,"_hmd_discretization_artists",[]):artist.set_visible(True)
        self.draw_idle()

    def _schedule_navigation_restore(self):
        self._navigation_restore_timer.start(160)

    def _update_data_cursor(self,event,group):
        if not self.data_cursor_enabled or self.data_cursor_locked:return
        info=getattr(self.figure,"_hmd_group_info",{}).get(group[0])
        if not info:return
        depth=np.asarray(info["depth"],float);valid=np.flatnonzero(np.isfinite(depth))
        if not valid.size:return
        _,pointer=self._pixel_to_data(group[0],event.x,event.y);index=int(valid[np.argmin(np.abs(depth[valid]-pointer))])
        well=info["well"];actual=float(info["raw_depth"][index]);display=float(depth[index]);unit=well.depth_unit or ""
        unit_suffix=f" {unit}" if unit else ""
        values=[]
        fallback_units={"GR":"API","SP":"mV","ILD":"ohm-m","ILM":"ohm-m","SFL":"ohm-m","RT":"ohm-m","RHOB":"g/cc","NPHI":"v/v","DT":"µs/ft"}
        for source in info.get("sources",[]):
            curve=well.curves.get(source)
            if curve is None or index>=len(curve) or not np.isfinite(curve[index]):continue
            curve_unit=well.curve_units.get(source,"") or fallback_units.get(source,"")
            values.append(f"{source}: {float(curve[index]):.3g}{(' '+curve_unit) if curve_unit else ''}")
        datum=self._last_draw[2] if self._last_draw else None
        relative=f" | Rel. {datum}: {display:+.2f}{unit_suffix}" if datum else ""
        message=f"{well.name} · {well.uwi} | MD: {actual:.2f}{unit_suffix}{relative}"
        if values:message += " | " + " | ".join(values)
        self._clear_data_cursor()
        for axis in self._all_depth_axes():
            artist=axis.axhline(display,color="#2563eb",lw=.7,ls=":",alpha=.75,zorder=29,animated=True);self._data_cursor_artists.append(artist)
        axis=group[0];right_side=event.x<axis.bbox.x0+axis.bbox.width/2
        x_fraction=.98 if right_side else .02;alignment="right" if right_side else "left"
        transform=blended_transform_factory(axis.transAxes,axis.transData)
        tag_lines=[f"MD {actual:.2f}{unit_suffix}"]
        if datum:tag_lines.append(f"Rel. {display:+.2f}{unit_suffix}")
        tag_lines.extend(values)
        tag=axis.text(x_fraction,display,"\n".join(tag_lines),transform=transform,ha=alignment,va="bottom",fontsize=6.2,
                      color="#1d4ed8",zorder=42,clip_on=True,bbox=dict(facecolor="white",edgecolor="#2563eb",alpha=.88,pad=1.2))
        tag.set_animated(True);self._data_cursor_artists.append(tag);self._emit(message);self._blit_overlays()

    def _track_cursor(self,event,group):
        if self.interaction_mode=="interval":
            depth=self._snapped_depth(group,event.x,event.y)
            axes=self._all_depth_axes()
            if self._cursor_kind!="interval" or len(self._cursor_artists)!=len(axes):
                self._clear_cursor();self._cursor_kind="interval"
                for axis in axes:self._cursor_artists.append(axis.axhline(depth,color="#2563eb",lw=.7,ls="--",alpha=.8,zorder=30,animated=True))
            else:
                for artist in self._cursor_artists:artist.set_ydata([depth,depth])
            self._emit(f"Zoom por intervalo: presione y arrastre desde esta profundidad | Cursor={depth:.2f}")
        else:
            fx=event.x/self.figure.bbox.width;fy=event.y/self.figure.bbox.height
            if self._cursor_kind!="area" or len(self._cursor_artists)!=2:
                self._clear_cursor();self._cursor_kind="area"
                vertical=Line2D([fx,fx],[0,1],transform=self.figure.transFigure,color="#2563eb",lw=.65,ls=":",zorder=40,animated=True)
                horizontal=Line2D([0,1],[fy,fy],transform=self.figure.transFigure,color="#2563eb",lw=.65,ls=":",zorder=40,animated=True)
                self.figure.add_artist(vertical);self.figure.add_artist(horizontal);self._cursor_artists=[vertical,horizontal]
            else:self._cursor_artists[0].set_xdata([fx,fx]);self._cursor_artists[1].set_ydata([fy,fy])
            self._emit("Zoom areal: arrastre un recuadro sobre cualquier parte de la sección.")
        self._blit_overlays()

    def _on_press(self,event):
        header_well=getattr(self.figure,"_hmd_header_wells",{}).get(event.inaxes)
        if header_well is not None and event.button==1 and getattr(event,"dblclick",False):
            if callable(self.header_edit_callback):self.header_edit_callback(header_well)
            return
        group=self._group_at(event)
        if self.assisted_correlation and event.button==1:
            info=getattr(self.figure,"_hmd_group_info",{}).get(group[0]) if group else None;state=self.assisted_correlation
            if info and str(info["well"].uwi)==state["source_uwi"] and state["curve"] in info.get("sources",[]):
                state["dragging"]=True;self._emit("Mantenga pulsado y lleve la curva fantasma al track del pozo destino.")
            return
        if self.top_edit_enabled and event.button==1:
            picked=self._top_at(group,event)
            if picked:
                info,name,md,display=picked;datum=self._last_draw[2] if self._last_draw else None
                if self.protect_datum_top and datum and name==datum:
                    self._emit(f"{name} está protegida porque es el datum activo. Desactive la protección para moverla.");return
                if getattr(event,"dblclick",False):
                    if callable(self.top_edit_callback):self.top_edit_callback({"manual_request":True,"well_uwi":str(info["well"].uwi),"top_name":name,"current_depth":md})
                    return
                self.top_edit_state={"well":info["well"],"well_uwi":str(info["well"].uwi),"top_name":name,
                                     "original_md":md,"proposed_md":md,"proposed_display":display,
                                     "group":group,"dragging":True,"artists":[]}
                self._draw_top_edit_preview(display,md)
                self._emit(f"Editando {name} en {info['well'].name}: arrastre verticalmente y suelte para confirmar. Esc cancela.")
                return
            # Outside the hit tolerance the event continues to the active zoom mode.
        if group and event.button==1 and event.key in {"control","ctrl"} and self.data_cursor_enabled:
            self.data_cursor_locked=not self.data_cursor_locked
            self._emit("Cursor de datos fijado. Ctrl+clic para liberarlo." if self.data_cursor_locked else "Cursor de datos liberado.")
            return
        if event.button==2:
            if not self._inside_depth_workspace(event):return
            self._navigation_restore_timer.stop();self._begin_fast_navigation()
            if self._area_zoom_active:
                self._drag={"kind":"area_pan","x":event.x,"y":event.y,"applied":0.0,
                            "viewport_span":self._area_viewport[3]-self._area_viewport[2],
                            "figure_height":max(float(self.figure.bbox.height),1.0)};return
            reference=group[0] if group else self._all_depth_axes()[0]
            self._drag={"kind":"pan","group":group,"reference":reference,"x":event.x,"y":event.y,
                        "ylims":[axis.get_ylim() for axis in self._all_depth_axes()],
                        "reference_ylim":reference.get_ylim(),"axis_height":max(float(reference.bbox.height),1.0)};return
        if event.button!=1:return
        if self.interaction_mode=="interval":
            if not group:return
            start=self._snapped_depth(group,event.x,event.y)
            width=max(float(self.figure.bbox.width),1.0);height=max(float(self.figure.bbox.height),1.0)
            axes=self._all_depth_axes();x0=min(axis.bbox.x0 for axis in axes)/width;x1=max(axis.bbox.x1 for axis in axes)/width
            start_y=group[0].transData.transform((0,start))[1];fy=min(max(start_y/height,0),1)
            self._drag={"kind":"interval","group":group,"start_depth":start,"start_y":start_y,"fy":fy,"x0":x0,"x1":x1}
            self._clear_cursor()
            self._selection_patch=Rectangle((x0,fy),x1-x0,0,transform=self.figure.transFigure,
                facecolor="#2563eb",edgecolor="#2563eb",alpha=.16,lw=1.2,zorder=45,clip_on=False,animated=True)
            self.figure.add_artist(self._selection_patch);self._blit_overlays()
            self._emit(f"Zoom por intervalo: inicio {start:.2f}; mantenga pulsado y arrastre hasta la profundidad final.")
            return
        width=max(float(self.figure.bbox.width),1.0);height=max(float(self.figure.bbox.height),1.0)
        fx=min(max(event.x/width,0),1);fy=min(max(event.y/height,0),1)
        self._drag={"kind":"area","x":event.x,"y":event.y,"fx":fx,"fy":fy}
        self._clear_cursor()
        self._selection_patch=Rectangle((fx,fy),0,0,transform=self.figure.transFigure,facecolor="#2563eb",edgecolor="#ef4444",alpha=.14,lw=1.5,zorder=45,clip_on=False,animated=True)
        self.figure.add_artist(self._selection_patch);self._blit_overlays()

    def _on_motion(self,event):
        group=self._group_at(event)
        if self.assisted_correlation and self.assisted_correlation.get("dragging"):
            info=getattr(self.figure,"_hmd_group_info",{}).get(group[0]) if group else None;state=self.assisted_correlation
            project=self._last_draw[0];target_index=project.wells.index(info["well"]) if info else -99
            if info and abs(target_index-state["source_index"])==1 and state["curve"] in info.get("sources",[]):
                anchor=self._snapped_depth(group,event.x,event.y);self._draw_ghost(group,anchor)
                raw=np.asarray(info["raw_depth"],float);shown=np.asarray(info["depth"],float);valid=np.flatnonzero(np.isfinite(shown))
                md=float(raw[valid[np.argmin(np.abs(shown[valid]-anchor))]])
                self._emit(f'Vista previa: {state["top_name"]} → {info["well"].name}, MD propuesta {md:.2f}. Suelte para confirmar.')
            else:
                self._draw_free_ghost(event)
                self._emit(f'Curva fantasma en tránsito: lleve {state["top_name"]} al track {state["curve"]} de un pozo vecino.')
            return
        if self.top_edit_state and self.top_edit_state.get("dragging"):
            state=self.top_edit_state;source_group=state["group"]
            display=self._snapped_depth(source_group,event.x,event.y)
            shown=np.asarray(self.figure._hmd_group_info[source_group[0]]["depth"],float)
            raw=np.asarray(self.figure._hmd_group_info[source_group[0]]["raw_depth"],float)
            valid=np.flatnonzero(np.isfinite(shown));index=int(valid[np.argmin(np.abs(shown[valid]-display))])
            proposed=float(raw[index]);display=float(shown[index]);self._draw_top_edit_preview(display,proposed)
            self._emit(f'{state["top_name"]}: MD anterior {state["original_md"]:.2f} → MD propuesta {proposed:.2f}')
            return
        if not self._drag:
            if self.interaction_mode=="area":self._track_cursor(event,group)
            elif group:self._track_cursor(event,group)
            elif self._cursor_artists:self._clear_cursor();self.draw_idle()
            if group:self._update_data_cursor(event,group)
            elif self._data_cursor_artists and not self.data_cursor_locked:self._clear_data_cursor();self.draw_idle()
            return
        drag=self._drag
        if drag["kind"]=="pan":
            sensitivity,label=self._modifier_value(event,.45,.15,1.0)
            span=abs(drag["reference_ylim"][0]-drag["reference_ylim"][1])
            pixel_delta=float(event.y-drag["y"])
            delta=self._bounded_depth_shift((pixel_delta/drag["axis_height"])*span*sensitivity,drag["reference_ylim"])
            for depth_axis,limits in zip(self._all_depth_axes(),drag["ylims"]):depth_axis.set_ylim(limits[0]+delta,limits[1]+delta)
            unit=self._last_draw[0].wells[0].depth_unit if self._last_draw and self._last_draw[0].wells else ""
            self._emit(f"Desplazamiento {label}: {delta:+.2f}{(' '+unit) if unit else ''}")
            update_correlation_artists(self.figure);self.draw_idle();return
        if drag["kind"]=="area_pan":
            sensitivity,label=self._modifier_value(event,.45,.15,1.0)
            pixel_delta=float(event.y-drag["y"])
            desired=-(pixel_delta/drag["figure_height"])*drag["viewport_span"]*sensitivity
            incremental=desired-drag["applied"];actual=self._pan_area_by(incremental);drag["applied"]+=actual
            direction="abajo" if drag["applied"]<0 else "arriba"
            self._emit(f"Desplazamiento areal {label}: {direction}");self.draw_idle();return
        if drag["kind"]=="interval":
            current=self._snapped_depth(drag["group"],event.x,event.y)
            height=max(float(self.figure.bbox.height),1.0)
            current_y=drag["group"][0].transData.transform((0,current))[1];fy=min(max(current_y/height,0),1)
            self._selection_patch.set_y(min(drag["fy"],fy));self._selection_patch.set_height(abs(fy-drag["fy"]))
            top,base=sorted((drag["start_depth"],current))
            self._emit(f"Zoom por intervalo — selección: {top:.2f} – {base:.2f}");self._blit_overlays();return
        width=max(float(self.figure.bbox.width),1.0);height=max(float(self.figure.bbox.height),1.0)
        fx=min(max(event.x/width,0),1);fy=min(max(event.y/height,0),1)
        self._selection_patch.set_x(min(drag["fx"],fx));self._selection_patch.set_y(min(drag["fy"],fy))
        self._selection_patch.set_width(abs(fx-drag["fx"]));self._selection_patch.set_height(abs(fy-drag["fy"]))
        self._emit(f"Zoom areal — recuadro: {abs(fx-drag['fx'])*100:.1f}% ancho × {abs(fy-drag['fy'])*100:.1f}% alto de la sección")
        self._blit_overlays()

    def _on_release(self,event):
        if self.assisted_correlation and self.assisted_correlation.get("dragging"):
            state=self.assisted_correlation;state["dragging"]=False;target=state.get("target")
            payload=None
            if target:
                group,anchor=target;info=self.figure._hmd_group_info[group[0]];raw=np.asarray(info["raw_depth"],float);shown=np.asarray(info["depth"],float)
                valid=np.flatnonzero(np.isfinite(shown));md=float(raw[valid[np.argmin(np.abs(shown[valid]-anchor))]])
                payload={key:state[key] for key in ("source_uwi","top_name","curve","interval")}
                payload.update(target_uwi=str(info["well"].uwi),target_depth=md)
            # Dispose the ghost before the callback refreshes and clears the figure.
            self.cancel_assisted_correlation()
            if payload and callable(self.correlation_callback):self.correlation_callback(payload)
            elif not payload:self._emit("La curva se soltó fuera de un track destino válido; no se modificó ninguna cima.")
            return
        if self.top_edit_state and self.top_edit_state.get("dragging"):
            state=self.top_edit_state;payload={"well_uwi":state["well_uwi"],"top_name":state["top_name"],
                "original_depth":state["original_md"],"target_depth":state["proposed_md"],"method":"cursor_adjustment"}
            self._clear_top_edit()
            if abs(payload["target_depth"]-payload["original_depth"])<1e-12:
                self._emit("La cima no cambió de profundidad.")
            elif callable(self.top_edit_callback):self.top_edit_callback(payload)
            return
        if not self._drag:return
        drag=self._drag;self._drag=None
        if drag["kind"] in {"pan","area_pan"}:self._end_fast_navigation();return
        if drag["kind"]=="interval":
            current=self._snapped_depth(drag["group"],event.x,event.y)
            if abs(event.y-drag["start_y"])<5 or abs(current-drag["start_depth"])<1e-9:
                self._cancel_selection();self._emit("Selección demasiado pequeña; el zoom no cambió.");return
            top,base=sorted((drag["start_depth"],current))
            self._cancel_selection(redraw=False)
            for depth_axis in self._all_depth_axes():depth_axis.set_ylim(base,top)
            self._clear_cursor();update_correlation_artists(self.figure);self.draw_idle()
            self._emit(f"Zoom por intervalo aplicado: {top:.2f} – {base:.2f}. Use rueda o botón intermedio para desplazarse.")
            return
        if abs(event.y-drag["y"])<5 or abs(event.x-drag["x"])<5:self._cancel_selection();return
        width=max(float(self.figure.bbox.width),1.0);height=max(float(self.figure.bbox.height),1.0)
        fx=min(max(event.x/width,0),1);fy=min(max(event.y/height,0),1)
        x0,x1=sorted((drag["fx"],fx));y0,y1=sorted((drag["fy"],fy))
        old_x0,old_x1,old_y0,old_y1=self._area_viewport
        new_viewport=(old_x0+x0*(old_x1-old_x0),old_x0+x1*(old_x1-old_x0),
                      old_y0+y0*(old_y1-old_y0),old_y0+y1*(old_y1-old_y0))
        self._clear_data_cursor();self._cancel_selection(redraw=False);apply_area_viewport(self.figure,x0,x1,y0,y1)
        self._area_viewport=new_viewport;self._area_zoom_active=True;self.draw_idle()
        self._emit("Zoom areal aplicado: todo el contenido señalado por el recuadro ocupa ahora el área de trabajo.")

    def _on_scroll(self,event):
        if not self._inside_depth_workspace(event) or not self._all_depth_axes():return
        self._begin_fast_navigation();self._schedule_navigation_restore()
        fraction,label=self._modifier_value(event,.05,.01,.15)
        step=float(getattr(event,"step",0.0) or 0.0)
        if step:direction=1.0 if step<0 else -1.0
        else:direction=1.0 if str(event.button).lower().endswith("down") else -1.0
        if self._area_zoom_active:
            span=self._area_viewport[3]-self._area_viewport[2]
            actual=self._pan_area_by(-direction*fraction*span)
            movement="abajo" if actual<0 else "arriba"
            boundary=" · límite de la sección" if abs(actual)<1e-12 else ""
            self._emit(f"Desplazamiento areal {label}: {movement}{boundary}");self.draw_idle();self._schedule_navigation_restore();return
        reference=self._all_depth_axes()[0];deep,shallow=reference.get_ylim();span=abs(deep-shallow)
        requested=direction*fraction*span
        shift=self._bounded_depth_shift(requested,reference.get_ylim())
        for axis in self._all_depth_axes():
            low,high=axis.get_ylim();axis.set_ylim(low+shift,high+shift)
        unit=self._last_draw[0].wells[0].depth_unit if self._last_draw and self._last_draw[0].wells else ""
        boundary=" · límite del registro" if abs(shift)<1e-12 else ""
        self._emit(f"Desplazamiento {label}: {shift:+.2f}{(' '+unit) if unit else ''}{boundary}")
        update_correlation_artists(self.figure);self.draw_idle();self._schedule_navigation_restore()

    def _on_key_press(self,event):
        if event.key=="escape" and self.top_edit_state:
            self._clear_top_edit();self._emit("Ajuste de cima cancelado; se conserva la profundidad original.")
        elif event.key=="escape" and self.assisted_correlation:
            self.cancel_assisted_correlation();self._emit("Correlación asistida cancelada.")
        elif event.key in {"ctrl+z","control+z"} and callable(self.correlation_callback):
            self.correlation_callback({"undo":True})

    def _cancel_selection(self,redraw=True):
        self._drag=None
        self._restore_overlay_background()
        if self._selection_patch is not None:
            try:self._selection_patch.remove()
            except ValueError:pass
        self._selection_patch=None
        if redraw:self._blit_overlays()

    def export(self, path: str):
        self.figure.savefig(path, bbox_inches="tight", facecolor=self.figure.get_facecolor())
