"""Formato portable y seguro para proyectos HMDLog Correlation."""
from __future__ import annotations

import gzip
import json
from pathlib import Path

import numpy as np

from .models import CorrelationProject, Well
from .spatial_reference import DEFAULT_PROJECT_METADATA,DEFAULT_SPATIAL_REFERENCE


def save_project(path: str, project: CorrelationProject) -> None:
    payload = {
        "schema": "hmdlog.correlation-project",
        "version": 16,
        "project_id": project.project_id,
        "name": project.name,
        "datum_top": project.datum_top,
        "viewer_template": project.viewer_template,
        "curve_overrides": project.curve_overrides,
        "hidden_curves": sorted(project.hidden_curves),
        "hidden_tracks": sorted(project.hidden_tracks),
        "show_lithology": project.show_lithology,
        "show_tops": project.show_tops,
        "show_correlation_lines": project.show_correlation_lines,
        "spacing_mode": project.spacing_mode,
        "correlation_linewidth": project.correlation_linewidth,
        "top_colors": project.top_colors,
        "top_styles": project.top_styles,
        "correlation_history": project.correlation_history,
        "hidden_section_wells": sorted(project.hidden_section_wells),
        "hidden_map_wells": sorted(project.hidden_map_wells),
        "project_metadata": project.project_metadata,
        "spatial_reference": project.spatial_reference,
        "section_lines": project.section_lines,
        "active_section_line_id": project.active_section_line_id,
        "active_section_well_order":project.active_section_well_order,
        "header_identifier_mode":project.header_identifier_mode,
        "well_header_aliases":project.well_header_aliases,
        "map_labels":project.map_labels,
        "track_discretizations":project.track_discretizations,
        "well_track_discretizations":project.well_track_discretizations,
        "well_track_properties":project.well_track_properties,
        "wells": [
            {
                "name": well.name, "uwi": well.uwi,
                "depth": np.asarray(well.depth, float).tolist(),
                "curves": {key: np.asarray(values, float).tolist() for key, values in well.curves.items()},
                "depth_unit":well.depth_unit,"curve_units":well.curve_units,
                "tops": well.tops, "top_metadata":well.top_metadata, "x": well.x, "y": well.y,
                "reference_elevation": well.reference_elevation,
                "coordinate_data": well.coordinate_data,
                "well_metadata": well.well_metadata,
            } for well in project.wells
        ],
    }
    with gzip.open(Path(path), "wt", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))


def load_project(path: str) -> CorrelationProject:
    with gzip.open(Path(path), "rt", encoding="utf-8") as stream:
        payload = json.load(stream)
    if payload.get("schema") != "hmdlog.correlation-project":
        raise ValueError("El archivo no corresponde a un proyecto HMDLog Correlation.")
    wells = [Well(
        name=item["name"], uwi=item["uwi"], depth=np.asarray(item["depth"], float),
        curves={key.upper(): np.asarray(values, float) for key, values in item["curves"].items()},
        depth_unit=item.get("depth_unit",""),curve_units={str(key).upper():str(value) for key,value in item.get("curve_units",{}).items()},
        tops={str(key): float(value) for key, value in item.get("tops", {}).items()},
        top_metadata={str(key):dict(value) for key,value in item.get("top_metadata",{}).items()},
        x=item.get("x"), y=item.get("y"), reference_elevation=item.get("reference_elevation"),
        coordinate_data=dict(item.get("coordinate_data",{})),
        well_metadata=dict(item.get("well_metadata",{})),
    ) for item in payload.get("wells", [])]
    project_metadata=dict(DEFAULT_PROJECT_METADATA);project_metadata.update(payload.get("project_metadata",{}))
    spatial_reference=dict(DEFAULT_SPATIAL_REFERENCE);spatial_reference.update(payload.get("spatial_reference",{}))
    return CorrelationProject(
        project_id=payload.get("project_id") or __import__('uuid').uuid4().hex,
        name=payload.get("name", "Proyecto sin nombre"), wells=wells,
        datum_top=payload.get("datum_top"), viewer_template=payload.get("viewer_template", {}),
        curve_overrides=payload.get("curve_overrides", {}), hidden_curves=set(payload.get("hidden_curves", [])),
        hidden_tracks=set(payload.get("hidden_tracks", [])), show_lithology=bool(payload.get("show_lithology", True)),
        show_tops=bool(payload.get("show_tops", True)),
        show_correlation_lines=bool(payload.get("show_correlation_lines", True)),
        spacing_mode=payload.get("spacing_mode", "proportional"),
        correlation_linewidth=float(payload.get("correlation_linewidth", 1.0)), top_colors=payload.get("top_colors", {}),
        top_styles=payload.get("top_styles", {}),
        correlation_history=list(payload.get("correlation_history",[])),
        hidden_section_wells=set(payload.get("hidden_section_wells",[])),
        hidden_map_wells=set(payload.get("hidden_map_wells",[])),
        project_metadata=project_metadata,
        spatial_reference=spatial_reference,
        section_lines=[dict(item) for item in payload.get("section_lines",[])],
        active_section_line_id=payload.get("active_section_line_id"),
        active_section_well_order=[str(value) for value in payload.get("active_section_well_order",[])],
        header_identifier_mode=payload.get("header_identifier_mode","NAME_UWI"),
        well_header_aliases={str(key):str(value) for key,value in payload.get("well_header_aliases",{}).items()},
        map_labels=[dict(item) for item in payload.get("map_labels",[])],
        track_discretizations={str(key):dict(value) for key,value in payload.get("track_discretizations",{}).items()},
        well_track_discretizations={str(uwi):{str(key):dict(value) for key,value in tracks.items()} for uwi,tracks in payload.get("well_track_discretizations",{}).items()},
        well_track_properties={str(uwi):{str(key):dict(value) for key,value in tracks.items()} for uwi,tracks in payload.get("well_track_properties",{}).items()},
    )
