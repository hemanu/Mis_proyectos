"""Geometría independiente para líneas de sección y proyección de pozos."""
from __future__ import annotations

import math


def _metric_point(point,crs_type="projected",units="metres",reference_latitude=0.0):
    x,y=map(float,point)
    if crs_type=="geographic":return x*111.320*math.cos(math.radians(reference_latitude)),y*110.574
    if "foot" in str(units).lower() or "feet" in str(units).lower():return x*.0003048,y*.0003048
    return x/1000.0,y/1000.0


def project_point_to_section(point,start,end,crs_type="projected",units="metres") -> dict:
    """Devuelve posición longitudinal y distancia perpendicular, ambas en km."""
    reference_latitude=(float(start[1])+float(end[1])+float(point[1]))/3
    p=_metric_point(point,crs_type,units,reference_latitude);a=_metric_point(start,crs_type,units,reference_latitude);b=_metric_point(end,crs_type,units,reference_latitude)
    vx,vy=b[0]-a[0],b[1]-a[1];length2=vx*vx+vy*vy
    if length2<=0:raise ValueError("Los puntos inicial y final de la sección deben ser diferentes.")
    raw_t=((p[0]-a[0])*vx+(p[1]-a[1])*vy)/length2;t=max(0.0,min(1.0,raw_t));qx,qy=a[0]+t*vx,a[1]+t*vy
    return {"fraction":t,"inside_segment":0<=raw_t<=1,"along_km":t*math.sqrt(length2),"lateral_km":math.hypot(p[0]-qx,p[1]-qy),"projected_metric":(qx,qy)}


def project_point_to_polyline(point,vertices,crs_type="projected",units="metres") -> dict:
    """Proyecta contra el segmento más cercano y devuelve estación acumulada desde A."""
    if len(vertices)<2:raise ValueError("La polilínea requiere al menos dos vértices.")
    best=None;cumulative=0.0
    for index,(start,end) in enumerate(zip(vertices,vertices[1:])):
        result=project_point_to_section(point,start,end,crs_type,units)
        reference_latitude=(float(start[1])+float(end[1])+float(point[1]))/3
        a=_metric_point(start,crs_type,units,reference_latitude);b=_metric_point(end,crs_type,units,reference_latitude)
        segment_length=math.hypot(b[0]-a[0],b[1]-a[1]);candidate={**result,"segment_index":index,"along_km":cumulative+result["fraction"]*segment_length}
        if result["inside_segment"] and (best is None or candidate["lateral_km"]<best["lateral_km"]):best=candidate
        cumulative+=segment_length
    if best is None:
        # Extremos fuera de la proyección ortogonal: compara A y A′.
        first=project_point_to_section(point,vertices[0],vertices[1],crs_type,units);last=project_point_to_section(point,vertices[-2],vertices[-1],crs_type,units)
        best={**(first if first["fraction"]<=0 else last),"segment_index":0 if first["fraction"]<=0 else len(vertices)-2,"along_km":0.0 if first["fraction"]<=0 else cumulative}
    best["total_length_km"]=cumulative;return best


def default_section_labels(name: str) -> tuple[str,str]:
    text=str(name).strip()
    if not text:return "A","A′"
    for separator in ("–","-","—"):
        if separator in text:
            left,right=(part.strip() for part in text.split(separator,1))
            if left and right:return left,right
    return text,f"{text}′"
