"""Núcleo independiente de HMDLog Correlation."""

__version__ = "0.12.12"
