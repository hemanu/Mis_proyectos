"""Detección, normalización y validación trazable de coordenadas de pozo."""
from __future__ import annotations

import math
import re
from pathlib import Path


LATITUDE_KEYS=("LATI","LAT","LATITUDE","Y_LAT","Y_LATITUDE")
LONGITUDE_KEYS=("LONG","LON","LOG","LONGITUDE","LONGI","X_LONG","X_LONGITUDE")
X_KEYS=("X","XCOORD","X_COORD","EASTING")
Y_KEYS=("Y","YCOORD","Y_COORD","NORTHING")


def empty_coordinate_data() -> dict:
    return {"source_x":None,"source_y":None,"longitude":None,"latitude":None,"crs":None,
            "source_fields":[],"source_file":None,"format":None,"validation_status":"missing",
            "validation_message":"El archivo no contiene coordenadas reconocibles."}


def parse_geographic_coordinate(value, axis: str) -> tuple[float,str]:
    """Admite decimal o DMS con símbolos y hemisferio."""
    if value is None:raise ValueError("Valor ausente")
    if isinstance(value,(int,float)):
        number=float(value);fmt="decimal"
    else:
        text=str(value).strip().upper().replace("º","°").replace("′","'").replace("″",'"')
        hemisphere=next((letter for letter in "NSEW" if letter in text),None)
        cleaned=text.replace(",",".")
        numbers=[float(token) for token in re.findall(r"[-+]?\d+(?:\.\d+)?",cleaned)]
        if not numbers:raise ValueError(f"No se reconoce la coordenada {value!r}")
        if len(numbers)>=3:
            sign=-1.0 if numbers[0]<0 else 1.0
            number=sign*(abs(numbers[0])+numbers[1]/60.0+numbers[2]/3600.0);fmt="dms"
        else:number=numbers[0];fmt="decimal"
        if hemisphere in {"S","W"}:number=-abs(number)
        elif hemisphere in {"N","E"}:number=abs(number)
    limit=90.0 if axis=="latitude" else 180.0
    if not math.isfinite(number) or not -limit<=number<=limit:
        raise ValueError(f"{axis.capitalize()} fuera del rango {-limit:g} a {limit:g}")
    return number,fmt


def coordinate_data_from_values(latitude_value=None, longitude_value=None, *, latitude_field=None,
                                longitude_field=None, x_value=None, y_value=None, x_field=None,y_field=None,
                                source_file=None) -> dict:
    data=empty_coordinate_data();data["source_file"]=Path(source_file).name if source_file else None
    if latitude_value is not None or longitude_value is not None:
        data.update(source_x=longitude_value,source_y=latitude_value,
                    source_fields=[field for field in (longitude_field,latitude_field) if field],crs="EPSG:4326")
        if latitude_value is None or longitude_value is None:
            data.update(validation_status="incomplete",validation_message="LAT/LON está incompleto.");return data
        try:
            longitude,lon_format=parse_geographic_coordinate(longitude_value,"longitude")
            latitude,lat_format=parse_geographic_coordinate(latitude_value,"latitude")
            data.update(longitude=longitude,latitude=latitude,format=lat_format if lat_format==lon_format else "mixed",
                        validation_status="valid",validation_message="Coordenadas geográficas válidas (WGS 84).")
        except ValueError as exc:data.update(validation_status="invalid",validation_message=str(exc))
        return data
    if x_value is not None or y_value is not None:
        data.update(source_x=x_value,source_y=y_value,source_fields=[field for field in (x_field,y_field) if field],
                    format="projected_or_local",validation_status="unknown_crs",
                    validation_message="Se detectaron X/Y, pero debe indicarse el CRS antes de convertirlas.")
    return data


def validate_manual_geographic(latitude,longitude,crs="EPSG:4326",source="manual") -> dict:
    data=coordinate_data_from_values(latitude,longitude,latitude_field="MANUAL_LAT",longitude_field="MANUAL_LON")
    data.update(source_file=source,crs=str(crs or "EPSG:4326"))
    if str(data["crs"]).upper() not in {"EPSG:4326","WGS84","WGS 84"}:
        data.update(validation_status="unknown_crs",validation_message="El CRS fue conservado, pero esta versión del mapa sólo representa WGS 84.")
    return data


def is_valid_geographic(data: dict | None) -> bool:
    return bool(data and data.get("validation_status")=="valid" and data.get("latitude") is not None and data.get("longitude") is not None)


def haversine_meters(first: dict,second: dict) -> float:
    lat1,lon1,lat2,lon2=map(math.radians,(first["latitude"],first["longitude"],second["latitude"],second["longitude"]))
    dlat=lat2-lat1;dlon=lon2-lon1
    a=math.sin(dlat/2)**2+math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return 6371008.8*2*math.atan2(math.sqrt(a),math.sqrt(1-a))
