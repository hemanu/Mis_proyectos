"""Mapa offline de pozos y construcción interactiva de líneas de sección."""
from __future__ import annotations

from uuid import uuid4
import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg,NavigationToolbar2QT
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QAbstractItemView,QCheckBox,QColorDialog,QComboBox,QDialog,QDialogButtonBox,QDoubleSpinBox,QFileDialog,QFormLayout,QHBoxLayout,
    QInputDialog,QLabel,QLineEdit,QMessageBox,QPushButton,QTableWidget,QTableWidgetItem,QVBoxLayout)

from .section_geometry import default_section_labels,project_point_to_polyline
from .spatial_reference import coordinates_in_project,describe_crs,transform_xy


class SectionReviewDialog(QDialog):
    def __init__(self,name,candidates,parent=None):
        super().__init__(parent);self.setWindowTitle("Revisar pozos de la sección");self.resize(720,430);layout=QVBoxLayout(self)
        form=QFormLayout();self.name_field=QLineEdit(name);form.addRow("Nombre de la sección",self.name_field);layout.addLayout(form)
        label=QLabel("Los pozos tocados se incorporan directamente; los cercanos se proyectan perpendicularmente. Desmarque los que no quiera incluir.");label.setWordWrap(True);layout.addWidget(label)
        self.table=QTableWidget(len(candidates),5);self.table.setHorizontalHeaderLabels(["Incluir","Pozo","Relación","Distancia lateral (km)","Posición desde A (km)"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        for row,item in enumerate(candidates):
            check=QTableWidgetItem();check.setFlags(Qt.ItemIsEnabled if item["mode"]=="direct" else Qt.ItemIsEnabled|Qt.ItemIsUserCheckable);check.setCheckState(Qt.Checked);check.setData(Qt.UserRole,item["uwi"]);self.table.setItem(row,0,check)
            values=(item["name"],"Tocado" if item["mode"]=="direct" else "Proyectado",f'{item["lateral_km"]:.3f}',f'{item["along_km"]:.3f}')
            for column,value in enumerate(values,1):cell=QTableWidgetItem(str(value));cell.setFlags(cell.flags()&~Qt.ItemIsEditable);self.table.setItem(row,column,cell)
        self.table.resizeColumnsToContents();self.table.horizontalHeader().setStretchLastSection(True);layout.addWidget(self.table)
        buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.accepted.connect(self._accept);buttons.rejected.connect(self.reject);layout.addWidget(buttons)

    def _accept(self):
        if not self.name_field.text().strip():QMessageBox.warning(self,"Nombre requerido","Introduzca letras, números o una combinación para identificar la sección.");return
        self.accept()

    def included_uwis(self):
        return {str(self.table.item(row,0).data(Qt.UserRole)) for row in range(self.table.rowCount()) if self.table.item(row,0).checkState()==Qt.Checked}


class WellMapDialog(QDialog):
    def __init__(self,wells,parent=None,project_crs="EPSG:4326",project=None,changed_callback=None):
        super().__init__(parent,Qt.Window);self.setWindowTitle("Mapa de pozos — HMDLog Correlation");self.resize(1100,780)
        self.project_crs=project_crs;self.project=project;self.changed_callback=changed_callback;self.wells=list(wells);self._drawing=False;self._vertices=[];self._vertex_uwis=[];self._preview=None;self._candidate_artists=[];self._editing_members=False;self._pending_line=None;self._adding_label=False;self._moving_label=None;self._label_artists=[]
        self.setAttribute(Qt.WA_DeleteOnClose,True);layout=QVBoxLayout(self);controls=QHBoxLayout()
        self.draw_button=QPushButton("Trazar línea");self.draw_button.setCheckable(True);self.draw_button.clicked.connect(self._toggle_drawing);controls.addWidget(self.draw_button)
        self.trace_mode=QComboBox();self.trace_mode.addItems(["Por pozos","Mixto: pozos y vértices libres"]);controls.addWidget(self.trace_mode)
        self.finish_button=QPushButton("Finalizar");self.finish_button.clicked.connect(self._finish_polyline);self.finish_button.setEnabled(False);controls.addWidget(self.finish_button)
        self.save_line_button=QPushButton("Guardar sección");self.save_line_button.clicked.connect(self._save_pending_line);self.save_line_button.setEnabled(False);controls.addWidget(self.save_line_button)
        controls.addWidget(QLabel("Proyectar hasta"));self.corridor=QDoubleSpinBox();self.corridor.setRange(.01,500);self.corridor.setValue(5);self.corridor.setSuffix(" km");controls.addWidget(self.corridor)
        controls.addSpacing(12);controls.addWidget(QLabel("Línea activa"));self.line_combo=QComboBox();self.line_combo.currentIndexChanged.connect(self._line_changed);controls.addWidget(self.line_combo,1)
        rename=QPushButton("Renombrar…");rename.clicked.connect(self._rename_line);controls.addWidget(rename)
        self.members_button=QPushButton("Agregar/quitar pozos");self.members_button.setCheckable(True);self.members_button.clicked.connect(self._toggle_member_edit);controls.addWidget(self.members_button)
        delete=QPushButton("Eliminar");delete.clicked.connect(self._delete_line);controls.addWidget(delete)
        self.apply_button=QPushButton("Aplicar a correlación");self.apply_button.clicked.connect(self._apply_line);controls.addWidget(self.apply_button);layout.addLayout(controls)
        self.figure=Figure(figsize=(10,7),tight_layout=True);self.canvas=FigureCanvasQTAgg(self.figure);self.nav=NavigationToolbar2QT(self.canvas,self);self.nav.hide()
        tools=QHBoxLayout()
        for symbol,tooltip,slot,checkable in (("⌂","Vista completa",self.nav.home,False),("←","Vista anterior",self.nav.back,False),("✋","Desplazar mapa",self.nav.pan,True),("⌕","Zoom rectangular",self.nav.zoom,True),("⚙","Configurar área",self._configure_area,False),("T","Agregar etiqueta",self._toggle_add_label,True),("▣","Exportar imagen",self._export_map,False)):
            button=QPushButton(symbol);button.setToolTip(tooltip);button.setFixedSize(38,32);button.setCheckable(checkable);button.clicked.connect(slot);tools.addWidget(button)
            if tooltip=="Agregar etiqueta":self.label_button=button
        tools.addStretch();layout.addLayout(tools);layout.addWidget(self.canvas)
        self.summary=QLabel();self.summary.setWordWrap(True);layout.addWidget(self.summary)
        self.canvas.setFocusPolicy(Qt.StrongFocus);self.canvas.setFocus();self._motion_connection=self.canvas.mpl_connect("motion_notify_event",self._on_motion);self.canvas.mpl_connect("button_press_event",self._on_click);self.canvas.mpl_connect("key_press_event",self._on_key)
        self.update_wells(self.wells);self._refresh_line_combo()

    @property
    def section_lines(self):return self.project.section_lines if self.project is not None else []

    @property
    def map_labels(self):return self.project.map_labels if self.project is not None else []

    def update_wells(self,wells,project_crs=None):
        if project_crs:self.project_crs=project_crs
        self.wells=list(wells);self._redraw()

    def _redraw(self):self.figure.clear();self.axis=self.figure.add_subplot(111);self._draw(self.wells)

    def _draw(self,wells):
        axis=self.axis;valid=[well for well in wells if coordinates_in_project(getattr(well,"coordinate_data",{}),self.project_crs) is not None]
        valid_ids={id(well) for well in valid};missing=[well.name for well in wells if id(well) not in valid_ids];info=describe_crs(self.project_crs);geographic=info["type"]=="geographic"
        axis.set_title(f'Ubicación superficial y líneas de sección · {info["code"]} — {info["name"]}');axis.set_xlabel("Longitud (°)" if geographic else f'X ({info["units"]})');axis.set_ylabel("Latitud (°)" if geographic else f'Y ({info["units"]})');axis.grid(True,color="#CBD5E1",lw=.6,alpha=.7)
        self._points=[]
        if valid:
            points=[coordinates_in_project(well.coordinate_data,self.project_crs) for well in valid];xs=np.asarray([p[0] for p in points]);ys=np.asarray([p[1] for p in points])
            axis.scatter(xs,ys,s=62,marker="o",facecolor="#2563EB",edgecolor="#0F172A",linewidth=.8,zorder=5)
            for well,x,y in zip(valid,xs,ys):axis.annotate(well.name,(x,y),xytext=(6,6),textcoords="offset points",fontsize=8,weight="bold",zorder=6);self._points.append((well,float(x),float(y)))
            xspan=max(float(np.ptp(xs)),.01);yspan=max(float(np.ptp(ys)),.01);axis.set_xlim(float(xs.min()-xspan*.18),float(xs.max()+xspan*.18));axis.set_ylim(float(ys.min()-yspan*.18),float(ys.max()+yspan*.18));axis.set_aspect(1/max(np.cos(np.deg2rad(float(ys.mean()))),.15) if geographic else "equal",adjustable="datalim")
        else:axis.text(.5,.5,"No existen pozos con coordenadas transformables.",transform=axis.transAxes,ha="center",va="center")
        for line in self.section_lines:
            if not line.get("visible",True):continue
            try:vertices=self._line_points(line)
            except ValueError:continue
            a,b=vertices[0],vertices[-1];color=line.get("color","#D32F2F");axis.plot([p[0] for p in vertices],[p[1] for p in vertices],color=color,lw=line.get("linewidth",2),marker="o",markersize=3,zorder=8)
            axis.annotate(line.get("label_start","A"),a,xytext=(5,5),textcoords="offset points",weight="bold",color=color,zorder=9);axis.annotate(line.get("label_end","A′"),b,xytext=(5,5),textcoords="offset points",weight="bold",color=color,zorder=9);axis.annotate(line.get("name","Sección"),b,xytext=(8,-13),textcoords="offset points",color=color,zorder=9)
            included=sorted((member for member in line.get("wells",[]) if member.get("included")),key=lambda member:member.get("along_km",0))
            for order,member in enumerate(included,1):
                point=next(((x,y) for w,x,y in self._points if str(w.uwi)==str(member["uwi"])),None)
                if point is not None:
                    axis.scatter([point[0]],[point[1]],s=125,facecolor="none",edgecolor="#16A34A",linewidth=1.6,zorder=10)
                    axis.annotate(str(order),point,xytext=(-9,7),textcoords="offset points",fontsize=7,weight="bold",color="#15803D",zorder=11)
            for member in included:
                if not member.get("included") or member.get("mode")!="projected":continue
                point=next(((x,y) for w,x,y in self._points if str(w.uwi)==str(member["uwi"])),None)
                if point is None:continue
                segment=max(0,min(int(member.get("segment_index",0)),len(vertices)-2));s,e=vertices[segment],vertices[segment+1];t=member["fraction"];projection=(s[0]+t*(e[0]-s[0]),s[1]+t*(e[1]-s[1]));axis.plot([point[0],projection[0]],[point[1],projection[1]],ls="--",lw=.8,color="#F59E0B" if member.get("mode")!="manual" else "#7C3AED",alpha=.8,zorder=4)
        if self._pending_line:
            line=self._pending_line;vertices=self._line_points(line);a,b=vertices[0],vertices[-1];color=line.get("color","#DC2626")
            axis.plot([p[0] for p in vertices],[p[1] for p in vertices],color=color,lw=2.2,ls="--",marker="o",zorder=12)
            axis.annotate(line.get("label_start","A"),a,xytext=(5,5),textcoords="offset points",weight="bold",color=color,zorder=13)
            axis.annotate(line.get("label_end","A′"),b,xytext=(5,5),textcoords="offset points",weight="bold",color=color,zorder=13)
            axis.annotate(f'{line.get("name","Sección")} · sin guardar',b,xytext=(8,-13),textcoords="offset points",color=color,zorder=13)
        self._label_artists=[]
        for label in self.map_labels:
            try:x,y=transform_xy(label["position_wgs84"],self.project_crs)
            except (KeyError,TypeError,ValueError):continue
            artist=axis.text(x,y,label.get("text","Etiqueta"),fontsize=float(label.get("font_size",10)),color=label.get("color","#111827"),fontweight="bold" if label.get("bold") else "normal",fontstyle="italic" if label.get("italic") else "normal",zorder=18,picker=8,bbox=dict(facecolor=label.get("background","#FFFFFF"),edgecolor="none",alpha=.82,pad=1.5))
            self._label_artists.append((artist,label))
        detail=f'{len(valid)} pozo(s) ubicado(s) · {len(self.section_lines)} línea(s) de sección · CRS: {info["code"]} · {len(missing)} sin coordenadas transformables'
        if missing:detail+="\nSin ubicación: "+", ".join(missing)
        self.summary.setText(detail);self.annotation=axis.annotate("",xy=(0,0),xytext=(12,14),textcoords="offset points",bbox=dict(boxstyle="round,pad=.35",fc="white",ec="#2563EB",alpha=.94),fontsize=8,zorder=20);self.annotation.set_visible(False);self.canvas.draw_idle()

    def _line_points(self,line):
        if line.get("vertices_wgs84"):return [transform_xy(point,self.project_crs) for point in line["vertices_wgs84"]]
        if line.get("vertices"):
            if line.get("crs")==self.project_crs:return [tuple(point) for point in line["vertices"]]
            return [transform_xy(point,self.project_crs,line.get("crs","EPSG:4326")) for point in line["vertices"]]
        # Compatibilidad con las líneas rectas de v0.11.8.
        if line.get("start_wgs84") and line.get("end_wgs84"):return [transform_xy(line["start_wgs84"],self.project_crs),transform_xy(line["end_wgs84"],self.project_crs)]
        if line.get("crs")==self.project_crs:return [tuple(line["start"]),tuple(line["end"])]
        return [transform_xy(line["start"],self.project_crs,line.get("crs","EPSG:4326")),transform_xy(line["end"],self.project_crs,line.get("crs","EPSG:4326"))]

    def _toggle_drawing(self,checked):
        if checked and self._editing_members:self.members_button.setChecked(False);self._toggle_member_edit(False)
        self._drawing=checked;self._vertices=[];self._vertex_uwis=[];self.finish_button.setEnabled(False);self.draw_button.setText("Cancelar trazado" if checked else "Trazar línea")
        if checked:self.summary.setText("Haga clic sobre el primer pozo (A). Continúe haciendo clic sobre los pozos; doble clic o Enter para finalizar.")
        if self._preview:
            try:self._preview.remove()
            except Exception:pass
            self._preview=None;self.canvas.draw_idle()
        self._clear_candidate_preview()

    def _on_click(self,event):
        if event.inaxes!=self.axis:return
        if event.button==3:
            label=self._label_at_pixel(event.x,event.y)
            if label:self._edit_label(label)
            return
        if event.button!=1:return
        # Matplotlib emite el doble clic después de un primer clic normal. Ese
        # primer evento ya añadió el vértice final; el segundo sólo debe cerrar.
        if self._drawing and getattr(event,"dblclick",False) and len(self._vertices)>=2:
            self._finish_polyline();return
        if self._moving_label is not None:
            self._moving_label["position_wgs84"]=list(transform_xy((float(event.xdata),float(event.ydata)),"EPSG:4326",self.project_crs));self._moving_label=None;self._changed();self._redraw();return
        if self._adding_label:
            self._create_label(float(event.xdata),float(event.ydata));return
        well_point=self._well_at_pixel(event.x,event.y)
        if self._editing_members:
            if well_point:self._toggle_well_membership(well_point[0])
            return
        if not self._drawing:return
        if well_point:point=(well_point[1],well_point[2]);uwi=str(well_point[0].uwi)
        elif self.trace_mode.currentIndex()==1:point=(float(event.xdata),float(event.ydata));uwi=None
        else:self.summary.setText("El modo Por pozos requiere hacer clic directamente sobre el símbolo de un pozo.");return
        if uwi and uwi in self._vertex_uwis:
            if event.key=="control":self._remove_draft_vertex(self._vertex_uwis.index(uwi))
            elif getattr(event,"dblclick",False) and uwi==self._vertex_uwis[-1]:self._finish_polyline()
            else:self.summary.setText("Ese pozo ya forma parte del trazado. Use Ctrl+clic para quitarlo.")
            return
        self._vertices.append(point);self._vertex_uwis.append(uwi);self.finish_button.setEnabled(len(self._vertices)>=2);self._draw_draft()
        self.summary.setText(f"{len(self._vertices)} vértice(s). Clic en otro pozo; Retroceso deshace y Enter finaliza.")
        if getattr(event,"dblclick",False) and len(self._vertices)>=2:self._finish_polyline()

    def _on_key(self,event):
        if not self._drawing:return
        if event.key in {"enter","return"}:self._finish_polyline()
        elif event.key in {"backspace","delete"} and self._vertices:self._remove_draft_vertex(len(self._vertices)-1)
        elif event.key=="escape":self.draw_button.setChecked(False);self._toggle_drawing(False);self._redraw()

    def _well_at_pixel(self,x,y,limit=12.0):
        nearest=None;distance=float(limit)
        for well,wx,wy in self._points:
            px,py=self.axis.transData.transform((wx,wy));candidate=float(np.hypot(px-x,py-y))
            if candidate<distance:distance=candidate;nearest=(well,wx,wy)
        return nearest

    def _remove_draft_vertex(self,index):
        self._vertices.pop(index);self._vertex_uwis.pop(index);self.finish_button.setEnabled(len(self._vertices)>=2);self._draw_draft()

    def _draw_draft(self,cursor=None):
        if self._preview:
            try:self._preview.remove()
            except Exception:pass
        points=list(self._vertices)+( [cursor] if cursor is not None and self._vertices else [] )
        self._preview=None
        if points:
            self._preview,=self.axis.plot([p[0] for p in points],[p[1] for p in points],color="#D32F2F",lw=2,ls="--",marker="o",zorder=15)
        if len(points)>=2:self._draw_candidate_preview(points)
        else:self._clear_candidate_preview()
        self.canvas.draw_idle()

    def _on_motion(self,event):
        if self._drawing and self._vertices and event.inaxes==self.axis and event.xdata is not None:
            well_point=self._well_at_pixel(event.x,event.y);cursor=(well_point[1],well_point[2]) if well_point else (float(event.xdata),float(event.ydata));self._draw_draft(cursor);return
        if event.inaxes is None or event.x is None:self.annotation.set_visible(False);self.canvas.draw_idle();return
        nearest=None;distance=12.0
        for well,x,y in self._points:
            px,py=event.inaxes.transData.transform((x,y));candidate=float(np.hypot(px-event.x,py-event.y))
            if candidate<distance:distance=candidate;nearest=(well,x,y)
        if nearest:
            well,x,y=nearest;data=well.coordinate_data;self.annotation.xy=(x,y);self.annotation.set_text(f"{well.name}\nUWI: {well.uwi}\nX: {x:.3f} · Y: {y:.3f}\nLAT/LONG: {data.get('latitude','')} / {data.get('longitude','')}");self.annotation.set_visible(True)
        else:self.annotation.set_visible(False)
        self.canvas.draw_idle()

    @staticmethod
    def _pixel_segment_distance(point,a,b):
        p=np.asarray(point,float);a=np.asarray(a,float);b=np.asarray(b,float);v=b-a
        if float(v@v)==0:return float(np.linalg.norm(p-a))
        t=max(0,min(1,float((p-a)@v/(v@v))));return float(np.linalg.norm(p-(a+t*v)))

    def _polyline_pixel_distance(self,point,vertices):
        pixel=self.axis.transData.transform(point);screen=[self.axis.transData.transform(vertex) for vertex in vertices]
        return min(self._pixel_segment_distance(pixel,start,end) for start,end in zip(screen,screen[1:]))

    def _clear_candidate_preview(self):
        for artist in self._candidate_artists:
            try:artist.remove()
            except Exception:pass
        self._candidate_artists=[]

    def _draw_candidate_preview(self,vertices):
        self._clear_candidate_preview();candidates=self._section_candidates(vertices,self._vertex_uwis)
        for item in candidates:
            well,x,y=next((entry for entry in self._points if str(entry[0].uwi)==item["uwi"]),(None,None,None))
            if well is None:continue
            color="#16A34A" if item["mode"]=="direct" else "#F59E0B";marker=self.axis.scatter([x],[y],s=115,facecolor="none",edgecolor=color,linewidth=2,zorder=16);self._candidate_artists.append(marker)

    def _section_candidates(self,vertices,vertex_uwis,corridor_km=None):
        info=describe_crs(self.project_crs);candidates=[];direct={str(uwi) for uwi in vertex_uwis if uwi}
        for well,x,y in self._points:
            projected=project_point_to_polyline((x,y),vertices,info["type"],info["units"]);uwi=str(well.uwi)
            if uwi in direct or self._polyline_pixel_distance((x,y),vertices)<=10:projected.update(lateral_km=0.0);mode="direct"
            elif projected["lateral_km"]<=(self.corridor.value() if corridor_km is None else float(corridor_km)):mode="projected"
            else:continue
            candidates.append({"uwi":uwi,"name":well.name,"mode":mode,**projected})
        return sorted(candidates,key=lambda item:item["along_km"])

    def _finish_polyline(self):
        if len(self._vertices)<2:QMessageBox.information(self,"Línea incompleta","Seleccione al menos dos pozos o vértices.");return
        # Congelar el trazado antes del diálogo evita que eventos de movimiento
        # pendientes continúen dibujando una línea desde el último vértice.
        vertices=list(self._vertices);vertex_uwis=list(self._vertex_uwis);self._drawing=False
        self.finish_button.setEnabled(False);self.draw_button.blockSignals(True);self.draw_button.setChecked(False);self.draw_button.blockSignals(False);self.draw_button.setText("Trazar línea")
        if self._preview:
            try:self._preview.remove()
            except Exception:pass
            self._preview=None
        self._clear_candidate_preview();self.canvas.draw_idle()
        candidates=self._section_candidates(vertices,vertex_uwis);dialog=SectionReviewDialog(f"Sección {len(self.section_lines)+1}",candidates,self)
        if dialog.exec()==QDialog.Accepted:
            name=dialog.name_field.text().strip()
            if any(item.get("name","").casefold()==name.casefold() for item in self.section_lines):QMessageBox.warning(self,"Nombre duplicado","Ya existe una línea de sección con ese nombre.")
            else:
                included=dialog.included_uwis();label_a,label_b=default_section_labels(name.replace("Sección ","",1));line={"id":str(uuid4()),"name":name,"label_start":label_a,"label_end":label_b,"vertices":[list(point) for point in vertices],"vertices_wgs84":[list(transform_xy(point,"EPSG:4326",self.project_crs)) for point in vertices],"vertex_uwis":vertex_uwis,"crs":self.project_crs,"corridor_km":self.corridor.value(),"color":"#D32F2F","linewidth":2.0,"visible":True,"wells":[{"uwi":item["uwi"],"mode":item["mode"],"lateral_km":item["lateral_km"],"along_km":item["along_km"],"fraction":item["fraction"],"segment_index":item["segment_index"],"included":item["uwi"] in included,"membership":"automatic"} for item in candidates]}
                self._pending_line=line;self.save_line_button.setEnabled(True);self.summary.setText(f'“{name}” finalizada y lista para revisión. Presione Guardar sección para incorporarla al proyecto.');self._refresh_line_combo();self._redraw()
        self._vertices=[];self._vertex_uwis=[]

    def _save_pending_line(self):
        if not self._pending_line:return
        line=self._pending_line;self.section_lines.append(line);self.project.active_section_line_id=line["id"];self._pending_line=None;self.save_line_button.setEnabled(False);self._changed();self._refresh_line_combo();self._redraw();self.summary.setText(f'Sección guardada en el proyecto: {line["name"]}.')

    def _configure_area(self):
        dialog=QDialog(self);dialog.setWindowTitle("Configurar área del mapa");form=QFormLayout(dialog);limits=self.axis.axis()
        fields=[]
        for label,value in zip(("X mínima","X máxima","Y mínima","Y máxima"),limits):field=QLineEdit(f"{value:.8g}");fields.append(field);form.addRow(label,field)
        grid=QCheckBox("Mostrar cuadrícula");grid.setChecked(any(line.get_visible() for line in self.axis.get_xgridlines()));form.addRow(grid)
        buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);form.addRow(buttons);buttons.rejected.connect(dialog.reject)
        def accept():
            try:values=[float(field.text()) for field in fields]
            except ValueError:QMessageBox.warning(dialog,"Valores inválidos","Los límites deben ser números.");return
            if values[0]>=values[1] or values[2]>=values[3]:QMessageBox.warning(dialog,"Área inválida","Los límites máximos deben ser mayores que los mínimos.");return
            self.axis.set_xlim(values[0],values[1]);self.axis.set_ylim(values[2],values[3]);self.axis.grid(grid.isChecked(),color="#CBD5E1",lw=.6,alpha=.7);self.canvas.draw_idle();dialog.accept()
        buttons.accepted.connect(accept);dialog.exec()

    def _toggle_add_label(self,checked):
        self._adding_label=bool(checked);self.summary.setText("Haga clic en el mapa donde desea colocar la etiqueta." if checked else "Herramienta de etiquetas desactivada.")

    def _create_label(self,x,y):
        text,ok=QInputDialog.getText(self,"Agregar etiqueta","Texto de la etiqueta:")
        if ok and text.strip():
            self.map_labels.append({"id":str(uuid4()),"text":text.strip(),"position_wgs84":list(transform_xy((x,y),"EPSG:4326",self.project_crs)),"font_size":10.0,"color":"#111827","background":"#FFFFFF","bold":False,"italic":False});self._changed();self._redraw()
        self._adding_label=False;self.label_button.setChecked(False)

    def _label_at_pixel(self,x,y):
        for artist,label in reversed(self._label_artists):
            box=artist.get_window_extent(renderer=self.canvas.get_renderer()).expanded(1.15,1.35)
            if box.contains(x,y):return label
        return None

    def _edit_label(self,label):
        dialog=QDialog(self);dialog.setWindowTitle("Editar etiqueta");form=QFormLayout(dialog);text=QLineEdit(label.get("text",""));size=QDoubleSpinBox();size.setRange(5,48);size.setValue(float(label.get("font_size",10)));bold=QCheckBox("Negrita");bold.setChecked(bool(label.get("bold")));italic=QCheckBox("Cursiva");italic.setChecked(bool(label.get("italic")));form.addRow("Texto",text);form.addRow("Tamaño",size);form.addRow(bold);form.addRow(italic)
        color=QPushButton("Color del texto…");background=QPushButton("Color de fondo…");form.addRow(color);form.addRow(background);selected={"color":label.get("color","#111827"),"background":label.get("background","#FFFFFF")}
        def choose(key):
            chosen=QColorDialog.getColor(QColor(selected[key]),dialog)
            if chosen.isValid():selected[key]=chosen.name()
        color.clicked.connect(lambda:choose("color"));background.clicked.connect(lambda:choose("background"))
        move=QPushButton("Mover con el cursor");form.addRow(move)
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Discard|QDialogButtonBox.Cancel);buttons.button(QDialogButtonBox.Save).setText("Guardar cambios");buttons.button(QDialogButtonBox.Discard).setText("Eliminar etiqueta");form.addRow(buttons);buttons.rejected.connect(dialog.reject)
        def save():label.update(text=text.text().strip() or "Etiqueta",font_size=size.value(),bold=bold.isChecked(),italic=italic.isChecked(),color=selected["color"],background=selected["background"]);self._changed();dialog.accept();self._redraw()
        def remove():self.map_labels.remove(label);self._changed();dialog.accept();self._redraw()
        def start_move():self._moving_label=label;dialog.accept();self.summary.setText("Haga clic en la nueva posición de la etiqueta.")
        move.clicked.connect(start_move);buttons.button(QDialogButtonBox.Save).clicked.connect(save);buttons.button(QDialogButtonBox.Discard).clicked.connect(remove);dialog.exec()

    def _export_map(self):
        path,_=QFileDialog.getSaveFileName(self,"Exportar mapa","mapa_pozos.png","PNG (*.png);;SVG (*.svg);;PDF (*.pdf)")
        if path:self.figure.savefig(path,dpi=220,bbox_inches="tight");self.summary.setText(f"Mapa exportado: {path}")

    def _refresh_line_combo(self):
        current="__pending__" if self._pending_line else (self.project.active_section_line_id if self.project else None);self.line_combo.blockSignals(True);self.line_combo.clear()
        for line in self.section_lines:self.line_combo.addItem(line.get("name","Sección"),line.get("id"))
        if self._pending_line:self.line_combo.addItem(f'[Sin guardar] {self._pending_line.get("name","Sección")}',"__pending__")
        index=self.line_combo.findData(current);self.line_combo.setCurrentIndex(index if index>=0 else (0 if self.line_combo.count() else -1));self.line_combo.blockSignals(False)
        self.apply_button.setEnabled(bool(self.line_combo.currentData() and self.line_combo.currentData()!="__pending__"))

    def _active_line(self):
        key=self.line_combo.currentData()
        if key=="__pending__":return self._pending_line
        return next((line for line in self.section_lines if line.get("id")==key),None)

    def _line_changed(self):
        key=self.line_combo.currentData();self.apply_button.setEnabled(bool(key and key!="__pending__"))
        if self.project and key and key!="__pending__":self.project.active_section_line_id=key;self._changed()

    def _toggle_member_edit(self,checked):
        if checked and not self._active_line():self.members_button.setChecked(False);QMessageBox.information(self,"Editar pozos","Seleccione primero una línea de sección.");return
        if checked and self._drawing:self.draw_button.setChecked(False);self._toggle_drawing(False)
        self._editing_members=checked;self.members_button.setText("Finalizar edición" if checked else "Agregar/quitar pozos")
        self.summary.setText("Clic sobre un pozo: agregarlo o quitarlo de la línea activa. Los pozos del proyecto no se eliminan." if checked else self.summary.text())

    def _toggle_well_membership(self,well):
        line=self._active_line();uwi=str(well.uwi)
        if not line:return
        current=next((item for item in line.get("wells",[]) if str(item.get("uwi"))==uwi),None);included=bool(current and current.get("included"))
        vertices=self._line_points(line);vertex_uwis=list(line.get("vertex_uwis",[None]*len(vertices)))
        if included:
            if uwi in vertex_uwis:
                if len(vertices)<=2:QMessageBox.information(self,"No se puede quitar","La polilínea debe conservar al menos dos vértices. Agregue otro pozo antes de quitar este extremo.");return
                index=vertex_uwis.index(uwi);vertices.pop(index);vertex_uwis.pop(index);line["vertices"]=[list(point) for point in vertices];line["vertices_wgs84"]=[list(transform_xy(point,"EPSG:4326",self.project_crs)) for point in vertices];line["vertex_uwis"]=vertex_uwis;line["crs"]=self.project_crs
            self._recalculate_line_members(line,{uwi:"manual_excluded"})
        else:self._recalculate_line_members(line,{uwi:"manual"})
        self._changed();self._redraw()

    def _recalculate_line_members(self,line,overrides=None):
        overrides=dict(overrides or {});vertices=self._line_points(line);vertex_uwis=list(line.get("vertex_uwis",[None]*len(vertices)));old={str(item.get("uwi")):item for item in line.get("wells",[])}
        decisions={uwi:item.get("membership","automatic") for uwi,item in old.items()};decisions.update(overrides)
        automatic={item["uwi"]:item for item in self._section_candidates(vertices,vertex_uwis,line.get("corridor_km",self.corridor.value()))};members=[];info=describe_crs(self.project_crs)
        for well,x,y in self._points:
            uwi=str(well.uwi);decision=decisions.get(uwi,"automatic");candidate=automatic.get(uwi)
            if decision=="manual_excluded":
                base=candidate or old.get(uwi)
                if base:members.append({**base,"uwi":uwi,"included":False,"membership":"manual_excluded"})
                continue
            if decision=="manual" and candidate is None:
                projected=project_point_to_polyline((x,y),vertices,info["type"],info["units"]);candidate={"uwi":uwi,"name":well.name,"mode":"manual",**projected}
            if candidate:
                mode="manual" if decision=="manual" else candidate["mode"];members.append({"uwi":uwi,"mode":mode,"lateral_km":candidate["lateral_km"],"along_km":candidate["along_km"],"fraction":candidate["fraction"],"segment_index":candidate["segment_index"],"included":True,"membership":decision})
        line["wells"]=sorted(members,key=lambda item:item.get("along_km",0))

    def _rename_line(self):
        line=self._active_line()
        if not line:QMessageBox.information(self,"Línea de sección","No existe una línea seleccionada.");return
        name,ok=QInputDialog.getText(self,"Renombrar línea de sección","Nuevo nombre:",text=line.get("name",""))
        if not ok or not name.strip():return
        if any(other is not line and other.get("name","").casefold()==name.strip().casefold() for other in self.section_lines):QMessageBox.warning(self,"Nombre duplicado","Ya existe una línea con ese nombre.");return
        line["name"]=name.strip();line["label_start"],line["label_end"]=default_section_labels(name.strip().replace("Sección ","",1));self._changed();self._refresh_line_combo();self._redraw()

    def _delete_line(self):
        line=self._active_line()
        if not line:return
        if QMessageBox.question(self,"Eliminar línea",f'¿Eliminar “{line["name"]}”?',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
        if line is self._pending_line:self._pending_line=None;self.save_line_button.setEnabled(False)
        else:self.section_lines.remove(line)
        if self.project.active_section_line_id==line.get("id"):self.project.active_section_line_id=None;self.project.active_section_well_order=[]
        self._changed();self._refresh_line_combo();self._redraw()

    def _apply_line(self):
        line=self._active_line()
        if not line:return
        if line is self._pending_line:QMessageBox.information(self,"Guardar sección","Guarde primero la sección para poder aplicarla a la correlación.");return
        selected=sorted((item for item in line.get("wells",[]) if item.get("included")),key=lambda item:item.get("along_km",0));uwis=[str(item["uwi"]) for item in selected]
        if not uwis:QMessageBox.information(self,"Aplicar a correlación","La línea no contiene pozos incluidos.");return
        if QMessageBox.question(self,"Aplicar a correlación",f'¿Ordenar y mostrar {len(uwis)} pozo(s) según “{line["name"]}”?',QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)!=QMessageBox.Yes:return
        lookup={str(w.uwi):w for w in self.project.wells};ordered=[lookup[u] for u in uwis if u in lookup];chosen=set(uwis);remaining=[w for w in self.project.wells if str(w.uwi) not in chosen]
        self.project.wells=ordered+remaining;self.project.hidden_section_wells={str(w.uwi) for w in remaining};self.project.active_section_line_id=line["id"];self.project.active_section_well_order=[str(w.uwi) for w in ordered];self._changed();self.summary.setText(f'Sección aplicada: {line["name"]} · {len(ordered)} pozos mostrados en el orden exacto desde {line["label_start"]} hacia {line["label_end"]}.')

    def _changed(self):
        if self.changed_callback:self.changed_callback()
