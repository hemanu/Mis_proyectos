"""Sistema de referencia del proyecto y transformación no destructiva de pozos."""
from __future__ import annotations

import re
import math


DEFAULT_PROJECT_METADATA={"area":"","field":"","operator":"","description":"","author":""}
DEFAULT_SPATIAL_REFERENCE={"horizontal_crs":"EPSG:4326","horizontal_name":"WGS 84","horizontal_type":"geographic",
    "coordinate_units":"degrees","transform_coordinates":True,"show_original_coordinates":False,
    "vertical_reference":"MSL","vertical_units":"ft","default_elevation":None}


def practical_crs_catalog() -> dict[str,list[tuple[str,str]]]:
    """Catálogo breve, útil y ampliable; cada entrada es (código, nombre)."""
    catalog={
        "Globales":[("EPSG:4326","WGS 84 — latitud/longitud"),("EPSG:3857","WGS 84 / Pseudo-Mercator")],
        "México":[("EPSG:6365","Mexico ITRF2008 — geográfico 2D"),("EPSG:6372","Mexico ITRF2008 / LCC")]
            +[(f"EPSG:{6355+zone}",f"Mexico ITRF2008 / UTM zona {zone}N") for zone in range(11,17)],
        "Norteamérica":[("EPSG:4267","NAD27 — geográfico"),("EPSG:4269","NAD83 — geográfico"),
            ("EPSG:6318","NAD83(2011) — geográfico")],
        "ITRF":[("EPSG:8999","ITRF2008 — geográfico 2D"),("EPSG:9000","ITRF2014 — geográfico 2D")],
        "UTM WGS 84 — Norte":[(f"EPSG:{32600+zone}",f"WGS 84 / UTM zona {zone}N") for zone in range(1,61)],
        "UTM WGS 84 — Sur":[(f"EPSG:{32700+zone}",f"WGS 84 / UTM zona {zone}S") for zone in range(1,61)],
        "Manual / otro EPSG":[],
    }
    return catalog


def practical_crs_category(code: str) -> str:
    normalized=clean_epsg(code)
    for category,items in practical_crs_catalog().items():
        if any(item_code==normalized for item_code,_name in items):return category
    return "Manual / otro EPSG"


def utm_zone(longitude: float) -> int:
    return max(1,min(60,int(math.floor((float(longitude)+180.0)/6.0))+1))


def recommend_crs_for_bounds(west: float,south: float,east: float,north: float) -> dict:
    """Recomienda CRS a partir de un rectángulo geográfico sin sustituir el juicio del usuario."""
    west,east=sorted((float(west),float(east)));south,north=sorted((float(south),float(north)))
    if not (-180<=west<=180 and -180<=east<=180 and -90<=south<=90 and -90<=north<=90) or west==east or south==north:
        raise ValueError("El área seleccionada no contiene límites geográficos válidos.")
    center_lon=(west+east)/2;center_lat=(south+north)/2;zone=utm_zone(center_lon)
    west_zone=utm_zone(west+1e-9);east_zone=utm_zone(east-1e-9);crosses=west_zone!=east_zone
    mexico=(-122.19<=center_lon<=-84.64 and 12.1<=center_lat<=32.72)
    recommendations=[]
    if mexico:
        if not crosses and 11<=zone<=16:
            recommendations.append({"code":f"EPSG:{6355+zone}","name":f"Mexico ITRF2008 / UTM zona {zone}N",
                "reason":"Área mexicana contenida en una sola zona UTM; conveniente para distancias y superficies locales."})
        recommendations.append({"code":"EPSG:6372","name":"Mexico ITRF2008 / LCC",
            "reason":"Alternativa regional para áreas extensas o que atraviesan zonas UTM."})
        recommendations.append({"code":"EPSG:6365","name":"Mexico ITRF2008 — geográfico 2D",
            "reason":"Coordenadas geográficas oficiales para México."})
    elif -80<=center_lat<=84 and not crosses:
        code=32600+zone if center_lat>=0 else 32700+zone;hemisphere="N" if center_lat>=0 else "S"
        recommendations.append({"code":f"EPSG:{code}","name":f"WGS 84 / UTM zona {zone}{hemisphere}",
            "reason":"Área contenida en una sola zona UTM; apropiada para mediciones locales."})
    recommendations.append({"code":"EPSG:4326","name":"WGS 84 — latitud/longitud",
        "reason":"Sistema global para intercambio y conservación de coordenadas geográficas."})
    unique=[];seen=set()
    for item in recommendations:
        if item["code"] not in seen:unique.append(item);seen.add(item["code"])
    return {"bounds":(west,south,east,north),"center":(center_lon,center_lat),"utm_zone":zone,
        "crosses_utm_zones":crosses,"region":"México" if mexico else "Global","recommendations":unique}


def clean_epsg(value) -> str:
    text=str(value or "EPSG:4326").strip().upper().replace(" ","")
    if text.isdigit():text=f"EPSG:{text}"
    if not re.fullmatch(r"EPSG:\d+",text):raise ValueError("Use un código con formato EPSG:4326.")
    return text


def describe_crs(value) -> dict:
    code=clean_epsg(value)
    try:
        from pyproj import CRS
        crs=CRS.from_user_input(code)
    except ImportError:
        if code!="EPSG:4326":raise ValueError("Instale pyproj para validar y transformar CRS proyectados.")
        return {"code":code,"name":"WGS 84","type":"geographic","units":"degrees"}
    except Exception as exc:raise ValueError(f"CRS no reconocido: {exc}") from exc
    axis_unit=(crs.axis_info[0].unit_name if crs.axis_info else "") or ""
    units="degrees" if crs.is_geographic else "metres" if "met" in axis_unit.lower() else "feet" if "foot" in axis_unit.lower() else axis_unit
    return {"code":code,"name":crs.name,"type":"geographic" if crs.is_geographic else "projected","units":units}


def coordinates_in_project(data: dict | None, target_crs: str) -> tuple[float,float] | None:
    if not data or data.get("validation_status")!="valid" or data.get("longitude") is None or data.get("latitude") is None:return None
    longitude=float(data["longitude"]);latitude=float(data["latitude"]);target=clean_epsg(target_crs)
    if target=="EPSG:4326":return longitude,latitude
    try:
        from pyproj import Transformer
        x,y=Transformer.from_crs("EPSG:4326",target,always_xy=True).transform(longitude,latitude)
    except Exception:return None
    return float(x),float(y)


def transform_xy(point,target_crs: str,source_crs: str="EPSG:4326") -> tuple[float,float]:
    source=clean_epsg(source_crs);target=clean_epsg(target_crs);x,y=map(float,point)
    if source==target:return x,y
    try:
        from pyproj import Transformer
        tx,ty=Transformer.from_crs(source,target,always_xy=True).transform(x,y)
    except Exception as exc:raise ValueError(f"No fue posible transformar la geometría entre {source} y {target}: {exc}") from exc
    return float(tx),float(ty)


def refresh_project_coordinate_cache(project) -> int:
    reference=dict(DEFAULT_SPATIAL_REFERENCE);reference.update(getattr(project,"spatial_reference",{}) or {})
    target=reference["horizontal_crs"];updated=0
    for well in project.wells:
        data=dict(well.coordinate_data or {});point=coordinates_in_project(data,target)
        if point is None:
            for key in ("project_x","project_y","project_crs"):data.pop(key,None)
        else:
            data.update(project_x=point[0],project_y=point[1],project_crs=target);updated+=1
        well.coordinate_data=data
    return updated


def original_coordinate_warning(data: dict | None) -> str:
    """Detecta discrepancias de signo sin corregir ni sobrescribir el origen."""
    if not data or data.get("source_x") is None or data.get("source_y") is None:return ""
    try:
        from .coordinates import parse_geographic_coordinate
        source_lon,_=parse_geographic_coordinate(data["source_x"],"longitude")
        source_lat,_=parse_geographic_coordinate(data["source_y"],"latitude")
    except (ValueError,TypeError):return ""
    if data.get("longitude") is not None and source_lon*float(data["longitude"])<0:return "Revisar signo de longitud"
    if data.get("latitude") is not None and source_lat*float(data["latitude"])<0:return "Revisar signo de latitud"
    return ""
