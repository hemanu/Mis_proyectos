"""Administrador unificado de pozos, catálogo e importación tabular."""
from __future__ import annotations

from pathlib import Path
import numpy as np
from PySide6.QtCore import Qt,QItemSelectionModel
from PySide6.QtWidgets import (QAbstractItemView,QCheckBox,QComboBox,QDialog,QDialogButtonBox,QFileDialog,QFormLayout,QGridLayout,QHBoxLayout,
    QHeaderView,QLabel,QLineEdit,QMessageBox,QPushButton,QTabWidget,QTableWidget,QTableWidgetItem,QTextEdit,QVBoxLayout,QWidget)

from .coordinates import coordinate_data_from_values,empty_coordinate_data,is_valid_geographic
from .crs_map_selector import CrsMapSelectorDialog
from .models import Well
from .spatial_reference import (DEFAULT_PROJECT_METADATA,DEFAULT_SPATIAL_REFERENCE,coordinates_in_project,describe_crs,
    original_coordinate_warning,practical_crs_catalog,practical_crs_category,refresh_project_coordinate_cache)


class ProjectAdministratorDialog(QDialog):
    def __init__(self,project,geodata,las_repository,refresh_callback,parent=None,map_callback=None,coordinate_callback=None):
        super().__init__(parent);self.project=project;self.geodata=geodata;self.las_repository=las_repository;self.refresh_callback=refresh_callback
        self.map_callback=map_callback;self.coordinate_callback=coordinate_callback
        self.setWindowTitle(f"Administrador de proyecto — {project.name}");self.resize(1120,620);layout=QVBoxLayout(self);self.tabs=QTabWidget();layout.addWidget(self.tabs)
        self._build_general_tab();self._build_reference_tab();self._build_catalog_tab();self._build_project_tab();self._build_map_tab();self._build_import_tab()
        footer=QHBoxLayout();self.remove_project_button=QPushButton("Quitar del proyecto…");self.remove_project_button.clicked.connect(self.remove_from_project)
        footer.addWidget(self.remove_project_button);footer.addStretch();self.selection_label=QLabel("Ningún pozo seleccionado");footer.addWidget(self.selection_label)
        apply_button=QPushButton("Aplicar");apply_button.clicked.connect(self._apply_project_settings);footer.addWidget(apply_button)
        buttons=QDialogButtonBox(QDialogButtonBox.Close);buttons.button(QDialogButtonBox.Close).setText("Cerrar");buttons.rejected.connect(self.reject);footer.addWidget(buttons);layout.addLayout(footer)
        self.tabs.currentChanged.connect(self._update_footer);self._update_footer(0)
        self.refresh_all()

    @staticmethod
    def _read_only(item):item.setFlags(item.flags()&~Qt.ItemIsEditable);return item

    def _build_general_tab(self):
        metadata=dict(DEFAULT_PROJECT_METADATA);metadata.update(self.project.project_metadata or {})
        page=QWidget();form=QFormLayout(page);self.project_name=QLineEdit(self.project.name);self.project_area=QLineEdit(metadata["area"])
        self.project_field=QLineEdit(metadata["field"]);self.project_operator=QLineEdit(metadata["operator"]);self.project_author=QLineEdit(metadata["author"])
        self.project_description=QTextEdit(metadata["description"])
        for label,widget in (("Nombre del proyecto",self.project_name),("Área o cuenca",self.project_area),("Campo",self.project_field),
                             ("Operador",self.project_operator),("Autor",self.project_author),("Descripción",self.project_description)):form.addRow(label,widget)
        self.tabs.addTab(page,"Datos generales")

    def _build_reference_tab(self):
        reference=dict(DEFAULT_SPATIAL_REFERENCE);reference.update(self.project.spatial_reference or {})
        page=QWidget();form=QFormLayout(page);self.crs_catalog=practical_crs_catalog();self.crs_category=QComboBox();self.crs_category.addItems(self.crs_catalog)
        self.project_crs=QComboBox();self.project_crs.setEditable(True);self.project_crs.setInsertPolicy(QComboBox.NoInsert)
        self.project_crs.lineEdit().setPlaceholderText("Seleccione o escriba un código, por ejemplo EPSG:4326")
        self.project_crs_description=QLabel();self.project_crs_description.setWordWrap(True)
        self.crs_map_button=QPushButton("🌐 Seleccionar área en mapa…");self.crs_map_button.setToolTip("Dibujar un área geográfica y recibir una recomendación de CRS")
        self.crs_map_button.clicked.connect(self._select_crs_on_map)
        initial_crs=str(reference["horizontal_crs"]);self.crs_category.setCurrentText(practical_crs_category(initial_crs));self._populate_crs_choices(initial_crs)
        self.transform_coordinates=QCheckBox("Transformar automáticamente sin modificar los valores originales");self.transform_coordinates.setChecked(bool(reference["transform_coordinates"]))
        self.show_original_coordinates=QCheckBox("Mostrar también las coordenadas originales");self.show_original_coordinates.setChecked(bool(reference["show_original_coordinates"]))
        self.vertical_reference=QComboBox();self.vertical_reference.addItems(["MSL","KB","DF","GL","Otro"]);self.vertical_reference.setCurrentText(str(reference["vertical_reference"]))
        self.vertical_units=QComboBox();self.vertical_units.addItems(["ft","m"]);self.vertical_units.setCurrentText(str(reference["vertical_units"]))
        self.default_elevation=QLineEdit("" if reference["default_elevation"] is None else str(reference["default_elevation"]))
        for label,widget in (("Grupo de sistemas",self.crs_category),("CRS horizontal principal",self.project_crs),("Sistema identificado",self.project_crs_description),
                             ("Referencia vertical",self.vertical_reference),("Unidad vertical",self.vertical_units),("Elevación predeterminada",self.default_elevation)):form.addRow(label,widget)
        form.addRow(self.transform_coordinates);form.addRow(self.show_original_coordinates)
        form.addRow("Asistente cartográfico",self.crs_map_button)
        self.crs_category.currentTextChanged.connect(self._populate_crs_choices);self.project_crs.currentTextChanged.connect(self._describe_project_crs);self._describe_project_crs()
        self.tabs.addTab(page,"Referencia espacial")

    def _build_project_tab(self):
        page=QWidget();layout=QVBoxLayout(page);self.project_table=QTableWidget(0,7)
        self.project_table.setHorizontalHeaderLabels(["Orden","UWI","Nombre","LAS","Cimas","En sección","Estado"])
        self.project_table.setSelectionBehavior(QAbstractItemView.SelectRows);self.project_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        toolbar=QHBoxLayout();self.add_project_button=QPushButton("Agregar desde catálogo…");self.add_project_button.clicked.connect(self._show_catalog)
        self.section_button=QPushButton("Ocultar de sección");self.section_button.clicked.connect(self.toggle_section_visibility)
        self.up_button=QPushButton("Subir");self.up_button.clicked.connect(lambda:self.move_project_well(-1))
        self.down_button=QPushButton("Bajar");self.down_button.clicked.connect(lambda:self.move_project_well(1))
        toolbar.addWidget(self.add_project_button);toolbar.addSpacing(8);toolbar.addWidget(self.section_button)
        toolbar.addSpacing(8);toolbar.addWidget(self.up_button);toolbar.addWidget(self.down_button);toolbar.addStretch();layout.addLayout(toolbar);layout.addWidget(self.project_table)
        self.project_table.itemSelectionChanged.connect(self._update_project_actions);self.project_table.cellDoubleClicked.connect(self._project_cell_double_clicked)
        self.tabs.addTab(page,"Sección")

    def _build_map_tab(self):
        page=QWidget();layout=QVBoxLayout(page);toolbar=QHBoxLayout()
        add_button=QPushButton("Agregar desde catálogo…");add_button.clicked.connect(self._show_catalog)
        self.map_context_button=QPushButton("Mostrar en mapa");self.map_context_button.clicked.connect(self.toggle_map_visibility_from_map)
        edit_button=QPushButton("Editar coordenadas…");edit_button.clicked.connect(self.edit_selected_map_well)
        open_button=QPushButton("Abrir mapa");open_button.clicked.connect(self._open_map_window);open_button.setEnabled(bool(self.map_callback))
        toolbar.addWidget(add_button);toolbar.addSpacing(8);toolbar.addWidget(self.map_context_button);toolbar.addWidget(edit_button);toolbar.addWidget(open_button);toolbar.addStretch();layout.addLayout(toolbar)
        self.map_table=QTableWidget(0,9);self.map_table.setHorizontalHeaderLabels(["UWI","Nombre","LAT","LONG","X proyecto","Y proyecto","CRS proyecto","En mapa","Validación"])
        self.map_table.setSelectionBehavior(QAbstractItemView.SelectRows);self.map_table.setSelectionMode(QAbstractItemView.ExtendedSelection);layout.addWidget(self.map_table)
        self.map_table.itemSelectionChanged.connect(self._update_map_actions);self.map_table.cellDoubleClicked.connect(self._map_cell_double_clicked)
        self.tabs.addTab(page,"Mapa")

    def _build_catalog_tab(self):
        page=QWidget();layout=QVBoxLayout(page);self.catalog_filter=QLineEdit();self.catalog_filter.setPlaceholderText("Filtrar por UWI, nombre, operador, campo o estado…")
        layout.addWidget(self.catalog_filter);toolbar=QHBoxLayout()
        for text,slot in (("Crear pozo…",lambda:self.edit_well_record(None)),("Editar",self.edit_selected_well),
                          ("Agregar al proyecto",self.add_selected_to_project),("Quitar del proyecto",self.remove_selected_catalog_from_project),
                          ("Exportar CSV…",self.export_selected_wells),
                          ("Eliminar definitivamente…",self.delete_selected_wells)):
            button=QPushButton(text);button.clicked.connect(slot);toolbar.addWidget(button)
        toolbar.addStretch();layout.addLayout(toolbar);self.catalog_table=QTableWidget(0,10)
        self.catalog_table.setHorizontalHeaderLabels(["UWI","Nombre","Operador","Campo","LAT","LONG","LAS","Cimas","Estado","En proyecto actual"])
        self.catalog_table.setSelectionBehavior(QAbstractItemView.SelectRows);self.catalog_table.setSelectionMode(QAbstractItemView.ExtendedSelection);layout.addWidget(self.catalog_table)
        self.catalog_filter.textChanged.connect(self.filter_catalog);self.tabs.addTab(page,"Pozos del proyecto")

    def _build_import_tab(self):
        page=QWidget();layout=QVBoxLayout(page);layout.addWidget(QLabel(
            "Importe una lista desde Excel, CSV o TXT. Antes de guardar podrá asignar las columnas, revisar una vista previa y resolver UWI duplicados."))
        button=QPushButton("Seleccionar archivo e importar…");button.clicked.connect(self.import_table_file);layout.addWidget(button);layout.addStretch()
        self.import_summary=QLabel("Aún no se ha realizado ninguna importación.");layout.addWidget(self.import_summary);self.tabs.addTab(page,"Importar datos")

    def refresh_all(self):
        self.refresh_project_table();self.refresh_map_table();self.refresh_catalog_table()

    def refresh_project_table(self):
        self.project_table.setRowCount(len(self.project.wells))
        for row,well in enumerate(self.project.wells):
            status="Listo para correlación" if well.has_log_data else "Sin LAS"
            values=(row+1,well.uwi,well.name,"Sí" if well.has_log_data else "No",len(well.tops),
                    "Visible" if self.project.well_visible_in_section(well.uwi) else "Oculto",status)
            for column,value in enumerate(values):self.project_table.setItem(row,column,self._read_only(QTableWidgetItem("" if value is None else str(value))))
        header=self.project_table.horizontalHeader();header.setSectionResizeMode(QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2,QHeaderView.Stretch);header.setSectionResizeMode(6,QHeaderView.Stretch);self._update_project_actions()

    def refresh_map_table(self):
        self.map_table.setRowCount(len(self.project.wells))
        for row,well in enumerate(self.project.wells):
            data=well.coordinate_data or {};target=self.project.spatial_reference.get("horizontal_crs","EPSG:4326");point=coordinates_in_project(data,target);warning=original_coordinate_warning(data)
            values=(well.uwi,well.name,data.get("latitude"),data.get("longitude"),None if point is None else point[0],None if point is None else point[1],target,
                    "Visible" if self.project.well_visible_on_map(well.uwi) else "Oculto",warning or ("Válidas" if point else "Faltantes o no transformables"))
            for column,value in enumerate(values):self.map_table.setItem(row,column,self._read_only(QTableWidgetItem("" if value is None else str(value))))
        header=self.map_table.horizontalHeader();header.setSectionResizeMode(QHeaderView.ResizeToContents);header.setSectionResizeMode(1,QHeaderView.Stretch)
        self._update_map_actions()

    def selected_project_rows(self):
        return sorted({index.row() for index in self.project_table.selectionModel().selectedRows()})

    def _show_catalog(self):
        self.tabs.setCurrentIndex(2);self.catalog_filter.setFocus()

    def _update_footer(self,index):
        is_section=index==3;self.remove_project_button.setVisible(is_section);self.selection_label.setVisible(is_section)

    def _update_project_actions(self):
        rows=self.selected_project_rows();wells=[self.project.wells[row] for row in rows if row<len(self.project.wells)]
        enabled=bool(wells);single=len(wells)==1
        self.section_button.setEnabled(enabled)
        self.up_button.setEnabled(single and rows[0]>0 if single else False);self.down_button.setEnabled(single and rows[0]<len(self.project.wells)-1 if single else False)
        self.remove_project_button.setEnabled(enabled)
        if not wells:
            self.section_button.setText("Mostrar en sección");self.selection_label.setText("Ningún pozo seleccionado");return
        section_all=all(self.project.well_visible_in_section(well.uwi) for well in wells)
        self.section_button.setText("Ocultar de sección" if section_all else "Mostrar en sección")
        self.selection_label.setText(wells[0].name if single else f"{len(wells)} pozos seleccionados")

    def refresh_catalog_table(self):
        self.catalog_rows=self.geodata.well_catalog();las_uwis={str(item["uwi"]) for item in self.las_repository.entries()};active={str(well.uwi) for well in self.project.wells}
        self.catalog_table.setRowCount(len(self.catalog_rows))
        for row,record in enumerate(self.catalog_rows):
            meta=record.get("metadata",{});values=(record["uwi"],record["name"],meta.get("operator",""),meta.get("field",""),record.get("latitude"),record.get("longitude"),
                "Sí" if str(record["uwi"]) in las_uwis else "No",record.get("top_count",0),meta.get("status",""),"Sí" if str(record["uwi"]) in active else "No")
            for column,value in enumerate(values):self.catalog_table.setItem(row,column,self._read_only(QTableWidgetItem("" if value is None else str(value))))
            self.catalog_table.item(row,0).setData(Qt.UserRole,str(record["uwi"]))
        self.catalog_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents);self.filter_catalog(self.catalog_filter.text())

    def selected_catalog_uwis(self):
        return list(dict.fromkeys(str(self.catalog_table.item(index.row(),0).data(Qt.UserRole)) for index in self.catalog_table.selectionModel().selectedRows()))

    def _describe_project_crs(self):
        try:
            info=describe_crs(self._selected_crs_code());self.project_crs_description.setText(f'{info["code"]} · {info["name"]} · {info["type"]} · {info["units"]}')
        except ValueError as exc:self.project_crs_description.setText(str(exc))

    def _selected_crs_code(self):
        return self.project_crs.currentData() or self.project_crs.currentText().split("—",1)[0].strip()

    def _select_crs_on_map(self):
        dialog=CrsMapSelectorDialog(self.project.wells,self)
        if dialog.exec()!=QDialog.Accepted or not dialog.selected_crs:return
        category=practical_crs_category(dialog.selected_crs);self.crs_category.setCurrentText(category);self._populate_crs_choices(dialog.selected_crs)
        self.selection_label.setText(f"CRS recomendado: {dialog.selected_crs}. Pulse Aplicar para guardarlo.")

    def _populate_crs_choices(self,selected=None):
        code=selected if isinstance(selected,str) and selected.upper().startswith("EPSG:") else self._selected_crs_code() if hasattr(self,"project_crs") else "EPSG:4326"
        category=self.crs_category.currentText();self.project_crs.blockSignals(True);self.project_crs.clear()
        for item_code,name in self.crs_catalog.get(category,[]):self.project_crs.addItem(f"{item_code} — {name}",item_code)
        index=self.project_crs.findData(code)
        if index>=0:self.project_crs.setCurrentIndex(index)
        else:self.project_crs.setEditText(code if category=="Manual / otro EPSG" else (self.project_crs.itemText(0) if self.project_crs.count() else code))
        self.project_crs.blockSignals(False);self._describe_project_crs()

    def _apply_project_settings(self):
        if not self.project_name.text().strip():QMessageBox.warning(self,"Nombre requerido","Introduzca el nombre del proyecto.");return
        try:info=describe_crs(self._selected_crs_code())
        except ValueError as exc:QMessageBox.warning(self,"CRS no válido",str(exc));return
        try:elevation=float(self.default_elevation.text()) if self.default_elevation.text().strip() else None
        except ValueError:QMessageBox.warning(self,"Elevación no válida","Introduzca un número o deje el campo vacío.");return
        self.project.name=self.project_name.text().strip();self.project.project_metadata={"area":self.project_area.text().strip(),"field":self.project_field.text().strip(),
            "operator":self.project_operator.text().strip(),"author":self.project_author.text().strip(),"description":self.project_description.toPlainText().strip()}
        self.project.spatial_reference={"horizontal_crs":info["code"],"horizontal_name":info["name"],"horizontal_type":info["type"],"coordinate_units":info["units"],
            "transform_coordinates":self.transform_coordinates.isChecked(),"show_original_coordinates":self.show_original_coordinates.isChecked(),
            "vertical_reference":self.vertical_reference.currentText(),"vertical_units":self.vertical_units.currentText(),"default_elevation":elevation}
        refresh_project_coordinate_cache(self.project);self.geodata.sync_project(self.project,reason="project_administrator");self.refresh_callback();self.refresh_map_table()
        self.setWindowTitle(f"Administrador de proyecto — {self.project.name}");self.selection_label.setText("Cambios aplicados")

    def _apply_record_to_active(self,record):
        well=next((well for well in self.project.wells if str(well.uwi)==str(record["uwi"])),None)
        if well is None:return False
        well.name=str(record["name"]);well.well_metadata=dict(record.get("metadata",{}));well.coordinate_data=dict(record.get("coordinate_data",{}))
        well.reference_elevation=record.get("reference_elevation")
        if is_valid_geographic(well.coordinate_data):well.x=well.coordinate_data["longitude"];well.y=well.coordinate_data["latitude"]
        return True

    def filter_catalog(self,text):
        needle=str(text).strip().casefold()
        for row in range(self.catalog_table.rowCount()):
            content=" ".join(self.catalog_table.item(row,col).text() for col in range(self.catalog_table.columnCount())).casefold()
            self.catalog_table.setRowHidden(row,bool(needle and needle not in content))

    def remove_from_project(self):
        rows=self.selected_project_rows()
        if not rows:QMessageBox.information(self,"Seleccionar pozo","Seleccione uno o más pozos del proyecto.");return
        wells=[self.project.wells[row] for row in rows];description=wells[0].name if len(wells)==1 else f"{len(wells)} pozos seleccionados"
        if QMessageBox.question(self,"Quitar del proyecto",f"¿Quitar {description} del proyecto abierto?\n\nLos pozos permanecerán en la base de datos.",QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
        for row in reversed(rows):
            well=self.project.wells.pop(row);self.project.hidden_section_wells.discard(str(well.uwi));self.project.hidden_map_wells.discard(str(well.uwi));self.project.well_track_discretizations.pop(str(well.uwi),None);self.project.well_track_properties.pop(str(well.uwi),None)
        current={str(well.uwi) for well in self.project.wells};self.project.active_section_well_order=[uwi for uwi in self.project.active_section_well_order if uwi in current]
        self.geodata.sync_project(self.project,reason="remove_from_project");self.refresh_callback();self.refresh_all()

    def remove_selected_catalog_from_project(self):
        uwis=set(self.selected_catalog_uwis());active=[well for well in self.project.wells if str(well.uwi) in uwis]
        if not active:QMessageBox.information(self,"Quitar del proyecto","Los pozos seleccionados no pertenecen al proyecto actual.");return
        if QMessageBox.question(self,"Quitar del proyecto",f"¿Quitar {len(active)} pozo(s) del proyecto actual?\n\nPermanecerán en la base de datos.",
            QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
        removed={str(well.uwi) for well in active};self.project.wells=[well for well in self.project.wells if str(well.uwi) not in removed]
        self.project.hidden_section_wells-=removed;self.project.hidden_map_wells-=removed
        for uwi in removed:self.project.well_track_discretizations.pop(uwi,None);self.project.well_track_properties.pop(uwi,None)
        self.project.active_section_well_order=[uwi for uwi in self.project.active_section_well_order if uwi not in removed]
        self.geodata.sync_project(self.project,reason="catalog_remove_from_project");self.refresh_callback();self.refresh_all()

    def _toggle_project_visibility(self,target):
        rows=self.selected_project_rows()
        if not rows:QMessageBox.information(self,"Seleccionar pozo","Seleccione uno o más pozos del proyecto.");return
        wells=[self.project.wells[row] for row in rows]
        make_visible=not all(self.project.well_visible_in_section(well.uwi) for well in wells);hidden=self.project.hidden_section_wells;reason="set_section_visibility"
        for well in wells:
            if make_visible:hidden.discard(str(well.uwi))
            else:hidden.add(str(well.uwi))
        # Una edición manual de visibilidad abandona el filtro exclusivo de una sección aplicada.
        self.project.active_section_well_order=[];self.project.active_section_line_id=None
        self.geodata.sync_project(self.project,reason=reason);self.refresh_callback();self.refresh_project_table()
        selection=self.project_table.selectionModel()
        for row in rows:selection.select(self.project_table.model().index(row,0),QItemSelectionModel.Select|QItemSelectionModel.Rows)

    def _project_cell_double_clicked(self,row,column):
        if column!=5:return
        self.project_table.clearSelection();self.project_table.selectRow(row)
        self._toggle_project_visibility("section")

    def selected_map_rows(self):
        return sorted({index.row() for index in self.map_table.selectionModel().selectedRows()})

    def _update_map_actions(self):
        rows=self.selected_map_rows();wells=[self.project.wells[row] for row in rows if row<len(self.project.wells)]
        self.map_context_button.setEnabled(bool(wells))
        self.map_context_button.setText("Ocultar del mapa" if wells and all(self.project.well_visible_on_map(well.uwi) for well in wells) else "Mostrar en mapa")

    def toggle_map_visibility_from_map(self):
        rows=self.selected_map_rows()
        if not rows:QMessageBox.information(self,"Seleccionar pozo","Seleccione uno o más pozos del mapa.");return
        wells=[self.project.wells[row] for row in rows];make_visible=not all(self.project.well_visible_on_map(well.uwi) for well in wells)
        for well in wells:
            if make_visible:self.project.hidden_map_wells.discard(str(well.uwi))
            else:self.project.hidden_map_wells.add(str(well.uwi))
        self.geodata.sync_project(self.project,reason="set_map_visibility");self.refresh_callback();self.refresh_map_table()
        selection=self.map_table.selectionModel()
        for row in rows:selection.select(self.map_table.model().index(row,0),QItemSelectionModel.Select|QItemSelectionModel.Rows)

    def _map_cell_double_clicked(self,row,column):
        if column!=7:return
        self.map_table.clearSelection();self.map_table.selectRow(row);self.toggle_map_visibility_from_map()

    def edit_selected_map_well(self):
        rows=self.selected_map_rows()
        if len(rows)!=1:QMessageBox.information(self,"Seleccionar pozo","Seleccione exactamente un pozo para editar sus coordenadas.");return
        well=self.project.wells[rows[0]];record=self.geodata.well_record(str(well.uwi))
        if record:self.edit_well_record(record)

    def _open_map_window(self):
        if not self.map_callback:return
        self.accept();self.map_callback()

    def toggle_section_visibility(self):self._toggle_project_visibility("section")

    def move_project_well(self,direction):
        row=self.project_table.currentRow();target=row+direction
        if row<0 or target<0 or target>=len(self.project.wells):return
        self.project.wells[row],self.project.wells[target]=self.project.wells[target],self.project.wells[row]
        self.geodata.sync_project(self.project,reason="reorder_wells");self.refresh_callback();self.refresh_all();self.project_table.setCurrentCell(target,0)

    def edit_selected_well(self):
        uwis=self.selected_catalog_uwis()
        if len(uwis)!=1:QMessageBox.information(self,"Seleccionar pozo","Seleccione exactamente un pozo.");return
        self.edit_well_record(self.geodata.well_record(uwis[0]))

    def edit_well_record(self,record):
        dialog=QDialog(self);dialog.setWindowTitle("Datos básicos del pozo — Editar" if record else "Datos básicos del pozo — Nuevo");layout=QGridLayout(dialog)
        fields={};specs=(("UWI *","uwi"),("Nombre *","name"),("Operador","operator"),("Campo","field"),("Latitud","latitude"),("Longitud","longitude"),
                         ("CRS","crs"),("Elevación de referencia","elevation"),("Estado","status"),("Observaciones","notes"))
        meta=(record or {}).get("metadata",{});coordinate=(record or {}).get("coordinate_data",{})
        values={"uwi":(record or {}).get("uwi",""),"name":(record or {}).get("name",""),"operator":meta.get("operator",""),"field":meta.get("field",""),
                "latitude":coordinate.get("latitude","") or "","longitude":coordinate.get("longitude","") or "","crs":coordinate.get("crs") or "EPSG:4326",
                "elevation":(record or {}).get("reference_elevation","") or "","status":meta.get("status",""),"notes":meta.get("notes","")}
        for row,(label,key) in enumerate(specs):layout.addWidget(QLabel(label),row,0);fields[key]=QLineEdit(str(values[key]));layout.addWidget(fields[key],row,1)
        if record:fields["uwi"].setReadOnly(True)
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject);layout.addWidget(buttons,len(specs),0,1,2)
        if dialog.exec()!=QDialog.Accepted:return
        uwi=fields["uwi"].text().strip();name=fields["name"].text().strip()
        if not uwi or not name:QMessageBox.warning(self,"Datos incompletos","UWI y nombre son obligatorios.");return
        lat=fields["latitude"].text().strip();lon=fields["longitude"].text().strip()
        coordinate_data=(record or {}).get("coordinate_data",{}) or empty_coordinate_data()
        if lat or lon:
            if not lat or not lon:QMessageBox.warning(self,"Coordenadas incompletas","Introduzca latitud y longitud.");return
            coordinate_data=coordinate_data_from_values(lat,lon,latitude_field="MANUAL_LAT",longitude_field="MANUAL_LONG",source_file="Administrador de pozos")
            coordinate_data["crs"]=fields["crs"].text().strip() or "EPSG:4326"
            if coordinate_data.get("validation_status")!="valid":QMessageBox.warning(self,"Coordenadas no válidas",coordinate_data.get("validation_message",""));return
        try:elevation=float(fields["elevation"].text()) if fields["elevation"].text().strip() else None
        except ValueError:QMessageBox.warning(self,"Elevación no válida","Introduzca un valor numérico.");return
        result=self.geodata.upsert_well_record({"uwi":uwi,"name":name,"reference_elevation":elevation,"coordinate_data":coordinate_data,
            "metadata":{"operator":fields["operator"].text().strip(),"field":fields["field"].text().strip(),"status":fields["status"].text().strip(),"notes":fields["notes"].text().strip(),"source":"manual"}})
        if self._apply_record_to_active(self.geodata.well_record(uwi)):refresh_project_coordinate_cache(self.project);self.refresh_callback()
        self.import_summary.setText(f"Pozo {result}: {name} · {uwi}");self.refresh_all()

    def _well_from_catalog(self,record):
        entries={str(item["uwi"]):item for item in self.las_repository.entries()}
        if str(record["uwi"]) in entries:
            try:well=self.las_repository.load_well(str(record["uwi"]))
            except Exception:well=None
        else:well=None
        if well is None:well=Well(str(record["name"]),str(record["uwi"]),np.asarray([],float),{})
        well.name=str(record["name"]);well.well_metadata=dict(record.get("metadata",{}));well.coordinate_data=dict(record.get("coordinate_data",{}))
        if is_valid_geographic(well.coordinate_data):well.x=well.coordinate_data["longitude"];well.y=well.coordinate_data["latitude"]
        well.reference_elevation=record.get("reference_elevation");return well

    def add_selected_to_project(self):
        uwis=self.selected_catalog_uwis()
        if not uwis:QMessageBox.information(self,"Seleccionar pozos","Seleccione uno o más pozos de la base de datos.");return
        active={str(well.uwi) for well in self.project.wells};incoming=[]
        for uwi in uwis:
            if uwi not in active:
                record=self.geodata.well_record(uwi)
                if record:incoming.append(self._well_from_catalog(record))
        added,updated=self.project.add_or_replace_wells(incoming);self.geodata.sync_project(self.project,reason="catalog_add")
        self.refresh_callback();self.refresh_all();self.tabs.setCurrentIndex(3)
        self.import_summary.setText(f"Agregados al proyecto: {added}. Ya presentes: {len(uwis)-added}.")

    def delete_selected_wells(self):
        uwis=self.selected_catalog_uwis()
        if not uwis:return
        names=[self.geodata.well_record(uwi)["name"] for uwi in uwis if self.geodata.well_record(uwi)]
        if QMessageBox.warning(self,"Eliminación definitiva",f"Se eliminarán definitivamente {len(uwis)} pozo(s), sus asociaciones y datos relacionados:\n\n"+", ".join(names)+"\n\n¿Continuar?",
            QMessageBox.Yes|QMessageBox.No,QMessageBox.No)!=QMessageBox.Yes:return
        active={str(well.uwi) for well in self.project.wells}
        if any(uwi in active for uwi in uwis):QMessageBox.warning(self,"Pozos en el proyecto","Quite primero del proyecto los pozos que desea eliminar definitivamente.");return
        errors=[]
        for uwi in uwis:
            try:self.geodata.delete_well(uwi);self.las_repository.delete(uwi)
            except Exception as exc:errors.append(f"{uwi}: {exc}")
        self.refresh_all()
        if errors:QMessageBox.warning(self,"No se eliminaron algunos pozos","\n".join(errors))

    def export_selected_wells(self):
        uwis=self.selected_catalog_uwis()
        if not uwis:QMessageBox.information(self,"Seleccionar pozos","Seleccione uno o más pozos.");return
        path,_=QFileDialog.getSaveFileName(self,"Exportar lista de pozos","pozos.csv","CSV (*.csv)")
        if not path:return
        if not path.lower().endswith(".csv"):path += ".csv"
        import csv
        with Path(path).open("w",encoding="utf-8-sig",newline="") as stream:
            writer=csv.writer(stream);writer.writerow(["UWI","NOMBRE","OPERADOR","CAMPO","LATI","LONG","CRS","ELEVACION","ESTADO","OBSERVACIONES"])
            for uwi in uwis:
                record=self.geodata.well_record(uwi);meta=record.get("metadata",{});coord=record.get("coordinate_data",{})
                writer.writerow([record["uwi"],record["name"],meta.get("operator",""),meta.get("field",""),coord.get("latitude",""),coord.get("longitude",""),
                    coord.get("crs",""),record.get("reference_elevation","") or "",meta.get("status",""),meta.get("notes","")])
        self.import_summary.setText(f"Se exportaron {len(uwis)} pozos a {Path(path).name}.")

    @staticmethod
    def _read_table(path):
        import pandas as pd
        suffix=Path(path).suffix.lower()
        if suffix in {".xlsx",".xls"}:return pd.read_excel(path,dtype=str,keep_default_na=False)
        if suffix==".csv":return pd.read_csv(path,dtype=str,keep_default_na=False)
        return pd.read_csv(path,sep=None,engine="python",dtype=str,keep_default_na=False)

    def import_table_file(self):
        path,_=QFileDialog.getOpenFileName(self,"Importar lista de pozos","","Tablas (*.xlsx *.xls *.csv *.txt);;Todos (*.*)")
        if not path:return
        try:frame=self._read_table(path)
        except Exception as exc:QMessageBox.critical(self,"No fue posible leer",str(exc));return
        frame.columns=[str(column).strip() for column in frame.columns];mapping=self._mapping_dialog(frame)
        if mapping is None:return
        import pandas as pd
        policy=None;created=updated=omitted=0;imported_uwis=[]
        for _,row in frame.iterrows():
            def value(key):
                column=mapping.get(key)
                if not column or pd.isna(row[column]) or not str(row[column]).strip():return None
                return row[column]
            uwi=str(value("uwi") or "").strip();name=str(value("name") or "").strip()
            if not uwi or not name:omitted+=1;continue
            existing=self.geodata.well_record(uwi)
            if existing and policy not in {"update_all","omit_all"}:
                answer=QMessageBox.question(self,"UWI duplicado",f"{uwi} ya existe como {existing['name']}.\nImportado: {name}\n\n¿Actualizar con los datos importados?",
                    QMessageBox.Yes|QMessageBox.YesToAll|QMessageBox.No|QMessageBox.NoToAll|QMessageBox.Cancel,QMessageBox.No)
                if answer==QMessageBox.Cancel:break
                if answer==QMessageBox.YesToAll:policy="update_all"
                elif answer==QMessageBox.NoToAll:policy="omit_all"
                elif answer==QMessageBox.No:omitted+=1;continue
            if existing and policy=="omit_all":omitted+=1;continue
            lat=value("latitude");lon=value("longitude");coordinate=existing.get("coordinate_data",{}) if existing else empty_coordinate_data()
            if (lat is None)!=(lon is None):omitted+=1;continue
            if lat is not None and lon is not None:
                coordinate=coordinate_data_from_values(lat,lon,latitude_field=mapping["latitude"],longitude_field=mapping["longitude"],source_file=path)
                coordinate["crs"]=str(value("crs") or "EPSG:4326")
                if coordinate.get("validation_status")!="valid":omitted+=1;continue
            try:elevation=float(value("elevation")) if value("elevation") is not None else None
            except (TypeError,ValueError):elevation=None
            result=self.geodata.upsert_well_record({"uwi":uwi,"name":name,"reference_elevation":elevation,"coordinate_data":coordinate,
                "metadata":{"operator":str(value("operator") or ""),"field":str(value("field") or ""),"status":str(value("status") or ""),
                            "notes":str(value("notes") or ""),"source":Path(path).name}})
            self._apply_record_to_active(self.geodata.well_record(uwi))
            created+=result=="created";updated+=result=="updated";imported_uwis.append(uwi)
        if updated:self.refresh_callback()
        self.refresh_all();self.import_summary.setText(f"Importación: {created} creados, {updated} actualizados, {omitted} omitidos.")
        if imported_uwis and QMessageBox.question(self,"Importación terminada","¿Agregar al proyecto abierto los pozos importados?",QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)==QMessageBox.Yes:
            active={str(well.uwi) for well in self.project.wells};incoming=[]
            for uwi in dict.fromkeys(imported_uwis):
                if uwi not in active:
                    record=self.geodata.well_record(uwi)
                    if record:incoming.append(self._well_from_catalog(record))
            added,_=self.project.add_or_replace_wells(incoming);self.geodata.sync_project(self.project,reason="table_import_add")
            self.refresh_callback();self.refresh_all();self.tabs.setCurrentIndex(3);self.import_summary.setText(self.import_summary.text()+f" Agregados al proyecto: {added}.")

    def _mapping_dialog(self,frame):
        dialog=QDialog(self);dialog.setWindowTitle("Asignar columnas de importación");dialog.resize(950,560);layout=QVBoxLayout(dialog)
        mapping_grid=QGridLayout();columns=list(frame.columns);selectors={}
        specs=(("UWI *","uwi",("UWI","API","WELL_ID","ID_POZO")),("Nombre *","name",("NOMBRE","POZO","WELL","WELL_NAME")),
               ("Operador","operator",("OPERADOR","OPERATOR")),("Campo","field",("CAMPO","FIELD")),("Latitud","latitude",("LATI","LAT","LATITUDE")),
               ("Longitud","longitude",("LONG","LON","LONGITUDE")),("CRS","crs",("CRS","EPSG")),("Elevación","elevation",("ELEV","ELEVATION","KB")),
               ("Estado","status",("ESTADO","STATUS")),("Observaciones","notes",("OBSERVACIONES","NOTES","COMMENTS")))
        for row,(label,key,candidates) in enumerate(specs):
            combo=QComboBox();combo.addItem("— No importar —",None)
            for column in columns:combo.addItem(column,column)
            normalized={str(column).strip().upper():column for column in columns};match=next((normalized[c] for c in candidates if c in normalized),None)
            if match is not None:combo.setCurrentIndex(combo.findData(match))
            mapping_grid.addWidget(QLabel(label),row,0);mapping_grid.addWidget(combo,row,1);selectors[key]=combo
        layout.addLayout(mapping_grid);preview=QTableWidget(min(20,len(frame)),len(columns));preview.setHorizontalHeaderLabels(columns)
        for row in range(preview.rowCount()):
            for column,name in enumerate(columns):preview.setItem(row,column,self._read_only(QTableWidgetItem(str(frame.iloc[row][name]))))
        preview.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents);layout.addWidget(preview)
        buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject);layout.addWidget(buttons)
        if dialog.exec()!=QDialog.Accepted:return None
        result={key:combo.currentData() for key,combo in selectors.items()}
        if not result["uwi"] or not result["name"]:QMessageBox.warning(self,"Asignación incompleta","Asigne las columnas UWI y Nombre.");return None
        return result
