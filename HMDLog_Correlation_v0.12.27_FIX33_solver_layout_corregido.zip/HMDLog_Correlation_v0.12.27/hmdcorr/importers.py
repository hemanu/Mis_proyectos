from pathlib import Path
import re

import numpy as np
import pandas as pd

from .models import Well
from .coordinates import (LATITUDE_KEYS,LONGITUDE_KEYS,X_KEYS,Y_KEYS,
                          coordinate_data_from_values,is_valid_geographic)


def _las_number(las, names):
    for section_name in ("well","params"):
        section=getattr(las,section_name,None)
        if section is None:continue
        for name in names:
            try:value=section[name].value
            except (KeyError,TypeError,AttributeError):continue
            try:return float(str(value).replace(",","").strip())
            except (TypeError,ValueError):continue
    return None


def _las_raw(las,names):
    for section_name in ("well","params"):
        section=getattr(las,section_name,None)
        if section is None:continue
        for name in names:
            try:value=section[name].value
            except (KeyError,TypeError,AttributeError):continue
            if value is not None and str(value).strip() not in {"","NULL","NONE"}:return value,name
    return None,None


def load_las(path: str | Path) -> Well:
    try:
        import lasio
    except ImportError as exc:
        raise RuntimeError("Falta lasio. Ejecute: python -m pip install lasio") from exc

    path = Path(path)
    las = lasio.read(path)
    depth = np.asarray(las.index, dtype=float)
    curves = {}
    curve_units = {}
    for curve in las.curves:
        mnemonic = curve.mnemonic.strip().upper()
        if mnemonic == las.index_unit or mnemonic in {"DEPT", "DEPTH"}:
            continue
        values = np.asarray(las[curve.mnemonic], dtype=float)
        if values.size == depth.size:
            curves[mnemonic] = values
            curve_units[mnemonic] = str(getattr(curve,"unit","") or "").strip()

    well_name = str(las.well.WELL.value).strip() if "WELL" in las.well else path.stem
    uwi = str(las.well.UWI.value).strip() if "UWI" in las.well else path.stem
    api,_api_field=_las_raw(las,("API","API_NUMBER","API_NO","APIN"))
    latitude,latitude_field=_las_raw(las,LATITUDE_KEYS);longitude,longitude_field=_las_raw(las,LONGITUDE_KEYS)
    raw_x,x_field=_las_raw(las,X_KEYS);raw_y,y_field=_las_raw(las,Y_KEYS)
    coordinates=coordinate_data_from_values(latitude,longitude,latitude_field=latitude_field,longitude_field=longitude_field,
        x_value=raw_x,y_value=raw_y,x_field=x_field,y_field=y_field,source_file=path)
    if is_valid_geographic(coordinates):x=coordinates["longitude"];y=coordinates["latitude"]
    else:
        try:x=float(str(raw_x).replace(",","")) if raw_x is not None else None
        except (TypeError,ValueError):x=None
        try:y=float(str(raw_y).replace(",","")) if raw_y is not None else None
        except (TypeError,ValueError):y=None
    elevation=_las_number(las,("KB","EKB","DF","GL","ELEV","ELEVATION"))
    return Well(name=well_name or path.stem, uwi=uwi or path.stem, depth=depth, curves=curves,
                depth_unit=str(getattr(las,"index_unit","") or "").strip(),curve_units=curve_units,
                x=x,y=y,reference_elevation=elevation,coordinate_data=coordinates,
                well_metadata={"API":str(api).strip()} if api is not None else {})


def _normalized_identifier(value) -> str:
    return re.sub(r"[^A-Z0-9]","",str(value).strip().upper())


def load_tops(path: str | Path, wells: list[Well], return_report: bool = False):
    path = Path(path)
    table = pd.read_excel(path) if path.suffix.lower() in {".xlsx", ".xls"} else pd.read_csv(path)
    table.columns = [str(column).strip().upper() for column in table.columns]
    def find_column(candidates):return next((name for name in candidates if name in table.columns),None)
    formation_col=find_column(("FORMATION","FORMACION","FORMACIÓN","CIMA","TOP_NAME","HORIZONTE","UNIDAD"))
    depth_col=find_column(("TOP","DEPTH","PROFUNDIDAD","MD","TOP_MD"))
    uwi_col=find_column(("UWI","API","WELL_ID","ID_POZO"))
    name_col=find_column(("WELL_NAME","WELL","POZO","NOMBRE_POZO"))
    if formation_col is None or depth_col is None or (uwi_col is None and name_col is None):
        raise ValueError("El archivo requiere CIMA/FORMATION, TOP/PROFUNDIDAD y UWI o POZO/WELL_NAME.")

    by_uwi = {_normalized_identifier(well.uwi): well for well in wells}
    by_name = {_normalized_identifier(well.name): well for well in wells}
    count=0;unmatched=[];outside=[]
    for _, row in table.iterrows():
        well = None
        if uwi_col and pd.notna(row[uwi_col]):
            identifier=_normalized_identifier(row[uwi_col]);well=by_uwi.get(identifier) or by_name.get(identifier)
        if well is None and name_col and pd.notna(row[name_col]):
            identifier=_normalized_identifier(row[name_col]);well=by_name.get(identifier) or by_uwi.get(identifier)
        if well is None:
            unmatched.append(str(row[uwi_col] if uwi_col and pd.notna(row[uwi_col]) else row[name_col]));continue
        if pd.notna(row[depth_col]) and pd.notna(row[formation_col]):
            depth=float(row[depth_col]);name=str(row[formation_col]).strip();well.tops[name]=depth
            count += 1
            if np.asarray(well.depth).size and (depth<float(np.nanmin(well.depth)) or depth>float(np.nanmax(well.depth))):outside.append(f"{well.name}: {name} ({depth:g})")
    report={"count":count,"unmatched":sorted(set(unmatched)),"outside":outside,"rows":len(table)}
    return report if return_report else count
