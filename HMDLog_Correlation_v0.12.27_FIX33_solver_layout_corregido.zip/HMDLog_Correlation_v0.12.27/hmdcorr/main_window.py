from pathlib import Path
import json
import numpy as np

from PySide6.QtCore import Qt, QSettings, QStandardPaths
from PySide6.QtGui import QAction, QActionGroup, QColor
from PySide6.QtWidgets import (
    QComboBox,
    QCheckBox,
    QFileDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QDockWidget,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QAbstractItemView,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QStatusBar,
    QStackedWidget,
    QTabWidget,
    QColorDialog,
    QInputDialog,
    QFormLayout,
    QHBoxLayout,
    QGroupBox,
    QVBoxLayout,
    QWidget,
)

from .canvas import CorrelationCanvas
from .demo import create_demo_project
from .importers import load_las, load_tops
from .models import CorrelationProject
from .viewer_template import load_template, save_template
from .project_io import load_project, save_project
from .well_repository import WellRepository
from .geodata_repository import GeoDataRepository
from .coordinates import (coordinate_data_from_values,is_valid_geographic,
                          validate_manual_geographic,haversine_meters)
from .well_map import WellMapDialog
from .well_manager import ProjectAdministratorDialog
from .spatial_reference import coordinates_in_project,refresh_project_coordinate_cache
from .rendering import probe_vispy
from .track_manager import TrackManagerDialog


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.project = CorrelationProject()
        self.setWindowTitle("HMDLog Correlation v0.12.27 — Restricciones de layout corregidas")
        self.resize(1220, 760)
        self.settings = QSettings("HMDLog", "HMDLog Correlation")
        stored_backend=str(self.settings.value("rendering/backend","vispy") or "vispy")
        backend_origin=str(self.settings.value("rendering/backend_origin","") or "")
        # Las versiones anteriores guardaban Matplotlib después de cualquier
        # excepción GPU. Ese fallback no representa una elección del usuario.
        self.render_backend="vispy" if stored_backend=="matplotlib" and backend_origin!="user" else stored_backend
        self.project_path=None;self._dirty=False;self._loading=True
        repository_root=Path(QStandardPaths.writableLocation(QStandardPaths.AppDataLocation))/"well_repository"
        self.repository=WellRepository(repository_root)
        self.geodata=GeoDataRepository(repository_root.parent/"hmdcorr_geodata.db")
        self._map_windows=[]
        self.demo_active=False
        self._build_ui()
        self._apply_theme(str(self.settings.value("appearance/theme", "Claro técnico")))
        self._restore_startup_workspace();self._loading=False;self._apply_render_backend(self.render_backend,initial=True,persist=False)

    def _build_ui(self):
        self.canvas = CorrelationCanvas()
        self.render_stack=QStackedWidget(self);self.render_stack.addWidget(self.canvas)
        self.gpu_host=QWidget(self);self.gpu_host_layout=QVBoxLayout(self.gpu_host);self.gpu_host_layout.setContentsMargins(0,0,0,0)
        self.render_stack.addWidget(self.gpu_host);self.gpu_canvas=None
        self.setCentralWidget(self.render_stack)
        self.setStatusBar(QStatusBar())
        self.canvas.message_callback=self._zoom_message
        self.canvas.correlation_callback=self._complete_assisted_correlation
        self.canvas.top_edit_callback=self._complete_top_edit
        self.canvas.header_edit_callback=self._edit_single_header_alias

        # Panel contextual: permanece oculto hasta que el usuario solicita editar.
        self.context_dock = QDockWidget("Configuración", self)
        self.context_dock.setObjectName("contextDock")
        self.context_dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.context_tabs = QTabWidget()
        self.context_dock.setWidget(self.context_tabs)
        self.addDockWidget(Qt.RightDockWidgetArea, self.context_dock)
        self.context_dock.hide()

        tracks_page = QWidget(); visibility_row = QVBoxLayout(tracks_page)
        self.visible_track = QComboBox(); self.toggle_track_button = QPushButton("Apagar track")
        self.visible_curve = QComboBox(); self.toggle_curve_button = QPushButton("Agregar al track")
        self.mirror_curve_check = QCheckBox("Imagen especular en este track")
        self.duplicate_mirror_button = QPushButton("Duplicar como imagen especular…")
        self.apply_track_curve_changes = QPushButton("Aplicar cambios")
        self.apply_track_curve_changes.setEnabled(False)
        self.lithology_check = QCheckBox("Track de litología HMDLog"); self.lithology_check.setChecked(True)
        visibility_row.addWidget(QLabel("Track activo")); visibility_row.addWidget(self.visible_track); visibility_row.addWidget(self.toggle_track_button)
        visibility_row.addSpacing(8); visibility_row.addWidget(QLabel("Curva disponible")); visibility_row.addWidget(self.visible_curve); visibility_row.addWidget(self.toggle_curve_button)
        visibility_row.addSpacing(8); visibility_row.addWidget(QLabel("Presentación en este track")); visibility_row.addWidget(self.mirror_curve_check); visibility_row.addWidget(self.duplicate_mirror_button)
        visibility_row.addSpacing(8); visibility_row.addWidget(self.lithology_check)
        visibility_row.addWidget(QLabel("Las asignaciones se acumulan sin reconstruir la escena."));visibility_row.addWidget(self.apply_track_curve_changes);visibility_row.addStretch()
        self.context_tabs.addTab(tracks_page, "Tracks y curvas")

        self.well_dock = QDockWidget("Pozos cargados", self)
        self.well_dock.setObjectName("wellDock")
        self.well_dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.well_list = QListWidget(); self.well_list.setMinimumWidth(135)
        self.well_dock.setWidget(self.well_list); self.addDockWidget(Qt.LeftDockWidgetArea, self.well_dock); self.well_dock.hide()

        self._build_menus()

        self.datum_combo = QComboBox()
        self.datum_combo.addItem("Profundidad MD", None)
        self.datum_combo.currentIndexChanged.connect(self.refresh_plot)
        self.toggle_track_button.clicked.connect(self._toggle_track)
        self.toggle_curve_button.clicked.connect(self._toggle_curve)
        self.mirror_curve_check.toggled.connect(self._set_active_curve_mirror)
        self.duplicate_mirror_button.clicked.connect(self._duplicate_curve_as_mirror)
        self.apply_track_curve_changes.clicked.connect(self._commit_curve_admin_changes)
        self.visible_track.currentIndexChanged.connect(self._update_visibility_buttons)
        self.visible_curve.currentIndexChanged.connect(self._update_visibility_buttons)
        self.lithology_check.toggled.connect(self._toggle_lithology)
        self.well_dock.visibilityChanged.connect(self.show_wells_action.setChecked)
        self.context_dock.visibilityChanged.connect(self._sync_context_actions)

    def _action(self, menu, text, slot=None, checkable=False):
        action=QAction(text,self); action.setCheckable(checkable)
        if slot: action.triggered.connect(slot)
        menu.addAction(action); return action

    def _build_menus(self):
        bar=self.menuBar(); bar.clear()
        project_menu=bar.addMenu("Proyecto")
        self._action(project_menu,"Nuevo proyecto…",self.new_project)
        self._action(project_menu,"Abrir proyecto…",self.open_project)
        recent_menu=project_menu.addMenu("Proyectos recientes")
        recent_path=str(self.settings.value("startup/last_project","") or "")
        recent_action=self._action(recent_menu,Path(recent_path).name if recent_path else "No hay proyectos recientes",
            lambda checked=False,p=recent_path:self._open_project_path(p))
        recent_action.setEnabled(bool(recent_path and Path(recent_path).is_file()))
        self._action(project_menu,"Guardar proyecto",self.save_project)
        self._action(project_menu,"Guardar proyecto como…",self.save_project_as)
        project_menu.addSeparator();self._action(project_menu,"Administrador de proyecto…",self._open_project_administrator)
        import_menu=project_menu.addMenu("Importar")
        self._action(import_menu,"Pozos LAS…",self.open_las_files);self._action(import_menu,"Cimas o topes…",self.open_tops_file)
        export_menu=project_menu.addMenu("Exportar");self._action(export_menu,"Panel SVG/PDF/PNG…",self.export_figure)
        self._action(project_menu,"Abrir proyecto de demostración",self.load_demo)
        project_menu.addSeparator();self._action(project_menu,"Cerrar proyecto",self.close_project)
        self._action(project_menu,"Salir",self.close)

        wells_menu=bar.addMenu("Pozos")
        self.show_wells_action=self._action(wells_menu,"Pozos cargados",lambda checked:self.well_dock.setVisible(checked),True)
        self._action(wells_menu,"Mover pozo arriba",lambda:self._move_well(-1))
        self._action(wells_menu,"Mover pozo abajo",lambda:self._move_well(1))
        self._action(wells_menu,"Distancias entre pozos…",self._show_distances)
        self._action(wells_menu,"Mapa de pozos…",self._show_well_map)
        headers_menu=wells_menu.addMenu("Encabezados de pozos")
        header_group=QActionGroup(self);header_group.setExclusive(True);self.header_mode_actions={}
        for label,mode in (("NAME","NAME"),("UWI","UWI"),("API","API"),("NAME + UWI","NAME_UWI"),("NAME + API","NAME_API"),("Nombre personalizado","CUSTOM")):
            action=self._action(headers_menu,label,lambda checked,m=mode:self._set_header_identifier_mode(m),True)
            header_group.addAction(action);self.header_mode_actions[mode]=action
        headers_menu.addSeparator();self._action(headers_menu,"Editar nombres visibles…",self._edit_header_aliases)
        self._action(headers_menu,"Restaurar nombres visibles",self._restore_header_aliases)
        wells_menu.addSeparator()
        spacing_group=QActionGroup(self); spacing_group.setExclusive(True)
        self.spacing_actions={}
        for label,mode in (("Separación proporcional","proportional"),("Separación uniforme","uniform")):
            a=self._action(wells_menu,label,lambda checked,m=mode:self._set_spacing(m),True); spacing_group.addAction(a); self.spacing_actions[mode]=a

        tracks_menu=bar.addMenu("Tracks y curvas")
        self.manage_tracks_action=self._action(tracks_menu,"Configurar tracks y retícula…",lambda:self._manage_tracks())
        self._action(tracks_menu,"Administrar curvas…",lambda:self._show_context(0))
        self._action(tracks_menu,"Duplicar curva como imagen especular…",self._duplicate_curve_as_mirror)
        self._action(tracks_menu,"Discretización litológica por referencia…",self._configure_track_discretization)
        self.lithology_action=self._action(tracks_menu,"Track de litología HMDLog",self._menu_toggle_lithology,True)

        correlation_menu=bar.addMenu("Correlación")
        self.datum_menu=correlation_menu.addMenu("Seleccionar datum")
        self.show_tops_action=self._action(correlation_menu,"Mostrar topes",self._toggle_tops,True); self.show_tops_action.setChecked(True)
        self._action(correlation_menu,"Administrar cimas manualmente…",self._manage_tops_manually)
        tops_db_menu=correlation_menu.addMenu("Base de datos de cimas")
        self._action(tops_db_menu,"Guardar cimas del proyecto",self._save_tops_database)
        self._action(tops_db_menu,"Mostrar tabla de cimas…",self._show_tops_database)
        self._action(tops_db_menu,"Revisar historial…",self._show_top_history)
        self._action(tops_db_menu,"Exportar cimas a CSV…",self._export_tops_database)
        self.edit_tops_action=self._action(correlation_menu,"Editar cimas con cursor",self._toggle_top_edit,True)
        self.edit_tops_action.setShortcut("E")
        self.protect_datum_action=self._action(correlation_menu,"Proteger cima usada como datum",self._toggle_datum_protection,True)
        self.protect_datum_action.setChecked(True)
        self.assisted_action=self._action(correlation_menu,"Correlación asistida por arrastre…",self._start_assisted_correlation)
        self.assisted_action.setShortcut("C")
        undo=self._action(correlation_menu,"Deshacer último cambio de cima",self._undo_assisted_correlation)
        undo.setShortcut("Ctrl+Z")
        zoom_menu=correlation_menu.addMenu("Navegación y zoom")
        zoom_group=QActionGroup(self);zoom_group.setExclusive(True);self.zoom_actions={}
        for label,mode,shortcut in (("Zoom por intervalo","interval","I"),("Zoom areal","area","A")):
            action=self._action(zoom_menu,label,lambda checked,m=mode:self._set_zoom_mode(m),True);action.setShortcut(shortcut);zoom_group.addAction(action);self.zoom_actions[mode]=action
        self.zoom_actions["interval"].setChecked(True)
        reset_zoom=self._action(zoom_menu,"Restablecer zoom",self._reset_zoom);reset_zoom.setShortcut("R")
        zoom_menu.addSeparator()
        self.data_cursor_action=self._action(zoom_menu,"Cursor de datos",self._toggle_data_cursor,True)
        cursor_enabled=str(self.settings.value("navigation/data_cursor","true")).lower() not in {"false","0"}
        self.data_cursor_action.setChecked(cursor_enabled);self.canvas.set_data_cursor_enabled(cursor_enabled)
        self._action(correlation_menu,"Grosor de líneas…",self._choose_line_width)
        self._action(correlation_menu,"Color de horizonte…",self._choose_top_color)
        self._action(correlation_menu,"Apariencia de cimas…",self._edit_top_appearance)

        templates_menu=bar.addMenu("Plantillas")
        self._action(templates_menu,"Cargar plantilla HMDLog…",self.open_template)
        self._action(templates_menu,"Guardar plantilla…",self.save_current_template)
        self._action(templates_menu,"Restablecer plantilla",self._restore_template)

        appearance_menu=bar.addMenu("Apariencia")
        theme_menu=appearance_menu.addMenu("Tema visual")
        group=QActionGroup(self); group.setExclusive(True); self.theme_actions={}
        for name in ("Claro técnico","Gris profesional","Oscuro","Alto contraste"):
            action=self._action(theme_menu,name,lambda checked,n=name:self._apply_theme(n),True); group.addAction(action); self.theme_actions[name]=action
        appearance_menu.addSeparator()
        gpu_menu=appearance_menu.addMenu("Motor gráfico")
        self._action(gpu_menu,"Abrir vista GPU experimental…",self._open_vispy_preview)
        self._action(gpu_menu,"Comprobar compatibilidad GPU…",self._show_gpu_status)
        gpu_menu.addSeparator()
        backend_group=QActionGroup(self);backend_group.setExclusive(True);self.backend_actions={}
        for label,backend in (("VisPy / OpenGL · principal","vispy"),("Matplotlib · compatibilidad","matplotlib")):
            action=self._action(gpu_menu,label,lambda checked,b=backend:self._apply_render_backend(b),True)
            backend_group.addAction(action);self.backend_actions[backend]=action
        self.backend_actions.get(self.render_backend,self.backend_actions["vispy"]).setChecked(True)
        appearance_menu.addSeparator()
        self._action(appearance_menu,"Fondo del área de trabajo…",lambda:self._choose_background("workspace_background","Área de trabajo"))
        self._action(appearance_menu,"Fondo de tracks…",lambda:self._choose_background("track_background","Tracks"))
        self._action(appearance_menu,"Color de cuadrícula…",lambda:self._choose_background("grid_color","Cuadrícula"))
        self._action(appearance_menu,"Restaurar apariencia",self._restore_appearance)
        preferences_menu=appearance_menu.addMenu("Preferencias de aplicación")
        startup_menu=preferences_menu.addMenu("Comportamiento al iniciar")
        startup_group=QActionGroup(self);startup_group.setExclusive(True);self.startup_mode_actions={}
        for label,mode in (("Reabrir último proyecto","last"),("Iniciar con ventana limpia","clean")):
            action=self._action(startup_menu,label,lambda checked,m=mode:self._set_startup_mode(m),True)
            startup_group.addAction(action);self.startup_mode_actions[mode]=action
        startup_mode=str(self.settings.value("startup/mode","last"))
        self.startup_mode_actions.get(startup_mode,self.startup_mode_actions["last"]).setChecked(True)

        help_menu=bar.addMenu("Ayuda")
        self._action(help_menu,"Manual del usuario",self._show_manual)
        self._action(help_menu,"Acerca de HMDLog Correlation",self._show_about)

    def load_demo(self):
        self.project = create_demo_project()
        self.project_path=None
        self.demo_active=True
        self._load_preferred_template()
        self._refresh_controls()
        self.statusBar().showMessage("Demostración cargada: 5 pozos y 3 horizontes.", 5000)

    def open_project(self):
        if not self._confirm_project_transition():return
        path,_=QFileDialog.getOpenFileName(self,"Abrir proyecto HMDLog Correlation","","Proyecto HMDLog Correlation (*.hmdcorr)")
        if not path:return
        self._open_project_path(path,confirm=False)

    def _open_project_path(self,path,confirm=True):
        if not path:return
        if confirm and not self._confirm_project_transition():return
        try:
            self._loading=True;self.project=load_project(path);refresh_project_coordinate_cache(self.project);self.project_path=path;self.demo_active=False;self._refresh_controls()
            self.geodata.sync_project(self.project,path,"project_open")
            self.settings.setValue("startup/last_project",path);self._dirty=False
            self.statusBar().showMessage(f"Proyecto abierto: {Path(path).name}",5000)
        except Exception as exc: QMessageBox.critical(self,"Proyecto no válido",str(exc))
        finally:self._loading=False

    def save_project(self):
        if self.project_path:return self._write_project(self.project_path)
        return self.save_project_as()

    def save_project_as(self):
        path,_=QFileDialog.getSaveFileName(self,"Guardar proyecto HMDLog Correlation","correlacion.hmdcorr","Proyecto HMDLog Correlation (*.hmdcorr)")
        if not path:return False
        if not path.lower().endswith(".hmdcorr"):path += ".hmdcorr"
        return self._write_project(path)

    def _write_project(self,path):
        try:
            save_project(path,self.project);report=self.geodata.sync_project(self.project,path,"project_save");self.project_path=path;self._dirty=False
            self.settings.setValue("startup/last_project",path)
            self.statusBar().showMessage(f'Proyecto y base de datos guardados: {Path(path).name} · {report["created"]} nuevas, {report["updated"]} actualizadas.',7000);return True
        except Exception as exc:QMessageBox.critical(self,"No fue posible guardar",str(exc));return False

    def _confirm_project_transition(self):
        if not self._dirty:return True
        answer=QMessageBox.warning(self,"Cambios sin guardar","El proyecto actual contiene cambios sin guardar.",
            QMessageBox.Save|QMessageBox.Discard|QMessageBox.Cancel,QMessageBox.Save)
        if answer==QMessageBox.Cancel:return False
        return self.save_project() if answer==QMessageBox.Save else True

    def new_project(self):
        if not self._confirm_project_transition():return
        self.project=CorrelationProject();self.project_path=None;self.demo_active=False;self._load_preferred_template();self._refresh_controls();self._dirty=False
        self._open_project_administrator()

    def close_project(self):
        if not self._confirm_project_transition():return
        self.project=CorrelationProject();self.project_path=None;self.demo_active=False;self._load_preferred_template();self._refresh_controls();self._dirty=False
        self.statusBar().showMessage("Proyecto cerrado. Área de trabajo limpia.",5000)

    def _set_startup_mode(self,mode):
        self.settings.setValue("startup/mode",mode)
        self.startup_mode_actions[mode].setChecked(True)
        message="Se reabrirá el último proyecto guardado." if mode=="last" else "La próxima sesión iniciará con el área de trabajo limpia."
        self.statusBar().showMessage(message,5000)

    def _restore_startup_workspace(self):
        mode=str(self.settings.value("startup/mode","last"));last=str(self.settings.value("startup/last_project","") or "")
        if mode=="last" and last and Path(last).is_file():
            try:
                self.project=load_project(last);refresh_project_coordinate_cache(self.project);self.project_path=last;self.demo_active=False;self._refresh_controls();self._dirty=False
                self.statusBar().showMessage(f"Último proyecto recuperado: {Path(last).name}",7000);return
            except Exception as exc:
                self.statusBar().showMessage(f"No se pudo recuperar el último proyecto; se inició una ventana limpia: {exc}",9000)
        self.project=CorrelationProject();self.project_path=None;self.demo_active=False
        self._load_preferred_template();self._refresh_controls();self._dirty=False

    def closeEvent(self,event):
        if not self._dirty:event.accept();return
        answer=QMessageBox.warning(self,"Cambios sin guardar","El proyecto contiene cambios sin guardar.",
            QMessageBox.Save|QMessageBox.Discard|QMessageBox.Cancel,QMessageBox.Save)
        if answer==QMessageBox.Cancel:event.ignore();return
        if answer==QMessageBox.Save and not self.save_project():event.ignore();return
        event.accept()

    def open_las_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Seleccionar pozos LAS", "", "Archivos LAS (*.las);;Todos (*.*)")
        if not paths:
            return
        wells = []; source_by_uwi={}
        errors = []
        for path in paths:
            try:
                well=load_las(path);self._resolve_coordinate_data(well);wells.append(well);source_by_uwi[str(well.uwi)]=path
            except Exception as exc:
                errors.append(f"{Path(path).name}: {exc}")
        if wells:
            if self.demo_active:
                self.project=CorrelationProject(name="Panel de correlación")
                self._load_preferred_template();self.demo_active=False
            added,updated=self.project.add_or_replace_wells(wells)
            refresh_project_coordinate_cache(self.project)
            for well in wells:
                try:self.repository.register(source_by_uwi[str(well.uwi)],well)
                except Exception as exc:errors.append(f"Repositorio {well.name}: {exc}")
            self._sync_geodata("las_import")
            self._refresh_controls()
            self.well_dock.show()
            self.statusBar().showMessage(f"Repositorio actualizado: {added} pozo(s) agregado(s), {updated} actualizado(s). Total en el área: {len(self.project.wells)}",7000)
        if errors:
            QMessageBox.warning(self, "Archivos no cargados", "\n".join(errors))

    def open_tops_file(self):
        if not self.project.wells:
            QMessageBox.information(self, "Sin pozos", "Primero cargue los pozos LAS.")
            return
        path, _ = QFileDialog.getOpenFileName(self, "Importar topes", "", "Tablas (*.csv *.xlsx *.xls)")
        if not path:
            return
        try:
            report=load_tops(path,self.project.wells,return_report=True)
            for well in self.project.wells:
                for name in well.tops:
                    well.top_metadata.setdefault(name,{}).update(source=Path(path).name,method="file_import")
            self._sync_geodata("file_import")
            self._refresh_controls()
            message=f'Se importaron {report["count"]} cimas de {report["rows"]} registros.'
            details=[]
            if report["unmatched"]:details.append("Pozos no identificados: "+", ".join(report["unmatched"][:12]))
            if report["outside"]:details.append("Cimas fuera del intervalo LAS: "+", ".join(report["outside"][:12]))
            self.statusBar().showMessage(message,7000)
            if details:QMessageBox.warning(self,"Importación de cimas",message+"\n\n"+"\n".join(details))
        except Exception as exc:
            QMessageBox.critical(self, "No fue posible importar", str(exc))

    def _manage_tops_manually(self):
        if not self.project.wells:
            QMessageBox.information(self,"Sin pozos","Primero cargue los pozos LAS.");return
        dialog=QDialog(self);dialog.setWindowTitle("Administrar cimas manualmente");dialog.resize(620,440)
        layout=QVBoxLayout(dialog)
        well_combo=QComboBox()
        for well in self.project.wells:well_combo.addItem(f"{well.name} · {well.uwi}",well.uwi)
        top_name=QLineEdit();depth_edit=QLineEdit()
        layout.addWidget(QLabel("Pozo"));layout.addWidget(well_combo);layout.addWidget(QLabel("Nombre de la cima"));layout.addWidget(top_name);layout.addWidget(QLabel("Profundidad MD"));layout.addWidget(depth_edit)
        save_button=QPushButton("Guardar / actualizar cima");delete_button=QPushButton("Eliminar cima seleccionada")
        layout.addWidget(save_button);layout.addWidget(delete_button)
        table=QTableWidget(0,3);table.setHorizontalHeaderLabels(["Pozo","Cima","Profundidad MD"]);table.setSelectionBehavior(QAbstractItemView.SelectRows);table.setSelectionMode(QAbstractItemView.SingleSelection);table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch);layout.addWidget(table)
        close_buttons=QDialogButtonBox(QDialogButtonBox.Close);close_buttons.rejected.connect(dialog.reject);layout.addWidget(close_buttons)
        def selected_well():return next(w for w in self.project.wells if str(w.uwi)==str(well_combo.currentData()))
        def refresh_table():
            table.setRowCount(0)
            for well in self.project.wells:
                for name,depth in sorted(well.tops.items(),key=lambda item:item[1]):
                    row=table.rowCount();table.insertRow(row)
                    for column,value in enumerate((well.name,name,f"{depth:g}")):table.setItem(row,column,QTableWidgetItem(str(value)))
                    table.item(row,0).setData(Qt.UserRole,well.uwi)
        def save_top():
            well=selected_well();name=top_name.text().strip()
            try:depth=float(depth_edit.text())
            except ValueError:QMessageBox.warning(dialog,"Profundidad no válida","Introduzca una profundidad numérica.");return
            if not name:QMessageBox.warning(dialog,"Cima sin nombre","Introduzca el nombre de la cima.");return
            if np.asarray(well.depth).size:
                minimum=float(well.depth.min());maximum=float(well.depth.max())
                if depth<minimum or depth>maximum:
                    QMessageBox.warning(dialog,"Cima fuera del registro",f"La profundidad debe estar entre {minimum:g} y {maximum:g}.");return
            previous=well.tops.get(name);well.tops[name]=depth
            metadata=well.top_metadata.setdefault(name,{})
            metadata.update(method="manual_entry" if previous is None else "manual_adjustment",source="manual")
            self._sync_geodata("manual_top");refresh_table();self._refresh_controls();top_name.clear();depth_edit.clear()
        def select_row():
            row=table.currentRow()
            if row<0:return
            uwi=table.item(row,0).data(Qt.UserRole);idx=well_combo.findData(uwi)
            if idx>=0:well_combo.setCurrentIndex(idx)
            top_name.setText(table.item(row,1).text());depth_edit.setText(table.item(row,2).text())
        def delete_top():
            row=table.currentRow()
            if row<0:return
            uwi=str(table.item(row,0).data(Qt.UserRole));name=table.item(row,1).text()
            well=next(w for w in self.project.wells if str(w.uwi)==uwi);well.tops.pop(name,None);well.top_metadata.pop(name,None)
            self._sync_geodata("manual_delete");refresh_table();self._refresh_controls()
        save_button.clicked.connect(save_top);delete_button.clicked.connect(delete_top);table.itemSelectionChanged.connect(select_row)
        refresh_table();dialog.exec();self._refresh_controls()

    def _start_assisted_correlation(self):
        if self.render_backend=="vispy" and self.gpu_canvas:
            self.gpu_canvas._configure_assisted_correlation();return
        self.edit_tops_action.setChecked(False);self.canvas.set_top_edit_enabled(False)
        candidates=[well for well in self.project.wells if well.tops and well.curves]
        if len(self.project.wells)<2 or not candidates:
            QMessageBox.information(self,"Correlación asistida","Se requieren al menos dos pozos y una cima en el pozo de origen.");return
        labels=[f"{well.name} · {well.uwi}" for well in candidates]
        label,ok=QInputDialog.getItem(self,"Correlación asistida","Pozo de origen:",labels,0,False)
        if not ok:return
        source=candidates[labels.index(label)]
        tops=list(sorted(source.tops,key=source.tops.get));top_name,ok=QInputDialog.getItem(self,"Correlación asistida","Cima que desea transferir:",tops,0,False)
        if not ok:return
        displayed=set()
        for track in self.project.visible_tracks():
            for curve in self.project.viewer_template.get("curves",[]):
                mnemonic=str(curve.get("source","")).upper()
                if curve.get("track_key")==track.get("key") and mnemonic in source.curves and self.project.curve_visible(mnemonic):displayed.add(mnemonic)
        curves=sorted(displayed)
        if not curves:QMessageBox.information(self,"Correlación asistida","El pozo de origen no tiene curvas visibles para comparar.");return
        curve,ok=QInputDialog.getItem(self,"Correlación asistida","Curva patrón:",curves,0,False)
        if not ok:return
        unit=source.depth_unit or "unidades de profundidad"
        above,ok=QInputDialog.getDouble(self,"Intervalo patrón",f"Extensión por encima de la cima ({unit}):",50.0,.1,100000.0,2)
        if not ok:return
        below,ok=QInputDialog.getDouble(self,"Intervalo patrón",f"Extensión por debajo de la cima ({unit}):",50.0,.1,100000.0,2)
        if not ok:return
        try:
            self.canvas.begin_assisted_correlation(source.uwi,top_name,curve,above,below)
            self.statusBar().showMessage(f"Pulse sobre {curve} en {source.name}, arrastre al mismo track de un pozo vecino y suelte. Esc cancela.")
        except Exception as exc:QMessageBox.warning(self,"No se puede iniciar",str(exc))

    def _complete_assisted_correlation(self,payload):
        if payload.get("undo"):
            self._undo_assisted_correlation();return
        source=next(w for w in self.project.wells if str(w.uwi)==payload["source_uwi"])
        target=next(w for w in self.project.wells if str(w.uwi)==payload["target_uwi"])
        answer=QMessageBox.question(self,"Confirmar cima interpretada",
            f'Crear "{payload["top_name"]}" en {target.name} a MD {payload["target_depth"]:.2f}?\n\nOrigen: {source.name}\nCurva patrón: {payload["curve"]}',
            QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)
        if answer!=QMessageBox.Yes:self.statusBar().showMessage("Transferencia cancelada; no se modificó ninguna cima.",5000);return
        self.project.transfer_top(payload["source_uwi"],payload["target_uwi"],payload["top_name"],
                                  payload["target_depth"],payload["curve"],tuple(payload["interval"]))
        self._sync_geodata("assisted_drag")
        self._refresh_controls();self.statusBar().showMessage(f'Cima {payload["top_name"]} transferida a {target.name}. Ctrl+Z para deshacer.',7000)

    def _undo_assisted_correlation(self):
        record=self.project.undo_last_correlation()
        if not record:self.statusBar().showMessage("No hay cambios de cimas para deshacer.",4000);return
        self._sync_geodata("undo")
        self._refresh_controls();self.statusBar().showMessage(f'Se deshizo el último cambio de {record["top_name"]}.',6000)

    def _toggle_top_edit(self,enabled):
        if enabled and not self.project.wells:
            self.edit_tops_action.setChecked(False);QMessageBox.information(self,"Editar cimas","Primero cargue los pozos y sus cimas.");return
        if self.render_backend=="vispy" and self.gpu_canvas:
            self.gpu_canvas.edit_tops_button.setChecked(bool(enabled))
        else:self.canvas.set_top_edit_enabled(bool(enabled))
        if enabled:
            tops_were_hidden=not self.project.show_tops
            self.project.show_tops=True;self.show_tops_action.setChecked(True)
            if tops_were_hidden:
                navigation=self.canvas.capture_navigation_state();self.refresh_plot();self.canvas.restore_navigation_state(navigation)
            self.statusBar().showMessage("Editor de cimas activo: arrastre una línea verticalmente; doble clic permite introducir MD. Esc cancela.",8000)
        else:self.statusBar().showMessage("Editor de cimas desactivado.",4000)

    def _toggle_datum_protection(self,enabled):
        self.canvas.protect_datum_top=bool(enabled)
        self.statusBar().showMessage("La cima usada como datum está protegida." if enabled else "Protección del datum desactivada: la cima de referencia puede editarse.",5000)

    def _complete_top_edit(self,payload):
        well=next((w for w in self.project.wells if str(w.uwi)==str(payload["well_uwi"])),None)
        if well is None:return
        name=payload["top_name"];old=float(well.tops[name])
        if payload.get("manual_request"):
            dialog=QDialog(self);dialog.setWindowTitle("Editar valor de la cima");layout=QVBoxLayout(dialog)
            unit=well.depth_unit or "";layout.addWidget(QLabel(f"Pozo: {well.name}\nUWI: {well.uwi}\nCima: {name}\nMD actual: {old:.3f}{(' '+unit) if unit else ''}"))
            depth_box=QDoubleSpinBox();depth_box.setDecimals(3);depth_box.setRange(float(np.nanmin(well.depth)),float(np.nanmax(well.depth)))
            depth_box.setValue(old);depth_box.setSuffix(f" {unit}" if unit else "");depth_box.setSingleStep(.5)
            snap_check=QCheckBox("Ajustar a la muestra más cercana del LAS");snap_check.setChecked(True)
            layout.addWidget(QLabel("Nueva profundidad MD"));layout.addWidget(depth_box);layout.addWidget(snap_check)
            buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject);layout.addWidget(buttons)
            if dialog.exec()!=QDialog.Accepted:return
            target=float(depth_box.value());method="direct_value_edit"
            if snap_check.isChecked():
                nearest=int(np.nanargmin(np.abs(np.asarray(well.depth,float)-target)));target=float(well.depth[nearest])
        else:
            target=float(payload["target_depth"]);method="cursor_adjustment"
            answer=QMessageBox.question(self,"Confirmar ajuste de cima",
                f'{well.name} — {name}\n\nMD anterior: {old:.2f}\nMD propuesta: {target:.2f}\n\n¿Aplicar este ajuste?',
                QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)
            if answer!=QMessageBox.Yes:self.statusBar().showMessage("Ajuste cancelado; se conserva la profundidad original.",5000);return
        if not payload.get("manual_request"):
            nearest=int(np.nanargmin(np.abs(np.asarray(well.depth,float)-target)));target=float(well.depth[nearest])
        if abs(target-old)<1e-12:self.statusBar().showMessage("La cima ya se encuentra en esa muestra de profundidad.",4000);return
        navigation=self.canvas.capture_navigation_state()
        self.project.adjust_top(well.uwi,name,target,method)
        self._sync_geodata(method)
        self._refresh_controls();self.canvas.restore_navigation_state(navigation)
        self.statusBar().showMessage(f'{name} ajustada en {well.name}: {old:.2f} → {target:.2f}. Ctrl+Z para deshacer.',7000)

    def _sync_geodata(self,reason="project_edit"):
        try:return self.geodata.sync_project(self.project,self.project_path,reason)
        except Exception as exc:
            self.statusBar().showMessage(f"El proyecto conserva las cimas, pero no se pudo actualizar la base local: {exc}",9000)
            return None

    def _save_tops_database(self):
        report=self._sync_geodata("manual_database_save")
        if report is not None:
            QMessageBox.information(self,"Base de datos de cimas",
                f'Se sincronizaron las cimas de {len(self.project.wells)} pozos.\n\nNuevas: {report["created"]}\nActualizadas: {report["updated"]}\nEliminadas: {report["deleted"]}')

    def _show_tops_database(self):
        self._sync_geodata("catalog_view")
        try:rows=self.geodata.tops_catalog()
        except Exception as exc:QMessageBox.critical(self,"No fue posible consultar",str(exc));return
        dialog=QDialog(self);dialog.setWindowTitle("Tabla de cimas almacenadas");dialog.resize(1120,560);layout=QVBoxLayout(dialog)
        search=QLineEdit();search.setPlaceholderText("Filtrar por proyecto, pozo, UWI, cima, fuente o método…");layout.addWidget(search)
        table=QTableWidget(len(rows),10);table.setHorizontalHeaderLabels(
            ["Proyecto","Pozo","UWI","Cima","MD","Unidad","Fuente","Método","Actualizado UTC","Estado"])
        table.setSelectionBehavior(QAbstractItemView.SelectRows);table.setSelectionMode(QAbstractItemView.SingleSelection)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        wells={str(well.uwi):well for well in self.project.wells}
        def status_for(record):
            well=wells.get(str(record["uwi"]))
            if well is None:return "Otro pozo"
            if str(record["top_name"]) not in well.tops:return "No está en el proyecto"
            return "Ya está visible" if abs(float(well.tops[str(record["top_name"])])-float(record["depth"]))<1e-9 else "Valor diferente"
        for row_index,record in enumerate(rows):
            status=status_for(record);values=(record.get("project_name",""),record.get("well_name",""),record.get("uwi",""),record.get("top_name",""),
                f'{float(record["depth"]):g}',record.get("depth_unit") or "",record.get("source") or "",record.get("method") or "",record.get("updated_utc") or "",status)
            for column,value in enumerate(values):table.setItem(row_index,column,QTableWidgetItem(str(value)))
            table.item(row_index,0).setData(Qt.UserRole,record)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents);layout.addWidget(table)
        action=QPushButton("Seleccione una cima");action.setEnabled(False);layout.addWidget(action)
        close_buttons=QDialogButtonBox(QDialogButtonBox.Close);close_buttons.rejected.connect(dialog.reject);layout.addWidget(close_buttons)
        def selected_record():
            row=table.currentRow();return table.item(row,0).data(Qt.UserRole) if row>=0 and table.item(row,0) else None
        def update_action():
            record=selected_record()
            if not record:action.setText("Seleccione una cima");action.setEnabled(False);return
            status=status_for(record)
            labels={"No está en el proyecto":"Mostrar cima seleccionada en el proyecto",
                    "Valor diferente":"Actualizar cima del proyecto","Ya está visible":"La cima ya está visible","Otro pozo":"El pozo no está en el proyecto"}
            action.setText(labels[status]);action.setEnabled(status in {"No está en el proyecto","Valor diferente"})
        def apply_selected():
            record=selected_record()
            if not record:return
            well=wells.get(str(record["uwi"]));name=str(record["top_name"]);depth=float(record["depth"]);previous=well.tops.get(name)
            if previous is not None:
                difference=depth-float(previous)
                answer=QMessageBox.question(dialog,"Confirmar actualización",
                    f'{well.name} — {name}\n\nValor actual: {float(previous):.3f} {well.depth_unit}\nValor almacenado: {depth:.3f} {record.get("depth_unit") or well.depth_unit}\nDiferencia: {difference:+.3f} {well.depth_unit}\n\n¿Actualizar la cima del proyecto?',
                    QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
                if answer!=QMessageBox.Yes:return
            else:
                answer=QMessageBox.question(dialog,"Mostrar cima en el proyecto",
                    f'Incorporar {name} a {well.name} en MD {depth:.3f} {record.get("depth_unit") or well.depth_unit}?',
                    QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)
                if answer!=QMessageBox.Yes:return
            try:metadata=json.loads(record.get("metadata_json") or "{}")
            except (TypeError,json.JSONDecodeError):metadata={}
            navigation=self.canvas.capture_navigation_state();self.project.adopt_database_top(well.uwi,name,depth,metadata)
            if record.get("color"):self.project.top_colors[name]=str(record["color"])
            try:style=json.loads(record.get("style_json") or "{}")
            except (TypeError,json.JSONDecodeError):style={}
            if style:self.project.set_top_style(name,style)
            self._sync_geodata("database_selection");self._refresh_controls();self.canvas.restore_navigation_state(navigation)
            self.statusBar().showMessage(f"{name} incorporada desde la tabla de cimas. Ctrl+Z para deshacer.",7000);dialog.accept()
        def filter_rows(text):
            needle=text.strip().casefold()
            for row in range(table.rowCount()):
                haystack=" ".join(table.item(row,column).text() for column in range(table.columnCount())).casefold()
                table.setRowHidden(row,bool(needle and needle not in haystack))
        table.itemSelectionChanged.connect(update_action);action.clicked.connect(apply_selected);search.textChanged.connect(filter_rows)
        dialog.exec()

    def _show_top_history(self):
        rows=self.geodata.top_history(self.project.project_id)
        dialog=QDialog(self);dialog.setWindowTitle("Historial de cimas");dialog.resize(900,480)
        layout=QVBoxLayout(dialog);table=QTableWidget(len(rows),8)
        table.setHorizontalHeaderLabels(["Fecha UTC","Pozo","UWI","Cima","Anterior","Nueva","Acción","Método"])
        for row_index,row in enumerate(rows):
            values=(row.get("changed_utc",""),row.get("well_name") or "",row.get("uwi",""),row.get("top_name",""),
                    "" if row.get("previous_depth") is None else f'{row["previous_depth"]:g}',
                    "" if row.get("new_depth") is None else f'{row["new_depth"]:g}',row.get("action",""),row.get("method") or "")
            for column,value in enumerate(values):table.setItem(row_index,column,QTableWidgetItem(str(value)))
        table.setEditTriggers(QAbstractItemView.NoEditTriggers);table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        layout.addWidget(table);buttons=QDialogButtonBox(QDialogButtonBox.Close);buttons.rejected.connect(dialog.reject);layout.addWidget(buttons);dialog.exec()

    def _export_tops_database(self):
        self._sync_geodata("database_export")
        path,_=QFileDialog.getSaveFileName(self,"Exportar cimas de la base de datos","cimas_proyecto.csv","CSV (*.csv)")
        if not path:return
        if not path.lower().endswith(".csv"):path += ".csv"
        try:
            count=self.geodata.export_tops_csv(self.project.project_id,path)
            self.statusBar().showMessage(f"Se exportaron {count} cimas: {Path(path).name}",7000)
        except Exception as exc:QMessageBox.critical(self,"No fue posible exportar",str(exc))

    def _edit_top_appearance(self):
        names=self.project.top_names
        if not names:QMessageBox.information(self,"Sin cimas","Primero importe o cree al menos una cima.");return
        dialog=QDialog(self);dialog.setWindowTitle("Apariencia de cimas");dialog.resize(420,520);layout=QVBoxLayout(dialog)
        top_combo=QComboBox();top_combo.addItems(names);size_box=QDoubleSpinBox();size_box.setRange(5,24);size_box.setDecimals(1);size_box.setSingleStep(.5)
        type_combo=QComboBox();type_combo.addItem("Normal",False);type_combo.addItem("Cursiva",True)
        bold_check=QCheckBox("Negrita");highlight_check=QCheckBox("Resaltado con fondo")
        text_button=QPushButton("Color del texto…");background_button=QPushButton("Color del resaltado…")
        preview=QLabel("Vista previa de la cima");preview.setAlignment(Qt.AlignCenter);preview.setMinimumHeight(54)
        current_colors={"text":"#B91C1C","background":"#FFF59D"}
        for label,widget in (("Cima u horizonte",top_combo),("Tamaño del texto",size_box),("Tipo",type_combo)):
            layout.addWidget(QLabel(label));layout.addWidget(widget)
        layout.addWidget(bold_check);layout.addWidget(highlight_check);layout.addWidget(text_button);layout.addWidget(background_button)
        layout.addSpacing(8);layout.addWidget(preview)
        apply_one=QPushButton("Aplicar a esta cima");apply_all=QPushButton("Aplicar estilo a todas las cimas");reset=QPushButton("Restaurar estilo predeterminado")
        layout.addWidget(apply_one);layout.addWidget(apply_all);layout.addWidget(reset)
        close_buttons=QDialogButtonBox(QDialogButtonBox.Close);close_buttons.rejected.connect(dialog.reject);layout.addWidget(close_buttons)
        def update_preview():
            weight="bold" if bold_check.isChecked() else "normal";style="italic" if bool(type_combo.currentData()) else "normal"
            background=current_colors["background"] if highlight_check.isChecked() else "white"
            preview.setStyleSheet(f"color:{current_colors['text']};background:{background};font-size:{size_box.value()}pt;font-weight:{weight};font-style:{style};padding:6px;")
            background_button.setEnabled(highlight_check.isChecked())
        def load_style():
            name=top_combo.currentText();style=self.project.effective_top_style(name)
            size_box.setValue(float(style.get("font_size",5.2)));type_combo.setCurrentIndex(1 if style.get("italic") else 0)
            bold_check.setChecked(bool(style.get("bold")));highlight_check.setChecked(bool(style.get("highlight")))
            current_colors["text"]=style.get("text_color") or self.project.top_colors.get(name,"#B91C1C")
            current_colors["background"]=style.get("background_color","#FFF59D");update_preview()
        def choose_color(key,title):
            color=QColorDialog.getColor(QColor(current_colors[key]),dialog,title)
            if color.isValid():current_colors[key]=color.name();update_preview()
        def selected_style():
            return {"font_size":size_box.value(),"italic":bool(type_combo.currentData()),"bold":bold_check.isChecked(),
                    "text_color":current_colors["text"],"highlight":highlight_check.isChecked(),"background_color":current_colors["background"]}
        def apply_style(all_tops=False):
            targets=names if all_tops else [top_combo.currentText()]
            for name in targets:self.project.set_top_style(name,selected_style())
            self.refresh_plot();self.statusBar().showMessage("Apariencia aplicada a todas las cimas." if all_tops else f"Apariencia aplicada a {targets[0]}.",5000)
        def reset_style():
            self.project.top_styles.pop(top_combo.currentText(),None);load_style();self.refresh_plot()
        top_combo.currentTextChanged.connect(load_style);size_box.valueChanged.connect(update_preview);type_combo.currentIndexChanged.connect(update_preview)
        bold_check.toggled.connect(update_preview);highlight_check.toggled.connect(update_preview)
        text_button.clicked.connect(lambda:choose_color("text","Color del texto"));background_button.clicked.connect(lambda:choose_color("background","Color del resaltado"))
        apply_one.clicked.connect(lambda:apply_style(False));apply_all.clicked.connect(lambda:apply_style(True));reset.clicked.connect(reset_style)
        load_style();dialog.exec()

    def _refresh_controls(self):
        previous_track=self.visible_track.currentData(); previous_curve=self.visible_curve.currentText()
        self.well_list.clear()
        for well in self.project.wells:
            label = well.name if not well.uwi or well.uwi == well.name else f"{well.name} · {well.uwi}"
            self.well_list.addItem(label)
        self.visible_track.blockSignals(True); self.visible_track.clear()
        for idx,track in enumerate(self.project.viewer_template.get("tracks",[]),1): self.visible_track.addItem(f"Track {idx}",str(track.get("key")))
        track_index=self.visible_track.findData(previous_track)
        if track_index>=0:self.visible_track.setCurrentIndex(track_index)
        self.visible_track.blockSignals(False)
        self.visible_curve.blockSignals(True); self.visible_curve.clear(); self.visible_curve.addItems(self.project.available_curves)
        if previous_curve in self.project.available_curves:self.visible_curve.setCurrentText(previous_curve)
        self.visible_curve.blockSignals(False)
        self.lithology_check.blockSignals(True); self.lithology_check.setChecked(self.project.show_lithology); self.lithology_check.blockSignals(False)
        self.lithology_action.setChecked(self.project.show_lithology)
        self.show_tops_action.setChecked(self.project.show_tops)
        if self.project.spacing_mode in self.spacing_actions:self.spacing_actions[self.project.spacing_mode].setChecked(True)
        if self.project.header_identifier_mode in self.header_mode_actions:self.header_mode_actions[self.project.header_identifier_mode].setChecked(True)
        self._update_visibility_buttons()

        self.datum_combo.blockSignals(True)
        self.datum_combo.clear()
        self.datum_combo.addItem("Profundidad MD", None)
        for top_name in self.project.common_top_names:
            self.datum_combo.addItem(f"Alinear por: {top_name}", top_name)
        saved_datum=self.project.datum_top
        saved_index=self.datum_combo.findData(saved_datum)
        self.datum_combo.setCurrentIndex(max(0,saved_index))
        self.datum_combo.blockSignals(False)
        self._rebuild_datum_menu()
        self.refresh_plot()
        mapped=[well for well in self.project.wells if self.project.well_visible_on_map(well.uwi)]
        for window in list(self._map_windows):
            try:window.update_wells(mapped,self.project.spatial_reference.get("horizontal_crs","EPSG:4326"))
            except RuntimeError:
                if window in self._map_windows:self._map_windows.remove(window)

    def _set_header_identifier_mode(self,mode):
        self.project.header_identifier_mode=str(mode);self.refresh_plot()
        labels={"NAME":"NAME","UWI":"UWI","API":"API","NAME_UWI":"NAME + UWI","NAME_API":"NAME + API","CUSTOM":"nombre personalizado"}
        self.statusBar().showMessage(f"Encabezados de pozo: {labels.get(mode,mode)}.",5000)

    def _edit_single_header_alias(self,well):
        current=self.project.well_header_aliases.get(str(well.uwi),well.name)
        value,accepted=QInputDialog.getText(self,"Nombre visible del pozo",f"Encabezado para {well.name} ({well.uwi}):",text=current)
        if not accepted:return
        self.project.set_well_header_alias(well.uwi,value);self.project.header_identifier_mode="CUSTOM";self._refresh_controls()

    def _edit_header_aliases(self):
        dialog=QDialog(self);dialog.setWindowTitle("Editar nombres visibles de los pozos");dialog.resize(760,430)
        layout=QVBoxLayout(dialog);layout.addWidget(QLabel("Los alias sólo afectan este proyecto. NAME, UWI y API originales permanecen intactos."))
        table=QTableWidget(len(self.project.wells),4);table.setHorizontalHeaderLabels(["UWI","NAME original","API","Nombre visible personalizado"])
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch);table.setSelectionBehavior(QAbstractItemView.SelectRows)
        for row,well in enumerate(self.project.wells):
            values=(well.uwi,well.name,self.project.well_api(well),self.project.well_header_aliases.get(str(well.uwi),""))
            for column,value in enumerate(values):
                item=QTableWidgetItem(str(value))
                if column<3:item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                table.setItem(row,column,item)
        layout.addWidget(table)
        buttons=QDialogButtonBox(QDialogButtonBox.Apply|QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Apply).setText("Aplicar");buttons.rejected.connect(dialog.reject)
        def apply_aliases():
            for row,well in enumerate(self.project.wells):self.project.set_well_header_alias(well.uwi,table.item(row,3).text())
            self.project.header_identifier_mode="CUSTOM";dialog.accept();self._refresh_controls()
        buttons.button(QDialogButtonBox.Apply).clicked.connect(apply_aliases);layout.addWidget(buttons);dialog.exec()

    def _restore_header_aliases(self):
        if not self.project.well_header_aliases:return
        if QMessageBox.question(self,"Restaurar encabezados","¿Eliminar todos los nombres personalizados del proyecto?")==QMessageBox.Yes:
            self.project.well_header_aliases.clear();self.project.header_identifier_mode="NAME_UWI";self._refresh_controls()

    def refresh_plot(self):
        datum = self.datum_combo.currentData()
        self.project.datum_top=datum
        if self.render_backend=="vispy":self._refresh_gpu_canvas()
        else:self.canvas.draw_project(self.project, "GR", datum)
        if not self._loading:
            self._dirty=True
        datum_label=datum or "Profundidad MD"
        spacing="proporcional" if self.project.spacing_mode=="proportional" else "uniforme"
        zoom_label="intervalo" if self.canvas.interaction_mode=="interval" else "areal"
        section_count=sum(self.project.well_visible_in_section(well.uwi) and well.has_log_data for well in self.project.wells)
        self.statusBar().showMessage(f"Datum: {datum_label}  |  {section_count}/{len(self.project.wells)} pozos visibles  |  Separación {spacing}  |  Zoom {zoom_label}")

    def _render_navigation_state(self):
        if self.render_backend=="vispy" and self.gpu_canvas:return self.gpu_canvas.capture_navigation_state()
        return self.canvas.capture_navigation_state()

    def _restore_render_navigation_state(self,state):
        if self.render_backend=="vispy" and self.gpu_canvas:self.gpu_canvas.restore_navigation_state(state)
        else:self.canvas.restore_navigation_state(state)

    def _manage_tracks(self,track_key=None,well_uwi=None):
        navigation=self._render_navigation_state();original_dirty=self._dirty
        def preview():
            self.refresh_plot();self._restore_render_navigation_state(navigation)
        dialog=TrackManagerDialog(self.project,preview,self,initial_track_key=track_key,initial_well_uwi=well_uwi)
        accepted=dialog.exec()==QDialog.Accepted
        if accepted:preview()
        self._dirty=original_dirty or accepted
        self.statusBar().showMessage("Configuración de tracks y retícula aplicada y guardada en el proyecto." if accepted else "Cambios de tracks y retícula cancelados.",5000)

    def _set_zoom_mode(self,mode):
        if self.render_backend=="vispy" and self.gpu_canvas:
            self.gpu_canvas._activate_zoom_mode(mode)
        else:self.canvas.set_interaction_mode(mode)
        self.zoom_actions[mode].setChecked(True)
        instruction="Presione en el inicio, mantenga pulsado y arrastre hasta el final del intervalo; después use rueda o botón intermedio para desplazarse." if mode=="interval" else "Use el cursor de seguimiento y arrastre el recuadro exacto que desea ampliar."
        self.statusBar().showMessage(instruction,8000)

    def _zoom_message(self,message):
        self.statusBar().showMessage(message)

    def _reset_zoom(self):
        if self.render_backend=="vispy" and self.gpu_canvas:self.gpu_canvas._reset_gpu_zoom()
        else:self.canvas.reset_zoom()
        self.statusBar().showMessage("Zoom restablecido al intervalo completo.",5000)

    def _toggle_data_cursor(self,enabled):
        self.canvas.set_data_cursor_enabled(bool(enabled));self.settings.setValue("navigation/data_cursor",bool(enabled))
        self.statusBar().showMessage("Cursor de datos activo: mueva el puntero sobre un track; Ctrl+clic para fijar." if enabled else "Cursor de datos desactivado.",6000)

    def open_template(self):
        path,_=QFileDialog.getOpenFileName(self,"Cargar plantilla HMDLog","","Plantilla HMDLog (*.hmdtpl)")
        if not path:return
        try:
            self.project.apply_template(load_template(path)); self.settings.setValue("templates/last_path",path); self._refresh_controls()
            self.statusBar().showMessage(f"Plantilla cargada: {Path(path).name}",5000)
        except Exception as exc: QMessageBox.critical(self,"Plantilla no válida",str(exc))

    def save_current_template(self):
        path,_=QFileDialog.getSaveFileName(self,"Guardar plantilla HMDLog","Correlacion_Actual.hmdtpl","Plantilla HMDLog (*.hmdtpl)")
        if not path:return
        if not path.lower().endswith(".hmdtpl"):path += ".hmdtpl"
        try:
            save_template(path,self.project.template_payload()); self.settings.setValue("templates/last_path",path)
            self.statusBar().showMessage(f"Plantilla guardada y establecida como predeterminada: {Path(path).name}",5000)
        except Exception as exc: QMessageBox.warning(self,"No fue posible guardar",str(exc))

    def _toggle_track(self):
        key=self.visible_track.currentData()
        if key:self.project.toggle_track(str(key));self._update_visibility_buttons();self._stage_curve_admin_changes()

    def _toggle_curve(self):
        key=self.visible_track.currentData();source=self.visible_curve.currentText()
        if not key or not source:return
        if self.project.track_has_curve(str(key),source):self.project.remove_curve_from_track(str(key),source)
        else:self.project.assign_curve_to_track(str(key),source)
        self._update_visibility_buttons();self._stage_curve_admin_changes()

    def _update_visibility_buttons(self):
        key=self.visible_track.currentData();source=self.visible_curve.currentText()
        self.toggle_track_button.setText("Apagar track" if not key or self.project.track_visible(str(key)) else "Encender track")
        assigned=bool(key and source and self.project.track_has_curve(str(key),source))
        self.toggle_curve_button.setText("Quitar del track" if assigned else "Agregar al track")
        self.mirror_curve_check.blockSignals(True)
        self.mirror_curve_check.setEnabled(assigned)
        self.mirror_curve_check.setChecked(assigned and self.project.curve_presentation(str(key),source)=="axis_inverted")
        self.mirror_curve_check.blockSignals(False)

    def _set_active_curve_mirror(self,mirrored):
        key=self.visible_track.currentData();source=self.visible_curve.currentText()
        if key and source and self.project.track_has_curve(str(key),source):
            self.project.set_curve_presentation(str(key),source,"axis_inverted" if mirrored else "normal");self._stage_curve_admin_changes()

    def _configure_track_discretization(self):
        tracks=self.project.viewer_template.get("tracks",[])
        if not tracks:QMessageBox.information(self,"Discretización litológica","No existen tracks configurados.");return
        dialog=QDialog(self);dialog.setWindowTitle("Discretización litológica por línea de referencia");dialog.resize(620,470);layout=QVBoxLayout(dialog)
        note=QLabel("La configuración pertenece al pozo y track seleccionados. Sólo se copiará a otros pozos cuando usted lo indique expresamente.");note.setWordWrap(True);layout.addWidget(note)
        general=QFormLayout();well=QComboBox();track=QComboBox();curve=QComboBox();scope=QComboBox();scope.addItem("Sólo este pozo","active");scope.addItem("Pozos seleccionados…","selected");scope.addItem("Todos los pozos visibles","all");enabled=QCheckBox("Activar discretización en este pozo y track");reference=QDoubleSpinBox();reference.setRange(-1e9,1e9);reference.setDecimals(5);reference.setSingleStep(1.0);alpha=QDoubleSpinBox();alpha.setRange(0.05,1.0);alpha.setSingleStep(.05);alpha.setDecimals(2)
        for item in self.project.wells:
            if item.has_log_data and self.project.well_visible_in_section(item.uwi):well.addItem(f"{item.name} · {item.uwi}",str(item.uwi))
        for index,item in enumerate(tracks,1):track.addItem(f"Track {index}",str(item.get("key")))
        general.addRow("Pozo activo",well);general.addRow("Track",track);general.addRow("Curva de control",curve);general.addRow("Valor de referencia",reference);general.addRow("Aplicar a",scope);general.addRow("Transparencia",alpha);general.addRow(enabled);layout.addLayout(general)
        colors={"left":"#F4D35E","right":"#9CA3AF","line":"#111827"};side_widgets={}
        lithologies=("Arena","Lutita","Caliza","Dolomía","Anhidrita","Sal","Otro")
        patterns=(("Sin patrón",""),("Puntos",".."),("Líneas horizontales","--"),("Cruz ortogonal","++"),("Cruz diagonal","xx"),("Diagonal","//"),("Círculos","oo"))
        sides=QHBoxLayout()
        for key,title in (("left","Área izquierda"),("right","Área derecha")):
            box=QGroupBox(title);form=QFormLayout(box);lith=QComboBox();lith.addItems(lithologies);pattern=QComboBox()
            for label,value in patterns:pattern.addItem(label,value)
            color=QPushButton("Seleccionar color…");color.clicked.connect(lambda checked=False,k=key:self._choose_discretization_color(dialog,colors,k))
            form.addRow("Litología",lith);form.addRow("Símbolo/patrón",pattern);form.addRow("Color",color);side_widgets[key]=(lith,pattern);sides.addWidget(box)
        layout.addLayout(sides)
        line_row=QHBoxLayout();line_color=QPushButton("Color de línea…");line_color.clicked.connect(lambda:self._choose_discretization_color(dialog,colors,"line"));line_style=QComboBox()
        for label,value in (("Discontinua","--"),("Continua","-"),("Punteada",":"),("Punto-raya","-.")):line_style.addItem(label,value)
        line_row.addWidget(QLabel("Línea de referencia"));line_row.addWidget(line_style);line_row.addWidget(line_color);line_row.addStretch();layout.addLayout(line_row)
        def assigned_sources(track_key):return [str(item.get("source","")).upper() for item in self.project.viewer_template.get("curves",[]) if str(item.get("track_key"))==str(track_key)]
        def set_combo_data(combo,value):
            index=combo.findData(value)
            if index<0:index=combo.findText(str(value))
            if index>=0:combo.setCurrentIndex(index)
        def load_track():
            key=str(track.currentData());uwi=str(well.currentData());sources=list(dict.fromkeys(assigned_sources(key)));curve.blockSignals(True);curve.clear();curve.addItems(sources);curve.blockSignals(False)
            source=sources[0] if sources else "GR";local=self.project.well_track_discretization(uwi,key);config=local or self.project.track_discretizations.get(key,self.project.default_track_discretization(source));enabled.setChecked(bool(local and config.get("enabled",True)));set_combo_data(curve,str(config.get("source",source)).upper());reference.setValue(float(config.get("reference",75)));alpha.setValue(float(config.get("alpha",.38)));colors.update(left=config.get("left",{}).get("color","#F4D35E"),right=config.get("right",{}).get("color","#9CA3AF"),line=config.get("line_color","#111827"));set_combo_data(line_style,config.get("line_style","--"))
            for side in ("left","right"):
                style=config.get(side,{});lith,pattern=side_widgets[side];lith.setCurrentText(style.get("lithology","Arena" if side=="left" else "Lutita"));set_combo_data(pattern,style.get("pattern",".." if side=="left" else "--"))
            enabled.setEnabled(bool(sources));reference.setEnabled(bool(sources))
        def apply_settings():
            navigation=self.canvas.capture_navigation_state()
            key=str(track.currentData());source=curve.currentText();active_uwi=str(well.currentData())
            if not source:QMessageBox.information(dialog,"Curva requerida","Asigne primero una curva al track.");return
            settings={"enabled":enabled.isChecked(),"source":source,"reference":reference.value(),"alpha":alpha.value(),"line_color":colors["line"],"line_width":1.0,"line_style":line_style.currentData()}
            for side in ("left","right"):
                lith,pattern=side_widgets[side];settings[side]={"lithology":lith.currentText(),"color":colors[side],"pattern":pattern.currentData()}
            self.project.set_track_discretization(key,settings)
            mode=scope.currentData();targets=[active_uwi]
            if mode=="all":targets=[str(item.uwi) for item in self.project.wells if item.has_log_data and self.project.well_visible_in_section(item.uwi)]
            elif mode=="selected":
                chosen=self._select_discretization_wells(active_uwi)
                if chosen is None:return
                targets=chosen
            for target in targets:self.project.set_well_track_discretization(target,key,settings)
            self.refresh_plot();self.canvas.restore_navigation_state(navigation);self._dirty=True
            self.statusBar().showMessage(f"Discretización aplicada a {len(targets)} pozo(s) en {track.currentText()} con {source} = {reference.value():g}. Se conservó el zoom actual.",5000)
        def remove_settings():
            navigation=self.canvas.capture_navigation_state()
            self.project.remove_well_track_discretization(str(well.currentData()),str(track.currentData()))
            self.refresh_plot();self.canvas.restore_navigation_state(navigation);self._dirty=True;load_track()
        buttons=QDialogButtonBox(QDialogButtonBox.Apply|QDialogButtonBox.Reset|QDialogButtonBox.Close);buttons.button(QDialogButtonBox.Apply).setText("Aplicar");buttons.button(QDialogButtonBox.Reset).setText("Quitar de este pozo");buttons.button(QDialogButtonBox.Close).setText("Cerrar");buttons.button(QDialogButtonBox.Apply).clicked.connect(apply_settings);buttons.button(QDialogButtonBox.Reset).clicked.connect(remove_settings);buttons.rejected.connect(dialog.reject);layout.addWidget(buttons)
        track.currentIndexChanged.connect(load_track);well.currentIndexChanged.connect(load_track);load_track();dialog.exec()

    def _select_discretization_wells(self,active_uwi):
        dialog=QDialog(self);dialog.setWindowTitle("Seleccionar pozos para copiar la discretización");dialog.resize(470,420);layout=QVBoxLayout(dialog);table=QTableWidget(0,2);table.setHorizontalHeaderLabels(["Aplicar","Pozo"]);table.horizontalHeader().setStretchLastSection(True)
        wells=[item for item in self.project.wells if item.has_log_data and self.project.well_visible_in_section(item.uwi)];table.setRowCount(len(wells))
        for row,item in enumerate(wells):
            check=QTableWidgetItem();check.setFlags(Qt.ItemIsEnabled|Qt.ItemIsUserCheckable);check.setCheckState(Qt.Checked if str(item.uwi)==str(active_uwi) else Qt.Unchecked);check.setData(Qt.UserRole,str(item.uwi));table.setItem(row,0,check);name=QTableWidgetItem(f"{item.name} · {item.uwi}");name.setFlags(name.flags()&~Qt.ItemIsEditable);table.setItem(row,1,name)
        layout.addWidget(table);buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject);layout.addWidget(buttons)
        if dialog.exec()!=QDialog.Accepted:return None
        selected=[str(table.item(row,0).data(Qt.UserRole)) for row in range(table.rowCount()) if table.item(row,0).checkState()==Qt.Checked]
        if not selected:QMessageBox.information(self,"Sin selección","Seleccione al menos un pozo.");return None
        return selected

    @staticmethod
    def _choose_discretization_color(parent,colors,key):
        chosen=QColorDialog.getColor(QColor(colors[key]),parent,"Seleccionar color")
        if chosen.isValid():colors[key]=chosen.name()

    def _duplicate_curve_as_mirror(self):
        sources=self.project.template_curves
        tracks=self.project.viewer_template.get("tracks",[])
        if not sources or not tracks:
            QMessageBox.information(self,"Imagen especular","Se requiere al menos una curva asignada y un track.");return
        source,ok=QInputDialog.getItem(self,"Duplicar como imagen especular","Curva de origen:",sources,0,False)
        if not ok:return
        labels=[f"Track {index+1}" for index in range(len(tracks))]
        label,ok=QInputDialog.getItem(self,"Duplicar como imagen especular","Track de destino:",labels,0,False)
        if not ok:return
        target=str(tracks[labels.index(label)].get("key"))
        self.project.duplicate_curve_as_mirror(source,target);self._refresh_controls()
        self.visible_track.setCurrentIndex(self.visible_track.findData(target));self.visible_curve.setCurrentText(source);self._update_visibility_buttons()
        self.statusBar().showMessage(f"{source} agregada como imagen especular en {label}.",5000)

    def _toggle_lithology(self,checked):
        self.project.show_lithology=bool(checked)
        self.lithology_action.blockSignals(True); self.lithology_action.setChecked(bool(checked)); self.lithology_action.blockSignals(False)
        self._stage_curve_admin_changes()

    def _menu_toggle_lithology(self,checked):
        self.lithology_check.blockSignals(True); self.lithology_check.setChecked(bool(checked)); self.lithology_check.blockSignals(False)
        self.project.show_lithology=bool(checked); self.refresh_plot()

    def _show_context(self,index):
        self.context_tabs.setCurrentIndex(index); self.context_dock.show(); self.context_dock.raise_()

    def _sync_context_actions(self,visible):
        if not visible:
            if hasattr(self,"apply_track_curve_changes") and self.apply_track_curve_changes.isEnabled():self._commit_curve_admin_changes()
            return
        self.context_tabs.setFocus()

    def _stage_curve_admin_changes(self):
        if not hasattr(self,"_curve_admin_navigation") or self._curve_admin_navigation is None:self._curve_admin_navigation=self._render_navigation_state()
        self.apply_track_curve_changes.setEnabled(True);self._dirty=True
        self.statusBar().showMessage("Cambios de tracks y curvas pendientes. Pulse Aplicar cambios.",5000)

    def _commit_curve_admin_changes(self):
        if not hasattr(self,"apply_track_curve_changes") or not self.apply_track_curve_changes.isEnabled():return
        navigation=getattr(self,"_curve_admin_navigation",None);self.refresh_plot();self._restore_render_navigation_state(navigation)
        self._curve_admin_navigation=None;self.apply_track_curve_changes.setEnabled(False)
        self.statusBar().showMessage("Cambios de tracks y curvas aplicados en una sola actualización.",5000)

    def _set_spacing(self,mode):
        self.project.spacing_mode=mode; self.refresh_plot()

    def _move_well(self,direction):
        row=self.well_list.currentRow()
        if row<0:
            self.well_dock.show(); QMessageBox.information(self,"Seleccionar pozo","Seleccione primero un pozo de la lista."); return
        target=row+direction
        if target<0 or target>=len(self.project.wells):return
        self.project.wells[row],self.project.wells[target]=self.project.wells[target],self.project.wells[row]
        self._refresh_controls(); self.well_list.setCurrentRow(target)

    def _resolve_coordinate_data(self,well):
        record=self.geodata.well_record(str(well.uwi));stored=record.get("coordinate_data") if record else None;incoming=dict(well.coordinate_data or {})
        if record:well.well_metadata=dict(record.get("metadata",{}))
        if stored and is_valid_geographic(stored) and is_valid_geographic(incoming):
            difference=max(abs(float(stored["latitude"])-float(incoming["latitude"])),abs(float(stored["longitude"])-float(incoming["longitude"])))
            if difference>1e-8:
                answer=QMessageBox.question(self,"Coordenadas diferentes",
                    f'{well.name} · {well.uwi}\n\nBase de datos: LAT {stored["latitude"]:.6f}, LON {stored["longitude"]:.6f}\nArchivo LAS: LAT {incoming["latitude"]:.6f}, LON {incoming["longitude"]:.6f}\n\n¿Usar las coordenadas del archivo LAS?\nSeleccione No para conservar las almacenadas.',
                    QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
                if answer==QMessageBox.No:well.coordinate_data=dict(stored);well.x=stored["longitude"];well.y=stored["latitude"]
        elif stored and is_valid_geographic(stored) and not is_valid_geographic(incoming):
            well.coordinate_data=dict(stored);well.x=stored["longitude"];well.y=stored["latitude"]

    def _open_project_administrator(self):
        dialog=ProjectAdministratorDialog(self.project,self.geodata,self.repository,self._refresh_controls,self,
            map_callback=self._show_well_map);dialog.exec()
        self._dirty=True

    def _show_well_map(self):
        if not self.project.wells:QMessageBox.information(self,"Mapa de pozos","Primero cargue al menos un pozo LAS.");return
        mapped=[well for well in self.project.wells if self.project.well_visible_on_map(well.uwi)]
        window=WellMapDialog(mapped,self,self.project.spatial_reference.get("horizontal_crs","EPSG:4326"),
            project=self.project,changed_callback=self._map_project_changed);self._map_windows.append(window)
        window.destroyed.connect(lambda *_args,w=window:self._map_windows.remove(w) if w in self._map_windows else None)
        window.show();window.raise_();window.activateWindow()

    def _map_project_changed(self):
        self._dirty=True;self._refresh_controls();self.statusBar().showMessage("Línea de sección actualizada en el proyecto.",4000)

    def _manage_coordinates(self):
        if not self.project.wells:QMessageBox.information(self,"Coordenadas","Primero cargue al menos un pozo LAS.");return
        dialog=QDialog(self);dialog.setWindowTitle("Administrar coordenadas de pozos");dialog.resize(1050,500);layout=QVBoxLayout(dialog)
        layout.addWidget(QLabel("LAT/LON se representan en WGS 84 (EPSG:4326). Los valores originales del LAS permanecen conservados."))
        table=QTableWidget(len(self.project.wells),9);table.setHorizontalHeaderLabels(
            ["Pozo","UWI","X/LON original","Y/LAT original","Latitud","Longitud","CRS","Estado","Fuente"])
        for row,well in enumerate(self.project.wells):
            data=dict(well.coordinate_data or {});values=(well.name,well.uwi,data.get("source_x"),data.get("source_y"),data.get("latitude"),data.get("longitude"),
                data.get("crs") or "EPSG:4326",data.get("validation_status","missing"),data.get("source_file") or "")
            for column,value in enumerate(values):
                item=QTableWidgetItem("" if value is None else str(value));table.setItem(row,column,item)
                if column not in {4,5,6}:item.setFlags(item.flags()&~Qt.ItemIsEditable)
            table.item(row,0).setData(Qt.UserRole,str(well.uwi))
        table.setSelectionBehavior(QAbstractItemView.SelectRows);table.setSelectionMode(QAbstractItemView.SingleSelection)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents);layout.addWidget(table)
        restore=QPushButton("Restaurar coordenadas originales del LAS para la fila seleccionada");layout.addWidget(restore)
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.button(QDialogButtonBox.Save).setText("Guardar coordenadas")
        buttons.rejected.connect(dialog.reject);layout.addWidget(buttons)
        def save_coordinates():
            prepared=[]
            for row,well in enumerate(self.project.wells):
                lat_text=table.item(row,4).text().strip();lon_text=table.item(row,5).text().strip();crs=table.item(row,6).text().strip() or "EPSG:4326"
                if not lat_text and not lon_text:continue
                if not lat_text or not lon_text:QMessageBox.warning(dialog,"Coordenadas incompletas",f"Complete latitud y longitud para {well.name}.");return
                try:data=validate_manual_geographic(lat_text,lon_text,crs,"edición manual")
                except ValueError as exc:QMessageBox.warning(dialog,"Coordenadas no válidas",f"{well.name}: {exc}");return
                if data.get("validation_status")=="invalid":QMessageBox.warning(dialog,"Coordenadas no válidas",f'{well.name}: {data.get("validation_message")}');return
                original=dict(well.coordinate_data or {})
                for key in ("source_x","source_y","source_fields","source_file","format"):
                    if original.get(key) is not None:data[key]=original[key]
                data["normalization_source"]="manual";prepared.append((well,data))
            for well,data in prepared:
                well.coordinate_data=data
                if is_valid_geographic(data):well.x=data["longitude"];well.y=data["latitude"]
            self._sync_geodata("coordinate_edit");self.refresh_plot();self.statusBar().showMessage(f"Coordenadas actualizadas para {len(prepared)} pozo(s).",6000);dialog.accept()
        def restore_original():
            row=table.currentRow()
            if row<0:QMessageBox.information(dialog,"Seleccionar pozo","Seleccione una fila.");return
            well=self.project.wells[row];old=dict(well.coordinate_data or {});fields=list(old.get("source_fields",[]))
            longitude_field=next((field for field in fields if str(field).upper() in {"LON","LONG","LOG","LONGITUDE","X_LONG","X_LONGITUDE"}),None)
            latitude_field=next((field for field in fields if str(field).upper() in {"LATI","LAT","LATITUDE","Y_LAT","Y_LATITUDE"}),None)
            if not longitude_field or not latitude_field:
                QMessageBox.information(dialog,"Original no geográfico","El LAS no contiene un par LAT/LON original que pueda restaurarse automáticamente.");return
            restored=coordinate_data_from_values(old.get("source_y"),old.get("source_x"),latitude_field=latitude_field,longitude_field=longitude_field,source_file=old.get("source_file"))
            if not is_valid_geographic(restored):QMessageBox.warning(dialog,"Original no válido",restored.get("validation_message","No fue posible restaurar."));return
            well.coordinate_data=restored;well.x=restored["longitude"];well.y=restored["latitude"]
            self._sync_geodata("coordinate_restore_las");self.refresh_plot();dialog.accept()
        buttons.accepted.connect(save_coordinates);restore.clicked.connect(restore_original);dialog.exec()

    def _show_distances(self):
        if len(self.project.wells)<2:
            QMessageBox.information(self,"Distancias","Se requieren al menos dos pozos."); return
        lines=[]
        reference=self.project.spatial_reference;projected=reference.get("horizontal_type")=="projected";target=reference.get("horizontal_crs","EPSG:4326")
        for left,right in zip(self.project.wells,self.project.wells[1:]):
            left_point=coordinates_in_project(left.coordinate_data,target);right_point=coordinates_in_project(right.coordinate_data,target)
            if projected and left_point and right_point:
                distance=float(np.hypot(right_point[0]-left_point[0],right_point[1]-left_point[1]));units=str(reference.get("coordinate_units","metres"))
                value=f"{distance:,.1f} {units}"
            elif is_valid_geographic(left.coordinate_data) and is_valid_geographic(right.coordinate_data):
                distance=haversine_meters(left.coordinate_data,right.coordinate_data);value=f"{distance/1000:.2f} km" if distance>=1000 else f"{distance:.0f} m"
            elif left.coordinate_data or right.coordinate_data:value="CRS no compatible o coordenadas no válidas"
            elif None in (left.x,left.y,right.x,right.y):value="Sin coordenadas"
            else:
                distance=float(np.hypot(right.x-left.x,right.y-left.y))
                value=f"{distance/1000:.2f} km" if distance>=1000 else f"{distance:.0f} m"
            lines.append(f"{left.name} → {right.name}: {value}")
        QMessageBox.information(self,"Distancias entre pozos","\n".join(lines))

    def _rebuild_datum_menu(self):
        self.datum_menu.clear(); group=QActionGroup(self); group.setExclusive(True)
        entries=[("Profundidad MD",None)]+[(name,name) for name in self.project.common_top_names]
        current=self.datum_combo.currentData()
        for label,value in entries:
            action=QAction(label,self); action.setCheckable(True); action.setChecked(value==current)
            action.triggered.connect(lambda checked,v=value:self._select_datum(v)); group.addAction(action); self.datum_menu.addAction(action)

    def _select_datum(self,value):
        idx=self.datum_combo.findData(value)
        if idx>=0:self.datum_combo.setCurrentIndex(idx)
        self._rebuild_datum_menu()

    def _toggle_tops(self,checked):
        self.project.show_tops=bool(checked); self.refresh_plot()

    def _choose_line_width(self):
        value,ok=QInputDialog.getDouble(self,"Grosor de líneas","Grosor:",self.project.correlation_linewidth,.3,5.0,1)
        if ok:self.project.correlation_linewidth=float(value);self.refresh_plot()

    def _choose_top_color(self):
        names=self.project.top_names
        if not names:QMessageBox.information(self,"Horizontes","No hay topes cargados.");return
        name,ok=QInputDialog.getItem(self,"Color de horizonte","Horizonte:",names,0,False)
        if not ok:return
        color=QColorDialog.getColor(QColor(self.project.top_colors.get(name,"#B91C1C")),self,"Seleccionar color")
        if color.isValid():self.project.top_colors[name]=color.name();self.refresh_plot()

    def _restore_template(self):
        from copy import deepcopy
        from .viewer_template import DEFAULT_TEMPLATE
        self.settings.remove("templates/last_path")
        self.project.apply_template(deepcopy(DEFAULT_TEMPLATE)); self._refresh_controls()

    def _load_preferred_template(self):
        saved=str(self.settings.value("templates/last_path","") or "")
        candidates=[]
        if saved:candidates.append(Path(saved))
        candidates.append(Path(__file__).resolve().parents[1]/"sample_data"/"Correlacion_Estandar.hmdtpl")
        for candidate in candidates:
            if candidate.exists():
                try:self.project.apply_template(load_template(candidate));return
                except Exception:continue

    def _apply_theme(self,name):
        styles={
            "Claro técnico":"QMainWindow{background:#f5f7f9} QMenuBar{background:#f5f7f9} QMenuBar::item:selected{background:#dbeafe} QDockWidget{font-weight:600}",
            "Gris profesional":"QWidget{background:#e5e7eb;color:#1f2937} QLineEdit,QComboBox,QListWidget{background:#f9fafb} QMenu::item:selected,QMenuBar::item:selected{background:#cbd5e1}",
            "Oscuro":"QWidget{background:#20242b;color:#e5e7eb} QLineEdit,QComboBox,QListWidget{background:#303640;color:#f9fafb} QPushButton{background:#374151;border:1px solid #64748b;padding:4px} QMenu::item:selected,QMenuBar::item:selected{background:#1d4ed8}",
            "Alto contraste":"QWidget{background:#ffffff;color:#000000} QLineEdit,QComboBox,QListWidget{background:#ffffff;color:#000000;border:1px solid #000} QPushButton{background:#fff;border:2px solid #000;padding:4px}"
        }
        self.setStyleSheet(styles.get(name,styles["Claro técnico"])); self.settings.setValue("appearance/theme",name)
        if hasattr(self,"theme_actions") and name in self.theme_actions:self.theme_actions[name].setChecked(True)

    def _choose_background(self,key,title):
        viewer=self.project.viewer_template.setdefault("viewer",{})
        defaults={"workspace_background":"#ffffff","track_background":"#ffffff","grid_color":"#b8bec6"}
        color=QColorDialog.getColor(QColor(viewer.get(key,defaults[key])),self,f"Fondo: {title}")
        if color.isValid():viewer[key]=color.name();self.refresh_plot()

    def _restore_appearance(self):
        viewer=self.project.viewer_template.setdefault("viewer",{})
        viewer.update(workspace_background="#ffffff",track_background="#ffffff",grid_color="#b8bec6")
        self._apply_theme("Claro técnico");self.refresh_plot()

    def _show_manual(self):
        QMessageBox.information(self,"Manual del usuario","Use el menú principal para cargar datos y los paneles contextuales para editar tracks, curvas y escalas.\n\nCursor de datos: mueva el puntero sobre un track; Ctrl+clic fija o libera la lectura.")

    def _show_gpu_status(self):
        status=probe_vispy()
        QMessageBox.information(
            self,"Compatibilidad del motor gráfico",
            f"{status.label}\n\n{status.detail}\n\n"
            "Durante esta fase Matplotlib continúa siendo el visor estable. "
            "La vista GPU se abre en paralelo y no modifica el proyecto."
        )

    def _gpu_project_changed(self):
        self._dirty=True;self._sync_geodata("gpu_interpretation")
        self.statusBar().showMessage("Interpretación GPU incorporada al proyecto.",5000)

    def _refresh_gpu_canvas(self):
        if self.render_backend!="vispy":return
        status=probe_vispy()
        if not status.available:
            self.settings.setValue("rendering/backend_origin","fallback")
            self._apply_render_backend("matplotlib",persist=False);return
        try:
            from .rendering.vispy_canvas import VisPyCorrelationDialog
            if self.gpu_canvas is not None:
                try:mode=self.gpu_canvas.refresh_project(self.project,self.datum_combo.currentData())
                except (AttributeError,IndexError,KeyError,TypeError,ValueError,RuntimeError):
                    self.gpu_canvas._rebuild_scene(self.project,self.datum_combo.currentData());mode="scene"
                self.render_stack.setCurrentWidget(self.gpu_host)
                detail="actualización incremental" if mode=="incremental" else "reconstrucción de escena"
                self.settings.setValue("rendering/backend","vispy");self.settings.setValue("rendering/backend_origin","recovered")
                self.statusBar().showMessage(f"VisPy: {detail} · {self.gpu_canvas.last_refresh_ms:.1f} ms",2500)
                return
            self.gpu_canvas=VisPyCorrelationDialog(self.project,self.datum_combo.currentData(),self.gpu_host,
                embedded=True,change_callback=self._gpu_project_changed,configuration_callback=self._manage_tracks)
            self.gpu_host_layout.addWidget(self.gpu_canvas)
            self.render_stack.setCurrentWidget(self.gpu_host)
            self.settings.setValue("rendering/backend","vispy");self.settings.setValue("rendering/backend_origin","recovered")
        except Exception as exc:
            self.render_backend="matplotlib";self.settings.setValue("rendering/backend_origin","fallback")
            self.canvas.draw_project(self.project,"GR",self.datum_combo.currentData());self.render_stack.setCurrentWidget(self.canvas)
            if hasattr(self,"backend_actions"):self.backend_actions["matplotlib"].setChecked(True)
            QMessageBox.warning(self,"Motor GPU no disponible",f"Se activó Matplotlib como compatibilidad.\n\n{exc}")

    def _apply_render_backend(self,backend,initial=False,persist=True):
        requested=str(backend)
        if requested not in {"vispy","matplotlib"}:requested="vispy"
        if persist:
            self.settings.setValue("rendering/backend",requested)
            self.settings.setValue("rendering/backend_origin","user")
        backend="matplotlib" if requested=="vispy" and not probe_vispy().available else requested

        self.render_backend=backend
        if hasattr(self,"backend_actions"):self.backend_actions[backend].setChecked(True)
        if backend=="vispy":self._refresh_gpu_canvas()
        else:
            self.canvas.draw_project(self.project,"GR",self.datum_combo.currentData());self.render_stack.setCurrentWidget(self.canvas)
        if not initial:self.statusBar().showMessage("Motor VisPy/OpenGL activado." if backend=="vispy" else "Motor Matplotlib de compatibilidad activado.",5000)

    def _open_vispy_preview(self):
        status=probe_vispy()
        if not status.available:
            QMessageBox.warning(self,"Motor GPU no disponible",status.detail)
            return
        try:
            from .rendering.vispy_canvas import VisPyCorrelationDialog
            dialog=VisPyCorrelationDialog(self.project,self.datum_combo.currentData(),self,configuration_callback=self._manage_tracks)
            dialog.exec()
            if dialog.project_changed:
                self._sync_geodata("gpu_interpretation");self._dirty=True;self._refresh_controls()
                self.statusBar().showMessage("Cambios interpretativos GPU incorporados al proyecto.",6000)
        except Exception as exc:
            QMessageBox.critical(self,"No se pudo iniciar la vista GPU",str(exc))

    def _show_about(self):
        QMessageBox.about(self,"Acerca de HMDLog Correlation","HMDLog Correlation v0.12.27\nCorrelación estratigráfica multipozo\nCompositor horizontal sin restricciones incompatibles · VisPy y Matplotlib")

    def _spacing_changed(self):
        self.refresh_plot()

    def _toggle_well_panel(self, hidden):
        self.well_dock.setVisible(not hidden)

    def export_figure(self):
        path, selected = QFileDialog.getSaveFileName(
            self, "Exportar panel", "correlacion_pozos.svg", "SVG (*.svg);;PDF (*.pdf);;PNG (*.png)"
        )
        if not path:
            return
        if not Path(path).suffix:
            suffix = ".svg" if "SVG" in selected else ".pdf" if "PDF" in selected else ".png"
            path += suffix
        self.canvas.export(path)
        self.statusBar().showMessage(f"Panel exportado: {path}", 6000)
