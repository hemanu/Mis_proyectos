"""Repositorio SQLite extensible para información geocientífica por UWI."""
from __future__ import annotations

import csv
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class GeoDataRepository:
    """Persistencia local normalizada; las cimas son el primer dominio operativo."""

    def __init__(self, path: str | Path):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        self._initialize()

    def connect(self):
        connection=sqlite3.connect(self.path)
        connection.row_factory=sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    def _initialize(self):
        with self.connect() as db:
            db.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS schema_info(version INTEGER NOT NULL);
            INSERT INTO schema_info(version) SELECT 1 WHERE NOT EXISTS(SELECT 1 FROM schema_info);
            CREATE TABLE IF NOT EXISTS projects(
                project_id TEXT PRIMARY KEY, name TEXT NOT NULL, file_path TEXT,
                created_utc TEXT NOT NULL, updated_utc TEXT NOT NULL,
                metadata_json TEXT NOT NULL DEFAULT '{}',spatial_reference_json TEXT NOT NULL DEFAULT '{}');
            CREATE TABLE IF NOT EXISTS wells(
                uwi TEXT PRIMARY KEY, name TEXT NOT NULL, x REAL, y REAL,
                reference_elevation REAL, metadata_json TEXT NOT NULL DEFAULT '{}', updated_utc TEXT NOT NULL,
                source_x TEXT,source_y TEXT,longitude REAL,latitude REAL,crs TEXT,coordinate_source TEXT,
                coordinate_fields_json TEXT NOT NULL DEFAULT '[]',coordinate_format TEXT,
                coordinate_status TEXT NOT NULL DEFAULT 'missing',coordinate_message TEXT);
            CREATE TABLE IF NOT EXISTS project_wells(
                project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
                uwi TEXT NOT NULL REFERENCES wells(uwi) ON DELETE CASCADE, display_order INTEGER NOT NULL,
                show_in_section INTEGER NOT NULL DEFAULT 1,show_on_map INTEGER NOT NULL DEFAULT 1,
                PRIMARY KEY(project_id,uwi));
            CREATE TABLE IF NOT EXISTS tops(
                project_id TEXT NOT NULL, uwi TEXT NOT NULL, top_name TEXT NOT NULL,
                depth REAL NOT NULL, depth_unit TEXT, color TEXT, source TEXT, method TEXT,
                metadata_json TEXT NOT NULL DEFAULT '{}', updated_utc TEXT NOT NULL,
                PRIMARY KEY(project_id,uwi,top_name),
                FOREIGN KEY(project_id,uwi) REFERENCES project_wells(project_id,uwi) ON DELETE CASCADE);
            CREATE TABLE IF NOT EXISTS top_history(
                id INTEGER PRIMARY KEY AUTOINCREMENT, project_id TEXT NOT NULL, uwi TEXT NOT NULL,
                top_name TEXT NOT NULL, previous_depth REAL, new_depth REAL, action TEXT NOT NULL,
                method TEXT, metadata_json TEXT NOT NULL DEFAULT '{}', changed_utc TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS idx_top_history_lookup ON top_history(project_id,uwi,top_name,changed_utc);

            -- Entidades previstas para la expansión del repositorio geocientífico.
            CREATE TABLE IF NOT EXISTS survey_stations(
                id INTEGER PRIMARY KEY AUTOINCREMENT, uwi TEXT NOT NULL REFERENCES wells(uwi),
                md REAL NOT NULL, tvd REAL, inclination REAL, azimuth REAL, northing REAL, easting REAL,
                metadata_json TEXT NOT NULL DEFAULT '{}', UNIQUE(uwi,md));
            CREATE TABLE IF NOT EXISTS well_assets(
                asset_id TEXT PRIMARY KEY, uwi TEXT NOT NULL REFERENCES wells(uwi), asset_type TEXT NOT NULL,
                name TEXT NOT NULL, uri TEXT, mime_type TEXT, metadata_json TEXT NOT NULL DEFAULT '{}',
                created_utc TEXT NOT NULL, updated_utc TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS well_intervals(
                interval_id TEXT PRIMARY KEY, uwi TEXT NOT NULL REFERENCES wells(uwi), category TEXT NOT NULL,
                top_md REAL NOT NULL, base_md REAL NOT NULL, depth_unit TEXT, values_json TEXT NOT NULL DEFAULT '{}',
                source TEXT, created_utc TEXT NOT NULL, updated_utc TEXT NOT NULL);
            """)
            columns={row[1] for row in db.execute("PRAGMA table_info(tops)")}
            if "style_json" not in columns:db.execute("ALTER TABLE tops ADD COLUMN style_json TEXT NOT NULL DEFAULT '{}'")
            well_columns={row[1] for row in db.execute("PRAGMA table_info(wells)")}
            additions={"source_x":"TEXT","source_y":"TEXT","longitude":"REAL","latitude":"REAL","crs":"TEXT",
                "coordinate_source":"TEXT","coordinate_fields_json":"TEXT NOT NULL DEFAULT '[]'","coordinate_format":"TEXT",
                "coordinate_status":"TEXT NOT NULL DEFAULT 'missing'","coordinate_message":"TEXT"}
            for name,definition in additions.items():
                if name not in well_columns:db.execute(f"ALTER TABLE wells ADD COLUMN {name} {definition}")
            project_well_columns={row[1] for row in db.execute("PRAGMA table_info(project_wells)")}
            if "show_in_section" not in project_well_columns:db.execute("ALTER TABLE project_wells ADD COLUMN show_in_section INTEGER NOT NULL DEFAULT 1")
            if "show_on_map" not in project_well_columns:db.execute("ALTER TABLE project_wells ADD COLUMN show_on_map INTEGER NOT NULL DEFAULT 1")
            project_columns={row[1] for row in db.execute("PRAGMA table_info(projects)")}
            if "metadata_json" not in project_columns:db.execute("ALTER TABLE projects ADD COLUMN metadata_json TEXT NOT NULL DEFAULT '{}'")
            if "spatial_reference_json" not in project_columns:db.execute("ALTER TABLE projects ADD COLUMN spatial_reference_json TEXT NOT NULL DEFAULT '{}'")
            db.execute("UPDATE schema_info SET version=5")

    @staticmethod
    def _top_fields(well, name, project):
        metadata=dict(well.top_metadata.get(name,{}) or {})
        method=str(metadata.get("method") or metadata.get("last_adjustment",{}).get("method") or "project_snapshot")
        source=str(metadata.get("source") or method)
        return metadata,method,source,project.top_colors.get(name)

    def sync_project(self, project, file_path: str | None = None, reason: str = "project_save") -> dict:
        """Sincroniza atómicamente pozos/cimas y registra únicamente cambios reales."""
        now=_utc_now();added=changed=deleted=0
        with self.connect() as db:
            existing=db.execute("SELECT created_utc FROM projects WHERE project_id=?",(project.project_id,)).fetchone()
            created=existing[0] if existing else now
            db.execute("""INSERT INTO projects(project_id,name,file_path,created_utc,updated_utc,metadata_json,spatial_reference_json) VALUES(?,?,?,?,?,?,?)
                ON CONFLICT(project_id) DO UPDATE SET name=excluded.name,file_path=COALESCE(excluded.file_path,projects.file_path),updated_utc=excluded.updated_utc,
                metadata_json=excluded.metadata_json,spatial_reference_json=excluded.spatial_reference_json""",
                (project.project_id,project.name,file_path,created,now,json.dumps(project.project_metadata,ensure_ascii=False),json.dumps(project.spatial_reference,ensure_ascii=False)))
            expected=set()
            for order,well in enumerate(project.wells):
                uwi=str(well.uwi)
                coordinate=dict(getattr(well,"coordinate_data",{}) or {})
                stored_record=self.well_record(uwi);stored=stored_record.get("coordinate_data") if stored_record else None
                if coordinate.get("validation_status") in {None,"missing"} and stored and stored.get("validation_status")=="valid":
                    coordinate=stored;well.coordinate_data=dict(stored);well.x=stored.get("longitude");well.y=stored.get("latitude")
                metadata=dict(getattr(well,"well_metadata",{}) or {})
                if not metadata and stored_record:metadata=dict(stored_record.get("metadata",{}));well.well_metadata=dict(metadata)
                db.execute("""INSERT INTO wells(uwi,name,x,y,reference_elevation,metadata_json,updated_utc,source_x,source_y,longitude,latitude,crs,
                    coordinate_source,coordinate_fields_json,coordinate_format,coordinate_status,coordinate_message) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(uwi) DO UPDATE SET name=excluded.name,x=excluded.x,y=excluded.y,
                    reference_elevation=excluded.reference_elevation,metadata_json=excluded.metadata_json,updated_utc=excluded.updated_utc,
                    source_x=excluded.source_x,source_y=excluded.source_y,longitude=excluded.longitude,latitude=excluded.latitude,crs=excluded.crs,
                    coordinate_source=excluded.coordinate_source,coordinate_fields_json=excluded.coordinate_fields_json,
                    coordinate_format=excluded.coordinate_format,coordinate_status=excluded.coordinate_status,coordinate_message=excluded.coordinate_message""",
                    (uwi,well.name,well.x,well.y,well.reference_elevation,json.dumps(metadata,ensure_ascii=False),now,
                     None if coordinate.get("source_x") is None else str(coordinate.get("source_x")),
                     None if coordinate.get("source_y") is None else str(coordinate.get("source_y")),coordinate.get("longitude"),coordinate.get("latitude"),
                     coordinate.get("crs"),coordinate.get("source_file"),json.dumps(coordinate.get("source_fields",[]),ensure_ascii=False),
                     coordinate.get("format"),coordinate.get("validation_status","missing"),coordinate.get("validation_message")))
                db.execute("""INSERT INTO project_wells(project_id,uwi,display_order,show_in_section,show_on_map) VALUES(?,?,?,?,?)
                    ON CONFLICT(project_id,uwi) DO UPDATE SET display_order=excluded.display_order,
                    show_in_section=excluded.show_in_section,show_on_map=excluded.show_on_map""",
                    (project.project_id,uwi,order,int(project.well_visible_in_section(uwi)),int(project.well_visible_on_map(uwi))))
                for name,depth in well.tops.items():
                    name=str(name);depth=float(depth);expected.add((uwi,name))
                    previous=db.execute("SELECT depth FROM tops WHERE project_id=? AND uwi=? AND top_name=?",
                        (project.project_id,uwi,name)).fetchone()
                    metadata,method,source,color=self._top_fields(well,name,project)
                    style=json.dumps(project.effective_top_style(name),ensure_ascii=False)
                    db.execute("""INSERT INTO tops(project_id,uwi,top_name,depth,depth_unit,color,source,method,metadata_json,updated_utc,style_json)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(project_id,uwi,top_name) DO UPDATE SET
                        depth=excluded.depth,depth_unit=excluded.depth_unit,color=excluded.color,source=excluded.source,
                        method=excluded.method,metadata_json=excluded.metadata_json,updated_utc=excluded.updated_utc,style_json=excluded.style_json""",
                        (project.project_id,uwi,name,depth,well.depth_unit,color,source,method,json.dumps(metadata,ensure_ascii=False),now,style))
                    if previous is None:action="created";added+=1
                    elif abs(float(previous[0])-depth)>1e-9:action="updated";changed+=1
                    else:action=None
                    if action:
                        db.execute("""INSERT INTO top_history(project_id,uwi,top_name,previous_depth,new_depth,action,method,metadata_json,changed_utc)
                            VALUES(?,?,?,?,?,?,?,?,?)""",(project.project_id,uwi,name,None if previous is None else float(previous[0]),depth,
                            action,method,json.dumps({"reason":reason},ensure_ascii=False),now))
            rows=db.execute("SELECT uwi,top_name,depth,method FROM tops WHERE project_id=?",(project.project_id,)).fetchall()
            for row in rows:
                key=(str(row["uwi"]),str(row["top_name"]))
                if key not in expected:
                    db.execute("DELETE FROM tops WHERE project_id=? AND uwi=? AND top_name=?",(project.project_id,*key))
                    db.execute("""INSERT INTO top_history(project_id,uwi,top_name,previous_depth,new_depth,action,method,metadata_json,changed_utc)
                        VALUES(?,?,?,?,?,?,?,?,?)""",(project.project_id,*key,float(row["depth"]),None,"deleted",row["method"],
                        json.dumps({"reason":reason},ensure_ascii=False),now));deleted+=1
            active_uwis=[str(well.uwi) for well in project.wells]
            if active_uwis:
                placeholders=",".join("?" for _ in active_uwis)
                db.execute(f"DELETE FROM project_wells WHERE project_id=? AND uwi NOT IN ({placeholders})",(project.project_id,*active_uwis))
            else:db.execute("DELETE FROM project_wells WHERE project_id=?",(project.project_id,))
        return {"created":added,"updated":changed,"deleted":deleted}

    def restore_tops(self, project) -> int:
        """Restaura el snapshot del proyecto o, si no existe, la cima más reciente por UWI/nombre."""
        restored=0
        with self.connect() as db:
            for well in project.wells:
                rows=db.execute("SELECT * FROM tops WHERE project_id=? AND uwi=? ORDER BY depth",
                                (project.project_id,str(well.uwi))).fetchall()
                if not rows:
                    rows=db.execute("""SELECT t.* FROM tops t JOIN projects p ON p.project_id=t.project_id
                        WHERE t.uwi=? AND t.updated_utc=(SELECT MAX(t2.updated_utc) FROM tops t2 WHERE t2.uwi=t.uwi AND t2.top_name=t.top_name)
                        ORDER BY t.depth""",(str(well.uwi),)).fetchall()
                for row in rows:
                    well.tops[str(row["top_name"])]=float(row["depth"])
                    try:well.top_metadata[str(row["top_name"])]=json.loads(row["metadata_json"] or "{}")
                    except json.JSONDecodeError:well.top_metadata[str(row["top_name"])]={}
                    if row["color"]:project.top_colors[str(row["top_name"])]=str(row["color"])
                    restored+=1
        return restored

    def top_history(self, project_id: str) -> list[dict]:
        with self.connect() as db:
            return [dict(row) for row in db.execute("""SELECT h.*,w.name AS well_name FROM top_history h
                LEFT JOIN wells w ON w.uwi=h.uwi WHERE h.project_id=? ORDER BY h.id DESC""",(project_id,)).fetchall()]

    def tops_catalog(self) -> list[dict]:
        """Devuelve todas las interpretaciones guardadas para consulta controlada."""
        with self.connect() as db:
            return [dict(row) for row in db.execute("""SELECT t.*,w.name AS well_name,p.name AS project_name
                FROM tops t JOIN wells w ON w.uwi=t.uwi JOIN projects p ON p.project_id=t.project_id
                ORDER BY w.name,t.top_name,t.updated_utc DESC""").fetchall()]

    def coordinate_for_uwi(self,uwi: str) -> dict | None:
        with self.connect() as db:row=db.execute("SELECT * FROM wells WHERE uwi=?",(str(uwi),)).fetchone()
        if row is None:return None
        try:fields=json.loads(row["coordinate_fields_json"] or "[]")
        except json.JSONDecodeError:fields=[]
        return {"source_x":row["source_x"],"source_y":row["source_y"],"longitude":row["longitude"],"latitude":row["latitude"],
                "crs":row["crs"],"source_fields":fields,"source_file":row["coordinate_source"],"format":row["coordinate_format"],
                "validation_status":row["coordinate_status"] or "missing","validation_message":row["coordinate_message"] or ""}

    @staticmethod
    def _catalog_row(row) -> dict:
        item=dict(row)
        try:item["metadata"]=json.loads(item.get("metadata_json") or "{}")
        except json.JSONDecodeError:item["metadata"]={}
        try:fields=json.loads(item.get("coordinate_fields_json") or "[]")
        except json.JSONDecodeError:fields=[]
        item["coordinate_data"]={"source_x":item.get("source_x"),"source_y":item.get("source_y"),
            "longitude":item.get("longitude"),"latitude":item.get("latitude"),"crs":item.get("crs"),
            "source_fields":fields,"source_file":item.get("coordinate_source"),"format":item.get("coordinate_format"),
            "validation_status":item.get("coordinate_status") or "missing","validation_message":item.get("coordinate_message") or ""}
        return item

    def well_catalog(self) -> list[dict]:
        with self.connect() as db:
            rows=db.execute("""SELECT w.*,
                EXISTS(SELECT 1 FROM project_wells pw WHERE pw.uwi=w.uwi) AS used_in_projects,
                (SELECT COUNT(*) FROM tops t WHERE t.uwi=w.uwi) AS top_count
                FROM wells w ORDER BY w.name,w.uwi""").fetchall()
        return [self._catalog_row(row) for row in rows]

    def well_record(self,uwi: str) -> dict | None:
        with self.connect() as db:row=db.execute("SELECT * FROM wells WHERE uwi=?",(str(uwi),)).fetchone()
        return self._catalog_row(row) if row else None

    def upsert_well_record(self,record: dict) -> str:
        uwi=str(record.get("uwi","")).strip();name=str(record.get("name","")).strip()
        if not uwi:raise ValueError("El UWI es obligatorio.")
        if not name:raise ValueError("El nombre del pozo es obligatorio.")
        now=_utc_now();existing=self.well_record(uwi);metadata=dict(existing.get("metadata",{}) if existing else {});metadata.update(record.get("metadata",{}))
        coordinate=dict(record.get("coordinate_data",{}) or (existing.get("coordinate_data",{}) if existing else {}))
        with self.connect() as db:
            db.execute("""INSERT INTO wells(uwi,name,x,y,reference_elevation,metadata_json,updated_utc,source_x,source_y,longitude,latitude,crs,
                coordinate_source,coordinate_fields_json,coordinate_format,coordinate_status,coordinate_message) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(uwi) DO UPDATE SET name=excluded.name,x=excluded.x,y=excluded.y,reference_elevation=excluded.reference_elevation,
                metadata_json=excluded.metadata_json,updated_utc=excluded.updated_utc,source_x=excluded.source_x,source_y=excluded.source_y,
                longitude=excluded.longitude,latitude=excluded.latitude,crs=excluded.crs,coordinate_source=excluded.coordinate_source,
                coordinate_fields_json=excluded.coordinate_fields_json,coordinate_format=excluded.coordinate_format,
                coordinate_status=excluded.coordinate_status,coordinate_message=excluded.coordinate_message""",
                (uwi,name,coordinate.get("longitude"),coordinate.get("latitude"),record.get("reference_elevation"),json.dumps(metadata,ensure_ascii=False),now,
                 None if coordinate.get("source_x") is None else str(coordinate.get("source_x")),None if coordinate.get("source_y") is None else str(coordinate.get("source_y")),
                 coordinate.get("longitude"),coordinate.get("latitude"),coordinate.get("crs"),coordinate.get("source_file"),
                 json.dumps(coordinate.get("source_fields",[]),ensure_ascii=False),coordinate.get("format"),coordinate.get("validation_status","missing"),coordinate.get("validation_message")))
        return "updated" if existing else "created"

    def delete_well(self,uwi: str):
        with self.connect() as db:
            db.execute("DELETE FROM wells WHERE uwi=?",(str(uwi),))

    def export_tops_csv(self, project_id: str, path: str | Path) -> int:
        with self.connect() as db:
            rows=db.execute("""SELECT t.uwi,w.name AS well_name,t.top_name,t.depth,t.depth_unit,t.color,t.source,t.method,t.updated_utc
                FROM tops t JOIN wells w ON w.uwi=t.uwi WHERE t.project_id=? ORDER BY w.name,t.depth""",(project_id,)).fetchall()
        with Path(path).open("w",encoding="utf-8-sig",newline="") as stream:
            writer=csv.writer(stream);writer.writerow(["UWI","Pozo","Cima","Profundidad","Unidad","Color","Fuente","Método","Actualizado UTC"])
            writer.writerows([tuple(row) for row in rows])
        return len(rows)
