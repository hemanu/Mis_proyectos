from dataclasses import dataclass, field
from uuid import uuid4

import numpy as np
from .viewer_template import DEFAULT_TEMPLATE, curve_settings, default_curve_settings
from .spatial_reference import DEFAULT_PROJECT_METADATA,DEFAULT_SPATIAL_REFERENCE


@dataclass
class Well:
    name: str
    uwi: str
    depth: np.ndarray
    curves: dict[str, np.ndarray]
    depth_unit: str = ""
    curve_units: dict[str, str] = field(default_factory=dict)
    tops: dict[str, float] = field(default_factory=dict)
    top_metadata: dict[str, dict] = field(default_factory=dict)
    x: float | None = None
    y: float | None = None
    reference_elevation: float | None = None
    coordinate_data: dict = field(default_factory=dict)
    well_metadata: dict = field(default_factory=dict)

    def curve(self, mnemonic: str) -> np.ndarray:
        return self.curves[mnemonic]

    @property
    def curve_names(self) -> list[str]:
        return sorted(self.curves)

    @property
    def has_log_data(self) -> bool:
        return bool(np.asarray(self.depth).size and self.curves)


@dataclass
class CorrelationProject:
    project_id: str = field(default_factory=lambda: str(uuid4()))
    name: str = "Proyecto sin nombre"
    wells: list[Well] = field(default_factory=list)
    datum_top: str | None = None
    viewer_template: dict = field(default_factory=lambda: __import__('copy').deepcopy(DEFAULT_TEMPLATE))
    curve_overrides: dict[str, dict[str, dict]] = field(default_factory=dict)
    hidden_curves: set[str] = field(default_factory=set)
    hidden_tracks: set[str] = field(default_factory=set)
    show_lithology: bool = True
    show_tops: bool = True
    show_correlation_lines: bool = True
    spacing_mode: str = "proportional"  # proportional | uniform
    correlation_linewidth: float = 1.0
    top_colors: dict[str, str] = field(default_factory=dict)
    top_styles: dict[str, dict] = field(default_factory=dict)
    correlation_history: list[dict] = field(default_factory=list)
    hidden_section_wells: set[str] = field(default_factory=set)
    hidden_map_wells: set[str] = field(default_factory=set)
    project_metadata: dict = field(default_factory=lambda: dict(DEFAULT_PROJECT_METADATA))
    spatial_reference: dict = field(default_factory=lambda: dict(DEFAULT_SPATIAL_REFERENCE))
    section_lines: list[dict] = field(default_factory=list)
    active_section_line_id: str | None = None
    active_section_well_order: list[str] = field(default_factory=list)
    header_identifier_mode: str = "NAME_UWI"
    well_header_aliases: dict[str, str] = field(default_factory=dict)
    map_labels: list[dict] = field(default_factory=list)
    track_discretizations: dict[str, dict] = field(default_factory=dict)
    well_track_discretizations: dict[str, dict[str, dict]] = field(default_factory=dict)
    well_track_properties: dict[str, dict[str, dict]] = field(default_factory=dict)

    @staticmethod
    def default_track_properties() -> dict:
        return {"name":"Track","width":1.0,"min_width":150,"background":"#FFFFFF",
                "border_visible":True,"border_color":"#9CA3AF","border_width":0.7,
                "grid_enabled":True,"grid_color":"#B8C0CC","grid_width":0.5,
                "grid_alpha":0.5,"grid_minor_color":"#D8DEE8","grid_minor_width":0.3,
                "grid_minor_alpha":0.25,"grid_same_color":False,
                "horizontal_grid_enabled":True,"horizontal_grid_interval":0.0,
                "horizontal_grid_subdivisions":0,"horizontal_grid_style":"solid",
                "vertical_grid_enabled":True,"vertical_grid_divisions":5,
                "vertical_grid_subdivisions":0,"vertical_grid_style":"solid",
                "vertical_grid_reference":"","vertical_grid_scale_mode":"auto",
                "vertical_grid_log_detail":"2_5","vertical_grid_show_labels":True,
                "depth_scale":"first","separation":3,
                "header_height":64,"header_background":"#FFFFFF","header_font_size":9}

    def effective_track_properties(self, track_key: str, well_uwi: str | None = None) -> dict:
        import copy
        tracks=self.viewer_template.get("tracks",[])
        track=next((item for item in tracks if str(item.get("key"))==str(track_key)),{})
        result=self.default_track_properties();result.update(copy.deepcopy(track))
        if well_uwi is not None:result.update(copy.deepcopy(self.well_track_properties.get(str(well_uwi),{}).get(str(track_key),{})))
        result["width"]=max(.1,float(result.get("width",1.0)))
        result["min_width"]=max(50,int(result.get("min_width",150)))
        result["border_width"]=max(0.0,float(result.get("border_width",.7)))
        result["grid_width"]=max(0.0,float(result.get("grid_width",.5)))
        result["grid_alpha"]=max(0.0,min(1.0,float(result.get("grid_alpha",.5))))
        result["grid_minor_width"]=max(0.0,float(result.get("grid_minor_width",.3)))
        result["grid_minor_alpha"]=max(0.0,min(1.0,float(result.get("grid_minor_alpha",.25))))
        result["horizontal_grid_interval"]=max(0.0,float(result.get("horizontal_grid_interval",0.0)))
        result["horizontal_grid_subdivisions"]=max(0,min(10,int(result.get("horizontal_grid_subdivisions",0))))
        result["vertical_grid_divisions"]=max(1,min(20,int(result.get("vertical_grid_divisions",5))))
        result["vertical_grid_subdivisions"]=max(0,min(10,int(result.get("vertical_grid_subdivisions",0))))
        result["header_height"]=max(36,int(result.get("header_height",64)))
        result["header_font_size"]=max(6,int(result.get("header_font_size",9)))
        return result

    def set_track_properties(self, track_key: str, properties: dict, well_uwi: str | None = None):
        import copy
        key=str(track_key)
        if well_uwi is not None:
            self.well_track_properties.setdefault(str(well_uwi),{})[key]=copy.deepcopy(properties);return
        track=next((item for item in self.viewer_template.setdefault("tracks",[]) if str(item.get("key"))==key),None)
        if track is None:raise KeyError(key)
        track.update(copy.deepcopy(properties))

    def remove_well_track_properties(self, well_uwi: str, track_key: str):
        values=self.well_track_properties.get(str(well_uwi),{});values.pop(str(track_key),None)
        if not values:self.well_track_properties.pop(str(well_uwi),None)

    @staticmethod
    def well_api(well: Well) -> str:
        metadata={str(key).strip().upper():value for key,value in well.well_metadata.items()}
        for key in ("API","API_NUMBER","API_NO","API#"):
            value=str(metadata.get(key,"") or "").strip()
            if value:return value
        return str(well.uwi or "").strip()

    def well_header_label(self, well: Well, mode: str | None = None) -> str:
        mode=str(mode or self.header_identifier_mode or "NAME_UWI").upper()
        name=str(well.name or "").strip();uwi=str(well.uwi or "").strip();api=self.well_api(well)
        if mode=="CUSTOM":return self.well_header_aliases.get(uwi,name or uwi or api)
        values={"NAME":[name],"UWI":[uwi],"API":[api],"NAME_UWI":[name,uwi],"NAME_API":[name,api]}.get(mode,[name,uwi])
        clean=[]
        for value in values:
            if value and value not in clean:clean.append(value)
        return "\n".join(clean) or "Pozo sin identificar"

    def set_well_header_alias(self, uwi: str, alias: str):
        key=str(uwi);value=str(alias).strip()
        if value:self.well_header_aliases[key]=value
        else:self.well_header_aliases.pop(key,None)

    @staticmethod
    def default_track_discretization(source: str = "GR") -> dict:
        return {"enabled":True,"source":str(source).upper(),"reference":75.0,
                "line_color":"#111827","line_width":1.0,"line_style":"--","alpha":0.38,
                "left":{"lithology":"Arena","color":"#F4D35E","pattern":".."},
                "right":{"lithology":"Lutita","color":"#9CA3AF","pattern":"--"}}

    def set_track_discretization(self, track_key: str, settings: dict):
        """Store reusable style defaults; this no longer activates every well."""
        import copy
        clean=self.default_track_discretization(settings.get("source","GR"));clean.update(copy.deepcopy(settings))
        clean["enabled"]=bool(clean["enabled"]);clean["source"]=str(clean["source"]).upper();clean["reference"]=float(clean["reference"])
        clean["line_width"]=float(clean["line_width"]);clean["alpha"]=max(0.0,min(1.0,float(clean["alpha"])))
        self.track_discretizations[str(track_key)]=clean

    def set_well_track_discretization(self, well_uwi: str, track_key: str, settings: dict):
        import copy
        clean=self.default_track_discretization(settings.get("source","GR"));clean.update(copy.deepcopy(settings))
        clean["enabled"]=bool(clean["enabled"]);clean["source"]=str(clean["source"]).upper();clean["reference"]=float(clean["reference"])
        clean["line_width"]=float(clean["line_width"]);clean["alpha"]=max(0.0,min(1.0,float(clean["alpha"])))
        self.well_track_discretizations.setdefault(str(well_uwi),{})[str(track_key)]=clean

    def well_track_discretization(self, well_uwi: str, track_key: str) -> dict | None:
        return self.well_track_discretizations.get(str(well_uwi),{}).get(str(track_key))

    def remove_well_track_discretization(self, well_uwi: str, track_key: str):
        configurations=self.well_track_discretizations.get(str(well_uwi),{});configurations.pop(str(track_key),None)
        if not configurations:self.well_track_discretizations.pop(str(well_uwi),None)

    def well_visible_in_section(self,uwi: str) -> bool:
        return str(uwi) not in self.hidden_section_wells

    def well_visible_on_map(self,uwi: str) -> bool:
        return str(uwi) not in self.hidden_map_wells

    def toggle_well_in_section(self,uwi: str):
        key=str(uwi);self.hidden_section_wells.remove(key) if key in self.hidden_section_wells else self.hidden_section_wells.add(key)

    def toggle_well_on_map(self,uwi: str):
        key=str(uwi);self.hidden_map_wells.remove(key) if key in self.hidden_map_wells else self.hidden_map_wells.add(key)

    @staticmethod
    def default_top_style() -> dict:
        return {"font_size":5.2,"italic":False,"bold":False,"text_color":None,
                "highlight":False,"background_color":"#FFF59D"}

    def effective_top_style(self, top_name: str) -> dict:
        style=self.default_top_style();style.update(self.top_styles.get(str(top_name),{}));return style

    def set_top_style(self, top_name: str, style: dict):
        clean=self.default_top_style();clean.update(style)
        clean["font_size"]=float(clean["font_size"]);clean["italic"]=bool(clean["italic"])
        clean["bold"]=bool(clean["bold"]);clean["highlight"]=bool(clean["highlight"])
        self.top_styles[str(top_name)]=clean

    def transfer_top(self, source_uwi: str, target_uwi: str, top_name: str,
                     target_depth: float, curve: str, interval: tuple[float, float]) -> dict:
        """Create an interpreted top while retaining enough state to undo it."""
        source=next(w for w in self.wells if str(w.uwi)==str(source_uwi))
        target=next(w for w in self.wells if str(w.uwi)==str(target_uwi))
        previous=target.tops.get(top_name);previous_meta=target.top_metadata.get(top_name)
        record={"source_uwi":str(source.uwi),"source_depth":float(source.tops[top_name]),
                "target_uwi":str(target.uwi),"target_depth":float(target_depth),
                "top_name":str(top_name),"curve":str(curve).upper(),
                "interval":[float(interval[0]),float(interval[1])],"method":"assisted_drag",
                "previous_depth":previous,"previous_metadata":previous_meta}
        target.tops[top_name]=float(target_depth)
        target.top_metadata[top_name]={key:value for key,value in record.items()
                                       if key not in {"previous_depth","previous_metadata"}}
        self.correlation_history.append(record)
        return record

    def undo_last_correlation(self) -> dict | None:
        if not self.correlation_history:return None
        record=self.correlation_history.pop();target=next((w for w in self.wells if str(w.uwi)==record["target_uwi"]),None)
        if target is None:return record
        if record.get("previous_depth") is None:
            target.tops.pop(record["top_name"],None);target.top_metadata.pop(record["top_name"],None)
        else:
            target.tops[record["top_name"]]=float(record["previous_depth"])
            if record.get("previous_metadata") is None:target.top_metadata.pop(record["top_name"],None)
            else:target.top_metadata[record["top_name"]]=record["previous_metadata"]
        return record

    def adjust_top(self, well_uwi: str, top_name: str, new_depth: float,
                   method: str = "cursor_adjustment") -> dict:
        """Move one well top and preserve its provenance and previous state."""
        import copy
        well=next(w for w in self.wells if str(w.uwi)==str(well_uwi))
        if top_name not in well.tops:raise KeyError(f"La cima {top_name} no existe en {well.name}.")
        previous=float(well.tops[top_name]);previous_meta=copy.deepcopy(well.top_metadata.get(top_name))
        record={"target_uwi":str(well.uwi),"top_name":str(top_name),
                "target_depth":float(new_depth),"previous_depth":previous,
                "previous_metadata":previous_meta,"method":str(method)}
        metadata=copy.deepcopy(previous_meta) if previous_meta else {}
        adjustment={"previous_depth":previous,"new_depth":float(new_depth),"method":str(method)}
        metadata.setdefault("adjustments",[]).append(adjustment)
        metadata["last_adjustment"]=adjustment
        well.tops[top_name]=float(new_depth);well.top_metadata[top_name]=metadata
        self.correlation_history.append(record)
        return record

    def adopt_database_top(self, well_uwi: str, top_name: str, depth: float, metadata: dict | None = None) -> dict:
        """Incorpora o actualiza una cima seleccionada explícitamente en el catálogo."""
        import copy
        well=next(w for w in self.wells if str(w.uwi)==str(well_uwi));previous=well.tops.get(top_name)
        previous_meta=copy.deepcopy(well.top_metadata.get(top_name))
        record={"target_uwi":str(well.uwi),"top_name":str(top_name),"target_depth":float(depth),
                "previous_depth":previous,"previous_metadata":previous_meta,"method":"database_selection"}
        top_meta=copy.deepcopy(metadata or {});top_meta["method"]="database_selection"
        well.tops[str(top_name)]=float(depth);well.top_metadata[str(top_name)]=top_meta
        self.correlation_history.append(record);return record

    @property
    def template_curves(self) -> list[str]:
        return list(dict.fromkeys(str(item.get("source", "")).upper() for item in self.viewer_template.get("curves", [])))

    def effective_curve_settings(self, well_uwi: str, source: str, track_key: str | None = None) -> dict | None:
        base = curve_settings(self.viewer_template, source, track_key)
        if base is None:
            return None
        presentation=base.get("presentation","normal")
        base.update(self.curve_overrides.get("*", {}).get(source.upper(), {}))
        base.update(self.curve_overrides.get(well_uwi, {}).get(source.upper(), {}))
        # Mirroring belongs to this exact track/curve assignment, never globally.
        base["presentation"]=presentation
        return base

    def set_curve_override(self, source: str, settings: dict, well_uwi: str | None = None):
        key = well_uwi or "*"
        self.curve_overrides.setdefault(key, {})[source.upper()] = dict(settings)

    def clear_curve_override(self, source: str, well_uwi: str | None = None):
        key = well_uwi or "*"
        self.curve_overrides.get(key, {}).pop(source.upper(), None)

    def curve_visible(self, source: str) -> bool:
        return source.upper() not in self.hidden_curves

    def track_visible(self, key: str) -> bool:
        return str(key) not in self.hidden_tracks

    def toggle_curve(self, source: str):
        source = source.upper()
        self.hidden_curves.remove(source) if source in self.hidden_curves else self.hidden_curves.add(source)

    def track_has_curve(self, track_key: str, source: str) -> bool:
        return curve_settings(self.viewer_template, source, track_key) is not None

    def assign_curve_to_track(self, track_key: str, source: str):
        source=str(source).upper(); track_key=str(track_key)
        if self.track_has_curve(track_key,source):return
        settings=curve_settings(self.viewer_template,source)
        if settings is None:settings=default_curve_settings(source,track_key)
        else:settings["track_key"]=track_key
        self.viewer_template.setdefault("curves",[]).append(settings)
        self.hidden_curves.discard(source)

    def remove_curve_from_track(self, track_key: str, source: str):
        source=str(source).upper(); track_key=str(track_key)
        self.viewer_template["curves"]=[c for c in self.viewer_template.get("curves",[])
            if not (str(c.get("track_key"))==track_key and str(c.get("source","")).upper()==source)]

    def curve_presentation(self, track_key: str, source: str) -> str:
        settings=curve_settings(self.viewer_template,source,track_key)
        return str(settings.get("presentation","normal")) if settings else "normal"

    def set_curve_presentation(self, track_key: str, source: str, presentation: str):
        if presentation not in {"normal","axis_inverted"}:raise ValueError("Presentación de curva no válida.")
        source=str(source).upper();track_key=str(track_key)
        for curve in self.viewer_template.get("curves",[]):
            if str(curve.get("track_key"))==track_key and str(curve.get("source","")).upper()==source:
                curve["presentation"]=presentation;return
        raise KeyError(f"{source} no está asignada a {track_key}.")

    def duplicate_curve_as_mirror(self, source: str, target_track: str):
        self.assign_curve_to_track(target_track,source)
        self.set_curve_presentation(target_track,source,"axis_inverted")

    def toggle_track(self, key: str):
        key = str(key)
        self.hidden_tracks.remove(key) if key in self.hidden_tracks else self.hidden_tracks.add(key)

    def visible_tracks(self) -> list[dict]:
        return [track for track in self.viewer_template.get("tracks", []) if self.track_visible(track.get("key", ""))]

    def add_or_replace_wells(self, incoming: list[Well]) -> tuple[int,int]:
        """Accumulate wells by UWI; a repeated UWI refreshes that well in place."""
        positions={str(well.uwi):index for index,well in enumerate(self.wells)}
        added=updated=0
        for well in incoming:
            key=str(well.uwi)
            if key in positions:self.wells[positions[key]]=well;updated+=1
            else:
                positions[key]=len(self.wells);self.wells.append(well);added+=1
                self.hidden_section_wells.discard(key);self.hidden_map_wells.discard(key)
        return added,updated

    def template_payload(self) -> dict:
        """Return the complete reusable presentation, not only curve rows."""
        import copy
        payload=copy.deepcopy(self.viewer_template)
        global_overrides=self.curve_overrides.get("*",{})
        for curve in payload.get("curves",[]):
            applied={key:value for key,value in global_overrides.get(str(curve.get("source","")).upper(),{}).items()
                     if key!="presentation"}
            curve.update(applied)
        payload["correlation_state"]={
            "hidden_curves":sorted(self.hidden_curves),
            "hidden_tracks":sorted(self.hidden_tracks),
            "show_lithology":self.show_lithology,
            "show_tops":self.show_tops,
            "show_correlation_lines":self.show_correlation_lines,
            "spacing_mode":self.spacing_mode,
            "correlation_linewidth":self.correlation_linewidth,
            "top_colors":copy.deepcopy(self.top_colors),
            "top_styles":copy.deepcopy(self.top_styles),
            "header_identifier_mode":self.header_identifier_mode,
            "track_discretizations":copy.deepcopy(self.track_discretizations),
        }
        return payload

    def apply_template(self, payload: dict):
        import copy
        self.viewer_template=copy.deepcopy(payload)
        state=payload.get("correlation_state",{})
        self.hidden_curves=set(state.get("hidden_curves",[]))
        self.hidden_tracks=set(state.get("hidden_tracks",[]))
        self.show_lithology=bool(state.get("show_lithology",True))
        self.show_tops=bool(state.get("show_tops",True))
        self.show_correlation_lines=bool(state.get("show_correlation_lines",True))
        self.spacing_mode=str(state.get("spacing_mode","proportional"))
        self.correlation_linewidth=float(state.get("correlation_linewidth",1.0))
        self.top_colors=copy.deepcopy(state.get("top_colors",{}))
        self.top_styles=copy.deepcopy(state.get("top_styles",{}))
        self.header_identifier_mode=str(state.get("header_identifier_mode","NAME_UWI"))
        self.track_discretizations=copy.deepcopy(state.get("track_discretizations",{}))
        self.curve_overrides.clear()

    @staticmethod
    def lithology_mnemonic(well: Well) -> str | None:
        for candidate in ("LITHOLOGY", "LITHO", "LITH", "LITO"):
            if candidate in well.curves:
                return candidate
        return None

    @property
    def common_curves(self) -> list[str]:
        if not self.wells:
            return []
        names = set(self.wells[0].curve_names)
        for well in self.wells[1:]:
            names.intersection_update(well.curve_names)
        return sorted(names)

    @property
    def available_curves(self) -> list[str]:
        names: set[str] = set()
        for well in self.wells:names.update(well.curve_names)
        return sorted(names)

    @property
    def top_names(self) -> list[str]:
        names: set[str] = set()
        for well in self.wells:
            names.update(well.tops)
        def mean_depth(name: str) -> float:
            values = [well.tops[name] for well in self.wells if name in well.tops]
            return sum(values) / len(values)
        return sorted(names, key=mean_depth)

    @property
    def common_top_names(self) -> list[str]:
        """Topes disponibles en todos los pozos, únicos válidos como datum común."""
        wells=[well for well in self.wells if well.has_log_data]
        if not wells:
            return []
        common = set(wells[0].tops)
        for well in wells[1:]:
            common.intersection_update(well.tops)
        return [name for name in self.top_names if name in common]
