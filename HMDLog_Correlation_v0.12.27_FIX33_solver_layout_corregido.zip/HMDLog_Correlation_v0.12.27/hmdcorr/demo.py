import numpy as np

from .models import CorrelationProject, Well


def _gr_curve(depth: np.ndarray, phase: float, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    regional = 65 + 24 * np.sin(depth / 34 + phase)
    beds = 18 * np.sin(depth / 9 + phase * 0.7)
    noise = rng.normal(0, 4.5, depth.size)
    return np.clip(regional + beds + noise, 5, 145)


def _demo_curves(depth, phase, seed):
    gr = _gr_curve(depth, phase, seed)
    sp = -20 - 0.75 * gr + 8 * np.sin(depth / 18 + phase)
    clean = np.clip((150 - gr) / 145, 0.03, 1)
    ild = np.clip(0.6 * np.exp(5.5 * clean) * (1 + .15*np.sin(depth/7)), .2, 2000)
    ilm = np.clip(ild * (0.55 + .12*np.sin(depth/13 + phase)), .2, 2000)
    sfl = np.clip(ilm * (0.45 + .10*np.cos(depth/11)), .2, 2000)
    lithology = np.select([gr < 45, gr < 80, gr >= 80], [1, 2, 3], default=0)
    return {"GR": gr, "SP": sp, "ILD": ild, "ILM": ilm, "SFL": sfl, "LITHOLOGY": lithology}


def create_demo_project() -> CorrelationProject:
    specifications = [
        ("POZO A", "DEMO-001", 1000.0, 0.0, {"Fm. Alfa": 1050, "Fm. Beta": 1132, "Fm. Gamma": 1218}),
        ("POZO B", "DEMO-002", 1022.0, 0.8, {"Fm. Alfa": 1075, "Fm. Beta": 1150, "Fm. Gamma": 1245}),
        ("POZO C", "DEMO-003", 985.0, 1.5, {"Fm. Alfa": 1041, "Fm. Beta": 1120, "Fm. Gamma": 1202}),
        ("POZO D", "DEMO-004", 1010.0, 2.1, {"Fm. Alfa": 1068, "Fm. Beta": 1141, "Fm. Gamma": 1226}),
        ("POZO E", "DEMO-005", 1040.0, 2.8, {"Fm. Alfa": 1092, "Fm. Beta": 1178, "Fm. Gamma": 1260}),
    ]
    wells = []
    for index, (name, uwi, start, phase, tops) in enumerate(specifications):
        depth = np.arange(start, start + 330.5, 0.5)
        wells.append(
            Well(
                name=name,
                uwi=uwi,
                depth=depth,
                curves=_demo_curves(depth, phase, 100 + index),
                depth_unit="ft",
                curve_units={"GR":"API","SP":"mV","ILD":"ohm-m","ILM":"ohm-m","SFL":"ohm-m"},
                tops=tops,
                x=float([0, 1450, 3100, 4780, 6250][index]),
                y=float([0, 100, -60, 80, 20][index]),
            )
        )
    return CorrelationProject(name="Demostración de correlación", wells=wells)
