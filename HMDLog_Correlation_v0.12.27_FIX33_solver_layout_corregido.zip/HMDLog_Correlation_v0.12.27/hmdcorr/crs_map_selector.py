"""Asistente cartográfico desconectado para recomendar el CRS del proyecto."""
from __future__ import annotations

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from matplotlib.widgets import RectangleSelector
from PySide6.QtWidgets import QDialog,QDialogButtonBox,QHBoxLayout,QLabel,QPushButton,QTableWidget,QTableWidgetItem,QVBoxLayout

from .spatial_reference import recommend_crs_for_bounds


class CrsMapSelectorDialog(QDialog):
    def __init__(self,wells,parent=None):
        super().__init__(parent);self.wells=list(wells);self.selected_crs=None;self.result=None
        self.setWindowTitle("Seleccionar sistema de referencia en el mapa");self.resize(940,680);layout=QVBoxLayout(self)
        help_label=QLabel("Arrastre el cursor para dibujar un rectángulo sobre el área del proyecto. HMDLog recomendará el CRS; usted confirma antes de aplicarlo.")
        help_label.setWordWrap(True);layout.addWidget(help_label)
        self.figure=Figure(figsize=(9,5));self.canvas=FigureCanvasQTAgg(self.figure);layout.addWidget(self.canvas,1);self.axis=self.figure.add_subplot(111)
        self.table=QTableWidget(0,3);self.table.setHorizontalHeaderLabels(["Prioridad","Sistema de referencia","Motivo"]);self.table.setMaximumHeight(155);layout.addWidget(self.table)
        self.summary=QLabel("Seleccione un área para obtener recomendaciones.");self.summary.setWordWrap(True);layout.addWidget(self.summary)
        footer=QHBoxLayout();reset=QPushButton("Restablecer vista");reset.clicked.connect(self._draw_map);footer.addWidget(reset);footer.addStretch()
        self.buttons=QDialogButtonBox(QDialogButtonBox.Apply|QDialogButtonBox.Cancel);self.buttons.button(QDialogButtonBox.Apply).setText("Aplicar CRS seleccionado")
        self.buttons.button(QDialogButtonBox.Apply).setEnabled(False);self.buttons.button(QDialogButtonBox.Cancel).setText("Cancelar")
        self.buttons.clicked.connect(self._button_clicked);footer.addWidget(self.buttons);layout.addLayout(footer)
        self.table.itemSelectionChanged.connect(self._selection_changed);self._draw_map()
        self.selector=RectangleSelector(self.axis,self._area_selected,useblit=True,button=[1],minspanx=0.05,minspany=0.05,spancoords="data",interactive=True)

    def _valid_points(self):
        points=[]
        for well in self.wells:
            data=getattr(well,"coordinate_data",{}) or {};lat=data.get("latitude");lon=data.get("longitude")
            if lat is not None and lon is not None:
                try:points.append((float(lon),float(lat),well.name))
                except (TypeError,ValueError):pass
        return points

    def _draw_map(self):
        self.axis.clear();self.axis.set_facecolor("#f7fbff");self.axis.grid(True,color="#cbd5e1",linewidth=.6);self.axis.set_xlabel("Longitud (°)");self.axis.set_ylabel("Latitud (°)")
        self.axis.set_title("Mapa geográfico del proyecto — selección rectangular")
        points=self._valid_points()
        if points:
            xs=[p[0] for p in points];ys=[p[1] for p in points];self.axis.scatter(xs,ys,s=38,color="#1565c0",edgecolor="white",zorder=3)
            for x,y,name in points:self.axis.annotate(name,(x,y),xytext=(4,4),textcoords="offset points",fontsize=8)
            margin_x=max(1,(max(xs)-min(xs))*.35);margin_y=max(1,(max(ys)-min(ys))*.35);self.axis.set_xlim(min(xs)-margin_x,max(xs)+margin_x);self.axis.set_ylim(min(ys)-margin_y,max(ys)+margin_y)
        else:self.axis.set_xlim(-180,180);self.axis.set_ylim(-90,90)
        self.canvas.draw_idle()

    def _area_selected(self,press,release):
        if press.xdata is None or release.xdata is None:return
        try:self.result=recommend_crs_for_bounds(press.xdata,press.ydata,release.xdata,release.ydata)
        except ValueError as exc:self.summary.setText(str(exc));return
        west,south,east,north=self.result["bounds"];center_lon,center_lat=self.result["center"]
        crossing="; atraviesa más de una zona UTM" if self.result["crosses_utm_zones"] else ""
        self.summary.setText(f'Región: {self.result["region"]} · Centro: {center_lat:.5f}, {center_lon:.5f} · Zona UTM {self.result["utm_zone"]}{crossing}')
        items=self.result["recommendations"];self.table.setRowCount(len(items))
        for row,item in enumerate(items):
            for column,value in enumerate(("Recomendado" if row==0 else "Alternativo",f'{item["code"]} — {item["name"]}',item["reason"])):
                cell=QTableWidgetItem(value);cell.setData(256,item["code"]);self.table.setItem(row,column,cell)
        self.table.resizeColumnsToContents();self.table.horizontalHeader().setStretchLastSection(True);self.table.selectRow(0);self._selection_changed()

    def _selection_changed(self):
        rows=self.table.selectionModel().selectedRows() if self.table.selectionModel() else []
        self.selected_crs=self.table.item(rows[0].row(),0).data(256) if rows else None
        self.buttons.button(QDialogButtonBox.Apply).setEnabled(bool(self.selected_crs))

    def _button_clicked(self,button):
        role=self.buttons.buttonRole(button)
        if role==QDialogButtonBox.ApplyRole and self.selected_crs:self.accept()
        elif role==QDialogButtonBox.RejectRole:self.reject()
