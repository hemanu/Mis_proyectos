$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Assert-LastCommand([string]$Description) {
    if ($LASTEXITCODE -ne 0) {
        throw "$Description fallo (codigo $LASTEXITCODE). Revise los mensajes de pip mostrados arriba."
    }
}

try {
    Write-Host "Comprobando Python..."
    & py -c "import sys; print('Python', sys.version)"
    Assert-LastCommand "La comprobacion de Python"

    Write-Host "Creando o reparando el entorno virtual..."
    & py -m venv .venv
    Assert-LastCommand "La creacion del entorno virtual"

    $PythonExe = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
    if (-not (Test-Path -LiteralPath $PythonExe)) {
        throw "No se creo $PythonExe"
    }

    Write-Host "Actualizando el instalador de paquetes..."
    & $PythonExe -m pip install --upgrade pip setuptools wheel
    Assert-LastCommand "La actualizacion de pip"

    Write-Host "Instalando dependencias de HMDLog Correlation..."
    & $PythonExe -m pip install --prefer-binary -r requirements.txt
    Assert-LastCommand "La instalacion de dependencias"

    Write-Host "Verificando motores graficos, PySide6 y dependencias cientificas..."
    & $PythonExe -c "import matplotlib, PySide6, numpy, pandas, lasio, openpyxl, pyproj; import vispy; print('Dependencias verificadas. Matplotlib', matplotlib.__version__, 'VisPy', vispy.__version__, 'PyProj', pyproj.__version__)"
    Assert-LastCommand "La verificacion final"

    Write-Host ""
    Write-Host "Instalacion terminada y verificada." -ForegroundColor Green
    Write-Host "Abra Iniciar_HMDLog_Correlation.bat"
}
catch {
    Write-Host ""
    Write-Host "LA INSTALACION NO SE COMPLETO." -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host "Corrija el error indicado y vuelva a ejecutar .\Instalar.ps1"
    exit 1
}
