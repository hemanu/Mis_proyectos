import sys

from PySide6.QtWidgets import QApplication

from hmdcorr.main_window import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("HMDLog Correlation")
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
