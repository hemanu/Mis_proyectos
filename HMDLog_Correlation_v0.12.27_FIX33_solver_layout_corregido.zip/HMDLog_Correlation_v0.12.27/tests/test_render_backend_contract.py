from hmdcorr.rendering import BackendStatus, probe_vispy


def test_vispy_probe_does_not_create_an_opengl_context():
    status = probe_vispy()
    assert isinstance(status, BackendStatus)
    assert status.key == "vispy"
    assert status.label
    assert isinstance(status.available, bool)
    assert status.detail


def test_backend_package_keeps_vispy_and_qt_imports_lazy():
    import sys
    import hmdcorr.rendering
    assert "hmdcorr.rendering.vispy_canvas" not in sys.modules


def test_gpu_preview_builds_all_components_on_one_root_grid():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw_block=source.split("def _draw_project",1)[1]
    assert "well_grid=grid.add_grid" not in draw_block
    assert "track_grid=well_grid.add_grid" not in draw_block
    assert "header_view=grid.add_view(row=1,col=track_column" in draw_block
    assert "plot_view=grid.add_view(row=2,col=track_column" in draw_block
    assert "track_grid=_LayoutHandle(header_view,plot_view)" in draw_block
    assert '"well":well,"grid":track_grid,"well_grid":well_grid' in draw_block
    assert "project.well_header_label(well)" in draw_block
    assert "_header_scale(settings)" in draw_block and "curve_label" in draw_block
    assert "header_view.height_min=track_header_height" in draw_block
    assert "well_header_view.height_min=common_header_height" in draw_block
    assert "header_view.height_max=track_header_height" in draw_block
    assert "well_header_view.height_max=common_header_height" in draw_block
    assert "plot_view.camera.link(master_camera,axis=\"y\")" in draw_block


def test_gpu_headers_are_not_an_external_qt_bar():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    assert "class _GpuHeaderBar" not in source
    assert "gpuWellHeaderBar" not in source
    assert "header_bar" not in source


def test_gpu_compound_view_has_unambiguous_version_marker():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    assert "Visor GPU compuesto v0.12.27" in source
    assert "VISOR COMPUESTO v0.12.27" in source


def test_gpu_depth_axes_and_cursor_are_synchronized_per_well():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    assert 'scene.AxisWidget(orientation="left"' not in source
    assert 'depth_tick_line=scene.visuals.Line' in source and 'depth_tick_texts=[' in source
    assert "plot_view.camera.flip=(False,True,False)" in source
    assert 'plot_view.camera.link(master_camera,axis="y")' in source
    assert "self.canvas.events.mouse_move.connect(self._on_mouse_move)" in source
    hit=source.split("def _track_at",1)[1].split("def _set_zoom_mode",1)[0]
    assert 'self.canvas.scene.node_transform(group["track"].scene)' in hit
    assert "point=transform.map(pos)" in hit
    cursor=source.split("def _update_cursor_readout",1)[1].split("def _track_at",1)[0]
    assert 'group["cursor_line"].set_data' in cursor
    assert 'hovered["raw_depth"]' in cursor and 'hovered.get("curve_data",{})' in cursor
    assert "cursor_table" not in source


def test_gpu_cursor_visibility_is_set_after_visual_construction():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    creation=source.split("cursor_line=scene.visuals.Line",1)[1].split("self.well_groups.append",1)[0]
    assert "parent=plot_view.scene,visible=False" not in creation
    assert "cursor_line.visible=False" in creation
    assert "cursor_text.visible=False" in creation
    assert "no fue posible inicializar la vista GPU" in source


def test_gpu_track_groups_share_one_flexible_horizontal_geometry():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw=source.split("def _draw_project",1)[1]
    assert "well_grid=grid.add_grid" not in draw
    assert "class _LayoutHandle" in source
    assert 'track_grid.stretch=(float(props.get("width",1.0)),1)' in draw
    assert 'configured_width_min=int(props.get("min_width",150))' in draw
    assert 'technical_width_min=42' in draw
    assert 'track_grid.width_min=technical_width_min' in draw
    assert 'well_handle.stretch=(well_weight,1)' in draw
    assert 'gap_handle.width_min=44' in draw
    responsive=source.split("def _apply_responsive_track_minimums",1)[1].split("def _open_track_grid_configuration",1)[0]
    assert 'group["grid"].width_min=group.get("base_width_min",42)' in responsive
    assert 'responsive_floor=' not in responsive
    assert "axis_spacer" not in draw
    assert 'plot_view.camera.rect=(0.0,low-margin,1.0,(high-low)+2*margin)' in draw
    assert 'x=(-.05,1.05)' not in draw
    assert 'border_color=plot_border' not in draw


def test_gpu_well_spacing_uses_real_distance_or_uniform_mode():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw=source.split("def _draw_project",1)[1]
    assert "distances=[_well_distance" in draw
    assert 'project.spacing_mode=="uniform"' in draw
    assert "gap_stretch=max(.12,min(.85,.28*ratio))" in draw
    assert "_distance_label(distance)" in draw


def test_gpu_track_manager_properties_are_applied_to_real_track_visuals():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw=source.split("def _draw_project",1)[1]
    assert "visible_tracks=project.visible_tracks()" in draw
    assert "_track_curve_settings(project,well,track_key)" in draw
    assert 'props.get("background","#FFFFFF")' in draw
    assert 'props.get("header_background","#FFFFFF")' in draw
    assert 'props.get("border_width",.7)' in draw
    assert 'props.get("grid_width",.5)' in draw and 'props.get("grid_alpha",.5)' in draw
    assert "hgrid_visual=scene.visuals.Line" in draw and "vgrid_visual=scene.visuals.Line" in draw
    assert "vminor_grid_visual=scene.visuals.Line" in draw
    assert 'props.get("horizontal_grid_enabled",True)' in draw
    assert 'props.get("vertical_grid_enabled",True)' in draw
    assert "_append_grid_segment" in source
    assert 'str(props.get("name",track_key))' in draw


def test_track_grid_configurator_is_available_from_menu_and_gpu_toolbar():
    from pathlib import Path
    root=Path(__file__).parents[1]
    window=(root/"hmdcorr/main_window.py").read_text(encoding="utf-8")
    gpu=(root/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    manager=(root/"hmdcorr/track_manager.py").read_text(encoding="utf-8")
    assert '"Configurar tracks y retícula…"' in window
    assert '_tool_button("configure-grid","Configurar tracks y retícula")' in gpu
    assert "self.configure_grid_button.clicked.connect(self._open_track_grid_configuration)" in gpu
    assert "configuration_callback=self._manage_tracks" in window
    assert 'self.configuration_callback(active.get("track_key") if active else None' in gpu
    assert "self.active_track_group=group" in gpu
    assert "def _manage_tracks(self,track_key=None,well_uwi=None)" in window
    assert "initial_track_key=track_key,initial_well_uwi=well_uwi" in window
    assert 'self.setWindowTitle("Configurar tracks y retícula")' in manager
    for field in ("horizontal_grid_interval","horizontal_grid_subdivisions","horizontal_grid_style",
                  "vertical_grid_divisions","vertical_grid_subdivisions","vertical_grid_style"):
        assert f"self.{field}" in manager


def test_gpu_vertical_grid_follows_reference_curve_scale():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    manager=(Path(__file__).parents[1]/"hmdcorr/track_manager.py").read_text(encoding="utf-8")
    helper=source.split("def _vertical_grid_positions",1)[1].split("_ICON_DIR",1)[0]
    assert 'props.get("vertical_grid_reference") or fallback_source' in helper
    assert 'if mode=="auto":mode=str(settings.get("scale","linear"))' in helper
    assert "_axis_positions([value],settings,mode)" in helper
    assert '[2,5] if detail=="2_5" else list(range(2,10))' in helper
    assert '[(normalized(value),f"{value:g}") for value in major_values]' in helper
    assert 'self.vertical_grid_scale_mode.addItem("Automática según la curva","auto")' in manager
    assert 'self.vertical_grid_log_detail.addItem("Décadas + 2 y 5","2_5")' in manager
    assert 'self.vertical_grid_show_labels=QCheckBox' in manager


def test_gpu_log_header_separates_curve_limits_and_decade_labels():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw=source.split("def _draw_project",1)[1].split("def _build_well_frame_overlay",1)[0]
    assert "track_header_height=max(48,header_height-common_header_height)" in draw
    assert 'track_name,pos=(.5,.82)' in draw
    assert 'curve_label,pos=(.5,.55)' in draw
    assert 'lo_label,pos=(0,.28)' in draw and 'hi_label,pos=(1,.28)' in draw
    assert 'label_text,pos=(position,.08)' in draw


def test_track_names_are_friendly_and_grid_colors_are_explicit():
    from pathlib import Path
    root=Path(__file__).parents[1]
    manager=(root/"hmdcorr/track_manager.py").read_text(encoding="utf-8")
    gpu=(root/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    renderer=(root/"hmdcorr/renderer.py").read_text(encoding="utf-8")
    assert 'visible_name=configured if configured' in manager and 'f"Track {index+1}"' in manager
    assert 'descriptor="Resistividad" if resistive' in manager
    assert 'configured.strip().lower()=="track"' in manager
    assert 'track_name=f"Track {track_index+1}"' in gpu
    assert 'props=dict(props,name=f"Track {ti+1}")' in renderer
    assert 'self.grid_color=self._color_button()' in manager
    assert 'self.grid_minor_color=self._color_button()' in manager
    assert 'self.grid_same_color=QCheckBox("Usar el mismo color para ambas")' in manager
    assert 'self.restore_grid_colors=QPushButton("Restaurar colores recomendados")' in manager
    assert 'hminor_grid_visual=scene.visuals.Line' in gpu
    assert 'props.get("grid_minor_color","#D8DEE8")' in gpu


def test_gpu_grid_never_submits_empty_geometry_and_uses_cache():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    setter=source.split("def _set_segment_visual",1)[1].split("def _update_track_grid",1)[0]
    grid=source.split("def _update_track_grid",1)[1].split("def _update_correlation_lines",1)[0]
    assert "if not enabled or not segments:" in setter
    assert "visual.visible=False;return" in setter
    assert "visual.set_data" in setter and "visual.visible=True" in setter
    assert 'group.get("_grid_signature")==signature' in grid
    assert 'group["_grid_signature"]=signature' in grid
    assert "if len(levels)>64" in grid
    assert "_set_segment_visual" in grid


def test_gpu_cursor_readout_is_local_to_active_track_and_can_be_pinned():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    cursor=source.split("def _update_cursor_readout",1)[1].split("def _track_at",1)[0]
    press=source.split("def _on_mouse_press",1)[1].split("def _on_mouse_release",1)[0]
    assert "QTableWidget" not in source and "cursor_table" not in source
    assert 'lines=[f\'MD {raw_md:g} {depth_unit}\'' in cursor
    assert 'hovered.get("curve_data",{}).items()' in cursor and 'data.get("unit","")' in cursor
    assert "self._control_pressed(event)" in press and "self.cursor_pinned" in press
    assert 'label.anchor_x=' not in cursor and 'label.anchor_y=' not in cursor
    assert 'sample>=len(values)' in cursor and "_safe_update_cursor_readout" in source


def test_gpu_cursor_hit_testing_uses_the_complete_nested_scene_path():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    hit=source.split("def _track_at",1)[1].split("def _set_zoom_mode",1)[0]
    assert 'self.canvas.scene.node_transform(group["track"].scene)' in hit
    assert "point=transform.map(pos)" in hit
    assert 'group["track"].scene.transform.imap' not in hit


def test_gpu_tops_keep_project_style_and_connect_between_wells():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw=source.split("def _draw_project",1)[1].split("def _build_correlation_overlay",1)[0]
    overlay=source.split("def _build_correlation_overlay",1)[1].split("def _on_mouse_move",1)[0]
    assert 'group["top_depths"][name]=y' in draw
    assert "if not project.show_tops:return" in draw
    assert "project.top_colors.get" in draw and "project.effective_top_style(name)" in draw
    assert 'scene.visuals.Text(name' in draw and 'bold=bool(style.get("bold",False))' in draw
    assert 'zip(getattr(self,"well_track_groups",[]),getattr(self,"well_track_groups",[])[1:])' in overlay
    assert 'parent=gap["view"].scene' in overlay
    assert 'points=np.asarray([(0.0,left_depth),(1.0,right_depth)]' in overlay
    assert 'not gap["widget"].visible' in overlay
    assert 'left["track"].scene.node_transform(self.canvas.scene)' not in overlay
    assert 'right["track"].scene.node_transform(self.canvas.scene)' not in overlay
    assert 'record["line"].set_data' in overlay
    assert "line.order=1000" in overlay and "depth_test=False" in overlay


def test_gpu_correlation_overlay_updates_on_camera_and_canvas_changes():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    assert "plot_view.camera.events.transform_change.connect(self._schedule_camera_refresh)" in source
    assert "self._camera_refresh_timer.setInterval(16)" in source
    assert "self.canvas.events.resize.connect(self._on_canvas_resize)" in source
    assert "QTimer.singleShot(0,self._update_correlation_lines)" in source
    assert "QTimer.singleShot(75,self._update_correlation_lines)" in source


def test_gpu_resize_recomputes_overlays_after_vispy_layout_settles():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    init=source.split("def __init__",1)[1].split("def _on_canvas_resize",1)[0]
    resize=source.split("def _on_canvas_resize",1)[1].split("def capture_navigation_state",1)[0]
    assert "self._resize_refresh_timer=QTimer(self)" in init
    assert "self._resize_refresh_timer.setSingleShot(True)" in init
    assert "self._resize_refresh_timer.timeout.connect(self._refresh_overlays_after_resize)" in init
    assert "QTimer.singleShot(0,self._refresh_overlays_after_resize)" in resize
    assert "self._resize_refresh_timer.start(80)" in resize
    assert "def _refresh_overlays_after_resize" in resize
    assert "self.canvas.update()" in resize
    assert "self._update_correlation_lines()" in resize


def test_gpu_colored_geologic_correlation_toggle_contract():
    from pathlib import Path
    root=Path(__file__).parents[1]
    source=(root/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    icon=(root/"hmdcorr/rendering/icons/geologic-correlation.svg").read_text(encoding="utf-8")
    assert '_tool_button("geologic-correlation","Mostrar/ocultar líneas de correlación (L)",True)' in source
    assert "self.project.show_correlation_lines=visible" in source
    assert 'if not self.project.show_correlation_lines:' in source
    assert 'QKeySequence("L")' in source
    assert "#D9C63B" in icon and "#5AA45F" in icon


def test_gpu_interval_and_area_zoom_contract():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    for method in ("_set_zoom_mode","_on_mouse_press","_on_mouse_release","_apply_interval_zoom","_apply_area_zoom","_reset_gpu_zoom"):
        assert f"def {method}" in source
    assert '_tool_button("zoom-interval","Zoom por intervalo (I)",True)' in source
    assert '_tool_button("zoom-area","Zoom areal (A)",True)' in source
    assert "self.zoom_button_group.setExclusive(True)" in source
    assert "scene.visuals.Rectangle" in source and "zoom_selection.visible=False" in source
    assert 'event.button==3' in source and '*.35' in source
    area=source.split("def _apply_area_zoom",1)[1].split("def _reset_gpu_zoom",1)[0]
    assert 'group["grid"].visible=active' in area
    assert 'self._set_exact_camera_rect(group["track"].camera,low,high)' in area
    interval=source.split("def _apply_interval_zoom",1)[1].split("def _apply_area_zoom",1)[0]
    assert 'self._set_exact_camera_rect(group["track"].camera,low,high)' in interval


def test_gpu_area_zoom_collapses_unused_layout_and_fills_the_canvas():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw=source.split("def _draw_project",1)[1].split("def _build_well_frame_overlay",1)[0]
    area=source.split("def _apply_area_zoom",1)[1].split("def _reset_gpu_zoom",1)[0]
    reset=source.split("def _reset_gpu_zoom",1)[1].split("def _on_mouse_move",1)[0]
    assert "self.area_layout_items=[]" in draw
    assert '"kind":"gap"' in draw and '"kind":"well"' in draw
    assert "minimum_overlap=max(3.0,(right-left)*.02)" in area
    assert "focus_fraction=.94" in area and "1.0/focus_fraction-1.0" in area
    assert 'self._set_exact_camera_rect(group["track"].camera,low,high)' in area
    assert 'area_x_range' not in area
    assert 'self._area_focus_state={"selected_ids":selected_ids' in area
    assert "widget.width_min=0;widget.width_max=0;widget.stretch=(.001,1)" in area
    assert "self._area_focus_active=True" in area
    geometry=source.split("def _refresh_area_focus_geometry",1)[1].split("def _reset_gpu_zoom",1)[0]
    assert "focus_width=canvas_width*.94" in geometry
    assert "self.root_grid.margin=max(4.0,canvas_width*.03)" in geometry
    assert "group[\"grid\"].width_min=assigned;group[\"grid\"].width_max=assigned" in geometry
    assert 'item["widget"].width_min=assigned' not in geometry
    assert 'getattr(layout,"_recreate_solver",None)' in geometry
    assert 'getattr(layout,"_update_child_widget_dim",None)' in geometry
    assert 'if item["kind"]=="gap":widget.width_min=item.get("base_width_min",44)' in reset
    assert 'group["grid"].width_min=int(group.get("base_width_min",0))' in reset
    assert "self.root_grid.margin=4" in reset
    assert "self._area_focus_active=False" in reset
    assert "self._area_focus_state=None" in reset
    assert "self._refresh_full_layout_geometry()" in reset
    assert "QTimer.singleShot(80,self._refresh_full_layout_geometry)" in reset
    full=source.split("def _refresh_full_layout_geometry",1)[1].split("def _on_mouse_move",1)[0]
    assert 'self._resolve_grid_geometry()' in full
    resolver=source.split("def _resolve_grid_geometry",1)[1].split("def _open_track_grid_configuration",1)[0]
    assert 'layouts=[getattr(self,"root_grid",None)]' in resolver
    assert 'layouts.extend(item["widget"]' in resolver
    assert 'layouts.extend(group["grid"]' in resolver
    assert 'getattr(layout,"_recreate_solver",None)' in resolver


def test_gpu_layout_has_no_nested_grids_or_unsupported_viewbox_attributes():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw=source.split("def _draw_project",1)[1].split("def _build_well_frame_overlay",1)[0]
    assert '.add_grid(' not in draw.split('grid=self.canvas.central_widget.add_grid',1)[1]
    assert 'gap_header=grid.add_view(row=0,col=root_column,row_span=2' in draw
    gap_line=next(line for line in draw.splitlines() if 'gap_header=grid.add_view' in line)
    assert 'gap_header.height_min' not in gap_line and 'gap_header.height_max' not in gap_line
    assert 'well_header_view=grid.add_view(row=0,col=root_column,col_span=len(well_tracks)' in draw
    assert '.clip_method=' not in draw


def test_gpu_overlays_ignore_stale_top_names_and_refresh_recovers_in_place():
    from pathlib import Path
    root=Path(__file__).parents[1]
    gpu=(root/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    window=(root/"hmdcorr/main_window.py").read_text(encoding="utf-8")
    update=gpu.split("def _update_correlation_lines",1)[1].split("def _set_top_edit_enabled",1)[0]
    refresh=window.split("def _refresh_gpu_canvas",1)[1].split("def _apply_render_backend",1)[0]
    assert update.count('name not in left.get("top_depths",{}) or name not in right.get("top_depths",{})')==1
    assert 'name not in group.get("top_depths",{})' in update
    assert 'except (AttributeError,IndexError,KeyError,TypeError,ValueError,RuntimeError):' in refresh
    assert 'self.gpu_canvas._rebuild_scene(self.project,self.datum_combo.currentData());mode="scene"' in refresh


def test_gpu_zoom_shortcuts_and_wheel_navigation_contract():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    assert "self.canvas.events.mouse_wheel.connect(self._on_mouse_wheel)" in source
    assert "self.canvas.events.key_press.connect(self._on_key_press)" in source
    key=source.split("def _on_key_press",1)[1].split("def _apply_interval_zoom",1)[0]
    assert 'key=="I"' in key and 'key=="A"' in key and 'key=="R"' in key
    motion=source.split("def _on_mouse_move",1)[1]
    assert 'visual_start[0]=float(inverse.map((0,depth))[0])' in motion
    assert 'visual_end[0]=float(inverse.map((1,depth))[0])' in motion


def test_gpu_vertical_navigation_preserves_track_horizontal_edges():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    wheel=source.split("def _on_mouse_wheel",1)[1].split("def _on_key_press",1)[0]
    interval=source.split("def _apply_interval_zoom",1)[1].split("def _apply_area_zoom",1)[0]
    motion=source.split("def _on_mouse_move",1)[1]
    assert 'self._set_exact_camera_rect(group["track"].camera,new_low,new_high)' in wheel
    assert 'self._set_exact_camera_rect(group["track"].camera,low,high)' in interval
    assert 'self._set_exact_camera_rect(group["track"].camera,low+delta,high+delta)' in motion


def test_gpu_well_name_spans_all_tracks_without_duplication():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw=source.split("def _draw_project",1)[1].split("def _build_correlation_overlay",1)[0]
    assert 'well_header_view=grid.add_view(row=0,col=root_column,col_span=len(well_tracks)' in draw
    assert 'scene.visuals.Text(project.well_header_label(well)' in draw
    assert draw.count('scene.visuals.Text(project.well_header_label(well)')==1
    assert 'track_grid=well_grid.add_grid(row=1,col=track_index' not in draw
    assert "track_header_height=max(48,header_height-common_header_height)" in draw


def test_gpu_track_bodies_use_only_local_borders_without_global_frame():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw=source.split("def _draw_project",1)[1].split("def _build_correlation_overlay",1)[0]
    update=source.split("def _update_correlation_lines",1)[1].split("def _set_top_edit_enabled",1)[0]
    assert 'is_first_track=track_index==0;is_last_track=track_index==len(well_tracks)-1' in draw
    assert 'border_visual=scene.visuals.Line' in draw and 'color="#9CA3AF"' in draw
    assert '"is_first_track":is_first_track,"is_last_track":is_last_track' in draw
    assert "def _build_well_frame_overlay" not in source
    assert "well_frame_overlays" not in source
    assert 'parent=plot_view.scene' in draw
    assert 'border_segments.extend' not in update


def test_gpu_curve_scale_limits_are_continuous_and_header_ticks_align():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw=source.split("def _draw_project",1)[1].split("def _build_well_top_overlay",1)[0]
    update=source.split("def _update_correlation_lines",1)[1].split('for record in getattr(self,"well_top_overlays"',1)[0]
    assert 'scale_limit_visual=scene.visuals.Line' in draw
    assert '"scale_limit_visual":scale_limit_visual' in draw
    assert '_append_grid_segment(scale_limits,(0.0,low),(0.0,high),"solid")' in update
    assert '_append_grid_segment(scale_limits,(1.0,low),(1.0,high),"solid")' in update
    assert 'group["scale_limit_visual"].visible=bool(props.get("border_visible",True))' in update
    assert '"header_tick_visual":header_tick_visual' in draw
    assert 'tick_segments=[(0.0,0.0),(0.0,.14),(1.0,0.0),(1.0,.14)]' in update
    assert 'group["header_tick_visual"].set_data' in update


def test_gpu_track_separator_is_stronger_only_between_adjacent_tracks():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw=source.split("def _draw_project",1)[1].split("def _build_well_top_overlay",1)[0]
    update=source.split("def _update_correlation_lines",1)[1].split('for record in getattr(self,"well_top_overlays"',1)[0]
    assert 'separator_visual=scene.visuals.Line' in draw
    assert 'width=max(1.4,float(props.get("border_width",.7))*1.8)' in draw
    assert 'separator_visual.visible=not is_last_track' in draw
    assert 'group["separator_visual"].set_data' in update


def test_gpu_tops_are_local_per_track_with_one_label_per_well():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw=source.split("def _draw_project",1)[1].split("def _build_well_top_overlay",1)[0]
    builder=source.split("def _build_well_top_overlay",1)[1].split("def _build_correlation_overlay",1)[0]
    update=source.split("def _update_correlation_lines",1)[1].split("def _set_top_edit_enabled",1)[0]
    assert "top_line=scene.visuals.Line" not in draw and "top_label=scene.visuals.Text" not in draw
    assert 'parent=group["track"].scene' in builder
    assert 'if track_index==len(tracks)-1:' in builder
    assert 'self.well_top_overlays.append({"line":line,"label":label,"group":group' in builder
    assert '[(0.0,depth),(1.0,depth)]' in update
    assert 'label.pos=(.985,depth);label.visible=True' in update


def test_gpu_zoom_has_window_level_qt_shortcuts_independent_of_focus():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    init=source.split("def __init__",1)[1].split("def _draw_project",1)[0]
    for key in ("I","A","R"):assert f'QShortcut(QKeySequence("{key}"),self)' in init
    assert init.count("setContext(Qt.WindowShortcut)")>=3
    assert "self.canvas.native.setFocusPolicy(Qt.StrongFocus)" in init
    assert "QTimer.singleShot(0,self.canvas.native.setFocus)" in init


def test_gpu_top_edit_and_assisted_ghost_contract():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    for method in ("_nearest_top","_move_top_visual","_configure_assisted_correlation","_move_ghost",
                   "_commit_assisted_correlation","_cancel_assisted_correlation"):
        assert f"def {method}" in source
    assert "project.adjust_top" in source and '"gpu_cursor_adjustment"' in source
    assert "self.project.transfer_top" in source
    assert "self.ghost_line" in source and "EN TRÁNSITO" in source and "ORIGEN" in source
    assert 'QShortcut(QKeySequence("E"),self)' in source
    assert 'QShortcut(QKeySequence("C"),self)' in source
    assert 'QShortcut(QKeySequence("Esc"),self)' in source


def test_gpu_interpretation_syncs_back_to_main_project():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/main_window.py").read_text(encoding="utf-8")
    block=source.split("def _open_vispy_preview",1)[1].split("def _show_about",1)[0]
    assert "if dialog.project_changed" in block
    assert 'self._sync_geodata("gpu_interpretation")' in block
    assert "self._refresh_controls()" in block


def test_main_window_has_persistent_selectable_render_backend():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/main_window.py").read_text(encoding="utf-8")
    assert 'self.settings.value("rendering/backend","vispy")' in source
    assert "QStackedWidget" in source and "self.render_stack.addWidget(self.canvas)" in source
    assert "def _apply_render_backend" in source and "def _refresh_gpu_canvas" in source
    assert 'embedded=True,change_callback=self._gpu_project_changed' in source
    assert '("VisPy / OpenGL · principal","vispy")' in source
    assert '("Matplotlib · compatibilidad","matplotlib")' in source
    refresh=source.split("def refresh_plot",1)[1].split("def _set_zoom_mode",1)[0]
    assert 'if self.render_backend=="vispy":self._refresh_gpu_canvas()' in refresh


def test_temporary_gpu_fallback_does_not_replace_user_preference_or_icons():
    from pathlib import Path
    root=Path(__file__).parents[1]
    source=(root/"hmdcorr/main_window.py").read_text(encoding="utf-8")
    init=source.split("def __init__",1)[1].split("def _build_ui",1)[0]
    refresh=source.split("def _refresh_gpu_canvas",1)[1].split("def _apply_render_backend",1)[0]
    apply=source.split("def _apply_render_backend",1)[1].split("def _open_vispy_preview",1)[0]
    assert 'stored_backend=="matplotlib" and backend_origin!="user"' in init
    assert 'self.settings.setValue("rendering/backend_origin","fallback")' in refresh
    assert 'self.settings.setValue("rendering/backend","matplotlib")' not in refresh
    assert 'def _apply_render_backend(self,backend,initial=False,persist=True)' in source
    assert 'if persist:' in apply and 'self.settings.setValue("rendering/backend",requested)' in apply
    for icon in ("zoom-area.svg","zoom-interval.svg","reset-view.svg","edit-tops.svg",
                 "assisted-correlation.svg","geologic-correlation.svg","configure-grid.svg"):
        assert (root/"hmdcorr/rendering/icons"/icon).is_file()


def test_embedded_gpu_uses_main_shortcuts_and_keeps_escape_local():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    assert "if not self.embedded:" in source
    assert 'QShortcut(QKeySequence("Esc"),self)' in source
    assert "Qt.WidgetWithChildrenShortcut if self.embedded else Qt.WindowShortcut" in source


def test_gpu_log_header_hides_only_labels_that_overlap_at_current_width():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    draw=source.split("def _draw_project",1)[1].split("def _build_well_top_overlay",1)[0]
    method=source.split("def _update_grid_header_labels",1)[1].split("def _update_correlation_lines",1)[0]
    update=source.split("def _update_correlation_lines",1)[1].split("def _set_top_edit_enabled",1)[0]
    assert '"grid_header_labels":grid_header_labels' in draw
    assert "width=abs(x1-x0)" in method
    assert "occupied=[" in method
    assert 'record["visual"].visible=visible' in method
    assert "if visible:occupied.append(interval)" in method
    assert "self._update_grid_header_labels(group)" in update
    # El control de colisiones actúa sólo sobre textos; las líneas conservan su geometría.
    assert "vgrid_visual" not in method and "vminor_grid_visual" not in method


def test_main_window_reuses_one_gpu_canvas_instead_of_recreating_it():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/main_window.py").read_text(encoding="utf-8")
    refresh=source.split("def _refresh_gpu_canvas",1)[1].split("def _apply_render_backend",1)[0]
    assert "if self.gpu_canvas is not None:" in refresh
    assert "self.gpu_canvas.refresh_project(self.project,self.datum_combo.currentData())" in refresh
    assert "previous=self.gpu_canvas" not in refresh
    assert "previous.canvas.close()" not in refresh
    assert refresh.count("VisPyCorrelationDialog(")==1


def test_gpu_persistent_scene_has_incremental_and_structural_refresh_paths():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/rendering/vispy_canvas.py").read_text(encoding="utf-8")
    refresh=source.split("def refresh_project",1)[1].split("def _update_overlay_styles",1)[0]
    rebuild=source.split("def _rebuild_scene",1)[1].split("def refresh_project",1)[0]
    signature=source.split("def _scene_structure_signature",1)[1].split("def _append_grid_segment",1)[0]
    assert "curve_overrides" not in signature and "top_colors" not in signature and "top_styles" not in signature
    assert 'if signature!=getattr(self,"_structure_signature",None)' in refresh
    assert "self._rebuild_scene(project,datum_top)" in refresh
    assert 'mode="incremental"' in refresh and "self.incremental_updates+=1" in refresh
    assert 'group["curve_visuals"].items()' in refresh
    assert "_normalized_curve_position" in refresh and "_update_overlay_styles()" in refresh
    assert '_curve_render_signature(well,source,settings)' in refresh
    assert 'group["curve_signatures"].get(source)!=curve_signature' in refresh
    assert 'group.get("_grid_config_signature")!=grid_signature' in refresh
    assert "self.full_scene_rebuilds+=1" in rebuild
    assert "self.canvas.close()" not in rebuild
    assert "self.last_refresh_ms" in refresh
