from pathlib import Path

import numpy as np

from hmdcorr.coordinates import (coordinate_data_from_values,haversine_meters,
                                 is_valid_geographic,parse_geographic_coordinate,
                                 LATITUDE_KEYS,LONGITUDE_KEYS)
from hmdcorr.geodata_repository import GeoDataRepository
from hmdcorr.models import CorrelationProject,Well
from hmdcorr.project_io import load_project,save_project
from hmdcorr.importers import _las_raw


ROOT=Path(__file__).resolve().parents[1]


def test_coordinate_parser_accepts_decimal_dms_and_hemisphere():
    assert parse_geographic_coordinate("31.75 N","latitude")[0]==31.75
    assert parse_geographic_coordinate("102° 30' 0\" W","longitude")[0]==-102.5
    data=coordinate_data_from_values("31°45'0N","102°30'0W",latitude_field="LAT",longitude_field="LOG",source_file="well.las")
    assert is_valid_geographic(data) and data["crs"]=="EPSG:4326" and data["source_fields"]==["LOG","LAT"]


def test_standard_las_lati_long_pair_is_recognized():
    assert "LATI" in LATITUDE_KEYS and "LONG" in LONGITUDE_KEYS
    data=coordinate_data_from_values("41.310000","-104.15000",latitude_field="LATI",longitude_field="LONG",source_file="wyoming.las")
    assert is_valid_geographic(data)
    assert data["latitude"]==41.31 and data["longitude"]==-104.15
    assert data["source_fields"]==["LONG","LATI"]


def test_las_header_lookup_reads_exact_lati_long_mnemonics():
    class Item:
        def __init__(self,value):self.value=value
    class FakeLas:
        well={"LATI":Item(41.310000),"LONG":Item(-104.15000)}
        params={}
    latitude,lat_field=_las_raw(FakeLas(),LATITUDE_KEYS);longitude,lon_field=_las_raw(FakeLas(),LONGITUDE_KEYS)
    assert (latitude,lat_field,longitude,lon_field)==(41.31,"LATI",-104.15,"LONG")


def test_project_and_database_preserve_coordinate_provenance(tmp_path):
    data=coordinate_data_from_values(31.75,-102.5,latitude_field="LAT",longitude_field="LONG",source_file="a.las")
    well=Well("A","UWI-A",np.array([1.]),{"GR":np.array([50.])},x=-102.5,y=31.75,coordinate_data=data)
    project=CorrelationProject(name="Mapa",wells=[well]);path=tmp_path/"map.hmdcorr";save_project(path,project)
    loaded=load_project(path);assert loaded.wells[0].coordinate_data["source_file"]=="a.las"
    repository=GeoDataRepository(tmp_path/"geo.db");repository.sync_project(loaded)
    stored=repository.coordinate_for_uwi("UWI-A")
    assert stored["latitude"]==31.75 and stored["longitude"]==-102.5 and stored["validation_status"]=="valid"


def test_haversine_returns_real_geographic_distance():
    first={"latitude":0.,"longitude":0.};second={"latitude":0.,"longitude":1.}
    assert 111000<haversine_meters(first,second)<112000


def test_map_is_a_separate_popup_and_project_owns_crs_tools():
    window=(ROOT/"hmdcorr"/"main_window.py").read_text(encoding="utf-8")
    map_source=(ROOT/"hmdcorr"/"well_map.py").read_text(encoding="utf-8")
    assert '"Mapa de pozos…"' in window and 'bar.addMenu("Proyecto")' in window
    assert '"Administrador de proyecto…"' in window
    menu_block=window[window.index('wells_menu=bar.addMenu("Pozos")'):window.index('tracks_menu=bar.addMenu("Tracks y curvas")')]
    assert '"Administrar coordenadas…"' not in menu_block
    assert "window.show()" in window and "class WellMapDialog(QDialog)" in map_source
    assert "marker=\"o\"" in map_source and "well.name" in map_source
