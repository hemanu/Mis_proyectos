import numpy as np

from hmdcorr.models import CorrelationProject,Well
from hmdcorr.project_io import save_project,load_project


def test_map_labels_persist_with_project(tmp_path):
    well=Well("A","1",np.array([1.]),{"GR":np.array([10.])})
    label={"id":"label-1","text":"Área norte","position_wgs84":[-104.15,41.31],"font_size":10,"color":"#111827"}
    project=CorrelationProject(wells=[well],map_labels=[label])
    path=tmp_path/"map-labels.hmdcorr";save_project(path,project);restored=load_project(path)
    assert restored.map_labels==[label]


def test_map_toolbar_and_section_save_contract():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/well_map.py").read_text(encoding="utf-8")
    for text in ("Guardar sección","Configurar área","Agregar etiqueta","Exportar imagen","_save_pending_line","position_wgs84","Mover con el cursor"):
        assert text in source
    finish=source.split("def _finish_polyline",1)[1].split("def _save_pending_line",1)[0]
    save=source.split("def _save_pending_line",1)[1].split("def _configure_area",1)[0]
    assert "self._pending_line=line" in finish
    assert "self.section_lines.append(line)" not in finish
    assert "self.section_lines.append(line)" in save


def test_double_click_freezes_trace_before_review():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/well_map.py").read_text(encoding="utf-8")
    click=source.split("def _on_click",1)[1].split("def _on_key",1)[0]
    finish=source.split("def _finish_polyline",1)[1].split("def _save_pending_line",1)[0]
    assert 'getattr(event,"dblclick",False)' in click
    assert "self._finish_polyline();return" in click
    assert "self._drawing=False" in finish
    assert finish.index("self._drawing=False") < finish.index("SectionReviewDialog")
    assert "vertices=list(self._vertices)" in finish and '"vertices":[list(point) for point in vertices]' in finish


def test_pending_line_is_identified_and_applied_order_is_explicit(tmp_path):
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/well_map.py").read_text(encoding="utf-8")
    renderer=(Path(__file__).parents[1]/"hmdcorr/renderer.py").read_text(encoding="utf-8")
    assert 'QPushButton("Trazar línea")' in source
    assert '"__pending__"' in source and "[Sin guardar]" in source and "Guarde primero la sección" in source
    assert 'line.get("label_start","A")' in source and 'line.get("label_end","A′")' in source
    assert "active_section_well_order=[str(w.uwi) for w in ordered]" in source
    assert "project.active_section_well_order" in renderer
    project=CorrelationProject(active_section_line_id="L1",active_section_well_order=["U2","U1"])
    path=tmp_path/"order.hmdcorr";save_project(path,project);restored=load_project(path)
    assert restored.active_section_line_id=="L1" and restored.active_section_well_order==["U2","U1"]
