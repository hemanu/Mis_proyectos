from pathlib import Path
import sqlite3

import numpy as np

from hmdcorr.geodata_repository import GeoDataRepository
from hmdcorr.models import CorrelationProject,Well
from hmdcorr.project_io import load_project,save_project


def sample_well(name="Pozo A",uwi="A"):
    return Well(name,uwi,np.asarray([1000.0,1001.0]),{"GR":np.asarray([50.0,60.0])},
                coordinate_data={"latitude":41.31,"longitude":-104.15,"crs":"EPSG:4326","validation_status":"valid"})


def test_visibility_is_independent_and_new_wells_default_visible():
    project=CorrelationProject(wells=[sample_well()])
    project.toggle_well_in_section("A")
    assert not project.well_visible_in_section("A")
    assert project.well_visible_on_map("A")
    project.toggle_well_on_map("A")
    assert not project.well_visible_on_map("A")
    project.add_or_replace_wells([sample_well("Pozo B","B")])
    assert project.well_visible_in_section("B") and project.well_visible_on_map("B")


def test_visibility_roundtrip_in_project_file(tmp_path):
    project=CorrelationProject(wells=[sample_well()]);project.toggle_well_in_section("A");project.toggle_well_on_map("A")
    path=tmp_path/"visibility.hmdcorr";save_project(str(path),project);loaded=load_project(str(path))
    assert loaded.hidden_section_wells=={"A"}
    assert loaded.hidden_map_wells=={"A"}


def test_visibility_is_persisted_in_sqlite(tmp_path):
    repository=GeoDataRepository(tmp_path/"geodata.sqlite")
    project=CorrelationProject(wells=[sample_well()]);project.toggle_well_in_section("A")
    repository.sync_project(project,reason="visibility_test")
    with sqlite3.connect(repository.path) as db:
        row=db.execute("SELECT show_in_section,show_on_map FROM project_wells WHERE project_id=? AND uwi='A'",(project.project_id,)).fetchone()
    assert row==(0,1)


def test_ui_contract_exposes_separate_section_and_map_controls():
    root=Path(__file__).parents[1]
    manager=(root/"hmdcorr"/"well_manager.py").read_text(encoding="utf-8")
    main=(root/"hmdcorr"/"main_window.py").read_text(encoding="utf-8")
    map_source=(root/"hmdcorr"/"well_map.py").read_text(encoding="utf-8")
    renderer=(root/"hmdcorr"/"renderer.py").read_text(encoding="utf-8")
    assert "Ocultar de sección" in manager and "Ocultar del mapa" in manager
    assert "Mostrar en sección" in manager and "Mostrar en mapa" in manager
    assert 'self.tabs.addTab(page,"Sección")' in manager and 'self.tabs.addTab(page,"Mapa")' in manager
    assert '"En sección"' in manager and '"En mapa"' in manager
    assert "project.well_visible_on_map(well.uwi)" in main
    assert "def update_wells" in map_source
    assert "project.well_visible_in_section(well.uwi)" in renderer
