from pathlib import Path

import numpy as np

from hmdcorr.coordinates import coordinate_data_from_values
from hmdcorr.geodata_repository import GeoDataRepository
from hmdcorr.models import CorrelationProject,Well
from hmdcorr.project_io import load_project,save_project


ROOT=Path(__file__).resolve().parents[1]


def test_manual_well_catalog_crud_and_metadata(tmp_path):
    repository=GeoDataRepository(tmp_path/"geo.db")
    coordinate=coordinate_data_from_values(41.31,-104.15,latitude_field="LATI",longitude_field="LONG",source_file="wells.csv")
    assert repository.upsert_well_record({"uwi":"UWI-1","name":"Pozo Uno","coordinate_data":coordinate,
        "reference_elevation":1450.,"metadata":{"operator":"HMD","field":"Norte","status":"Planeado","notes":"Sin LAS"}})=="created"
    record=repository.well_record("UWI-1")
    assert record["metadata"]["field"]=="Norte" and record["latitude"]==41.31
    assert repository.upsert_well_record({"uwi":"UWI-1","name":"Pozo Uno A","metadata":{"status":"Activo"}})=="updated"
    assert repository.well_record("UWI-1")["metadata"]["operator"]=="HMD"
    repository.delete_well("UWI-1");assert repository.well_record("UWI-1") is None


def test_metadata_only_well_is_portable_and_has_no_log_data(tmp_path):
    well=Well("Pozo futuro","UWI-F",np.asarray([],float),{},well_metadata={"operator":"HMD"})
    project=CorrelationProject(name="Lista",wells=[well]);path=tmp_path/"list.hmdcorr";save_project(path,project);loaded=load_project(path)
    assert loaded.wells[0].has_log_data is False and loaded.wells[0].well_metadata["operator"]=="HMD"


def test_well_manager_replaces_old_repository_command_and_supports_import_mapping():
    main=(ROOT/"hmdcorr"/"main_window.py").read_text(encoding="utf-8")
    manager=(ROOT/"hmdcorr"/"well_manager.py").read_text(encoding="utf-8")
    assert '"Administrador de proyecto…"' in main and '"Administrador de pozos…"' not in main
    for label in ("Datos generales","Referencia espacial","Sección","Mapa","Pozos del proyecto","Importar datos","Asignar columnas de importación"):
        assert label in manager
    for extension in (".xlsx",".xls",".csv"):
        assert extension in manager
