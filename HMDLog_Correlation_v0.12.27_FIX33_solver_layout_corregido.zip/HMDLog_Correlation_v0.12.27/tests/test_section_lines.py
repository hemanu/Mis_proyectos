from pathlib import Path
import numpy as np

from hmdcorr.models import CorrelationProject,Well
from hmdcorr.project_io import load_project,save_project
from hmdcorr.section_geometry import default_section_labels,project_point_to_polyline,project_point_to_section


ROOT=Path(__file__).resolve().parents[1]


def test_point_projection_returns_lateral_and_along_distance():
    result=project_point_to_section((5,2),(0,0),(10,0),"projected","metres")
    assert result["inside_segment"] is True and result["fraction"]==.5
    assert abs(result["along_km"]-.005)<1e-9 and abs(result["lateral_km"]-.002)<1e-9


def test_section_name_accepts_letters_numbers_and_can_generate_end_labels():
    assert default_section_labels("A")==("A","A′")
    assert default_section_labels("1-1′")==("1","1′")
    assert default_section_labels("Regional A2")==("Regional A2","Regional A2′")


def test_polyline_projection_uses_nearest_segment_and_cumulative_station():
    result=project_point_to_polyline((10,5),[(0,0),(10,0),(10,10)],"projected","metres")
    assert result["segment_index"]==1 and abs(result["lateral_km"])<1e-12
    assert abs(result["along_km"]-.015)<1e-9 and abs(result["total_length_km"]-.020)<1e-9


def test_section_lines_are_persistent_in_project(tmp_path):
    well=Well("Pozo","U1",np.asarray([1.]),{"GR":np.asarray([10.])})
    line={"id":"line-1","name":"Sección A-A′","start":[0,0],"end":[10,0],"crs":"EPSG:4326",
        "wells":[{"uwi":"U1","mode":"direct","included":True,"along_km":1.0,"lateral_km":0.0,"fraction":.5}]}
    project=CorrelationProject(wells=[well],section_lines=[line],active_section_line_id="line-1");path=tmp_path/"section.hmdcorr"
    save_project(path,project);restored=load_project(path)
    assert restored.section_lines[0]["name"]=="Sección A-A′" and restored.active_section_line_id=="line-1"


def test_map_ui_supports_draw_touch_projection_rename_and_apply():
    source=(ROOT/"hmdcorr"/"well_map.py").read_text(encoding="utf-8")
    for text in ("Trazar línea","Mixto: pozos y vértices libres","Agregar/quitar pozos","Proyectar hasta","Renombrar…","Aplicar a correlación","Tocado","Proyectado"):
        assert text in source
    assert "_well_at_pixel" in source and "project_point_to_polyline" in source
    assert "_draw_candidate_preview" in source and '"#16A34A"' in source and '"#F59E0B"' in source
    assert '"start_wgs84"' in source and '"end_wgs84"' in source and "transform_xy" in source
    assert '"vertices"' in source and '"vertices_wgs84"' in source and '"vertex_uwis"' in source
    assert "_recalculate_line_members" in source and '"manual_excluded"' in source
    assert "hidden_section_wells" in source and "active_section_line_id" in source
