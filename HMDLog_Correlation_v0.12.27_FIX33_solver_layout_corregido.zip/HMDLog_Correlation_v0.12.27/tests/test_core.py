from hmdcorr.demo import create_demo_project


def test_demo_project_contains_five_wells():
    project = create_demo_project()
    assert len(project.wells) == 5
    assert project.common_curves == ["GR", "ILD", "ILM", "LITHOLOGY", "SFL", "SP"]
    assert project.top_names == ["Fm. Alfa", "Fm. Beta", "Fm. Gamma"]


def test_datum_top_exists_in_demo_wells():
    project = create_demo_project()
    for well in project.wells:
        assert "Fm. Beta" in well.tops


def test_global_and_well_scale_overrides():
    project = create_demo_project()
    project.set_curve_override("GR", {"xlim": [0, 200]}, None)
    project.set_curve_override("GR", {"xlim": [10, 100]}, "DEMO-002")
    assert project.effective_curve_settings("DEMO-001", "GR")["xlim"] == [0, 200]
    assert project.effective_curve_settings("DEMO-002", "GR")["xlim"] == [10, 100]


def test_visibility_is_reversible():
    project = create_demo_project()
    project.toggle_curve("GR")
    assert not project.curve_visible("GR")
    project.toggle_curve("GR")
    assert project.curve_visible("GR")
    key = project.viewer_template["tracks"][0]["key"]
    project.toggle_track(key)
    assert not project.track_visible(key)
    project.toggle_track(key)
    assert project.track_visible(key)


def test_demo_has_hmdlog_lithology_curve():
    project = create_demo_project()
    assert all(project.lithology_mnemonic(well) == "LITHOLOGY" for well in project.wells)


def test_common_datum_requires_top_in_every_well():
    project = create_demo_project()
    assert project.common_top_names == ["Fm. Alfa", "Fm. Beta", "Fm. Gamma"]
    project.wells[-1].tops.pop("Fm. Beta")
    assert "Fm. Beta" not in project.common_top_names


def test_correlation_edge_is_independent_of_curve_scale():
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from hmdcorr.renderer import _figure_point
    figure = Figure(figsize=(4, 3))
    FigureCanvasAgg(figure)
    axis = figure.add_subplot(111)
    axis.set_xlim(0, 150)
    axis.set_ylim(100, 0)
    figure.canvas.draw()
    right, _ = _figure_point(figure, axis, 1, 50)
    expected = axis.get_position().x1
    assert abs(right - expected) < 1e-10


def test_header_shrinks_when_fewer_curves_are_visible():
    from hmdcorr.renderer import _header_fraction
    project = create_demo_project()
    extra = dict(project.viewer_template["curves"][0])
    extra.update(source="SP", color="#2563EB")
    project.viewer_template["curves"].append(extra)
    tracks = project.visible_tracks()
    full = _header_fraction(project, project.wells, tracks)
    project.hidden_curves.add("SP")
    compact = _header_fraction(project, project.wells, tracks)
    assert compact < full


def test_project_roundtrip_preserves_interface_state(tmp_path):
    from hmdcorr.project_io import load_project, save_project
    project = create_demo_project()
    project.datum_top = "Fm. Beta"
    project.show_tops = False
    project.show_correlation_lines = False
    project.correlation_linewidth = 1.7
    project.top_colors["Fm. Alfa"] = "#123456"
    project.viewer_template.setdefault("viewer", {})["workspace_background"] = "#eeeeee"
    target = tmp_path / "demo.hmdcorr"
    save_project(target, project)
    restored = load_project(target)
    assert restored.datum_top == "Fm. Beta"
    assert restored.show_tops is False
    assert restored.show_correlation_lines is False
    assert restored.correlation_linewidth == 1.7
    assert restored.top_colors["Fm. Alfa"] == "#123456"
    assert restored.viewer_template["viewer"]["workspace_background"] == "#eeeeee"
    assert len(restored.wells) == 5


def test_minimal_menu_contract():
    from pathlib import Path
    source = (Path(__file__).parents[1] / "hmdcorr" / "main_window.py").read_text(encoding="utf-8")
    for menu in ("Proyecto", "Pozos", "Tracks y curvas", "Correlación", "Plantillas", "Apariencia", "Ayuda"):
        assert f'addMenu("{menu}")' in source
    assert 'addMenu("Escalas")' not in source
    assert "toolbar.addWidget" not in source
    assert "self.well_dock.hide()" in source
    assert "self.context_dock.hide()" in source


def test_legacy_scale_menu_and_panel_are_fully_replaced_by_track_configurator():
    from pathlib import Path
    root=Path(__file__).parents[1]
    window=(root/"hmdcorr"/"main_window.py").read_text(encoding="utf-8")
    manager=(root/"hmdcorr"/"track_manager.py").read_text(encoding="utf-8")
    for legacy in ('addMenu("Escalas")','addTab(scale_page, "Escalas")',
                   "def _load_scale_controls", "def _scale_payload",
                   "def _apply_scale", "def _restore_scale"):
        assert legacy not in window
    assert 'self._action(tracks_menu,"Configurar tracks y retícula…"' in window
    assert 'self._add_scroll_tab(page,"Curvas y escalas")' in manager
    assert 'self.curve_scale.addItem("Lineal","linear")' in manager
    assert 'self.curve_scale.addItem("Logarítmica","log")' in manager
    assert "self.curve_min" in manager and "self.curve_max" in manager
    assert 'self.scope.addItem("Solo este track y pozo","well")' in manager
    assert 'QPushButton("Restaurar valores recomendados")' in manager


def test_any_available_curve_can_be_assigned_to_any_track():
    project = create_demo_project()
    project.viewer_template["tracks"].append({"key": "TRACK_002", "width": 1.0})
    assert "SP" in project.available_curves
    assert not project.track_has_curve("TRACK_002", "SP")
    project.assign_curve_to_track("TRACK_002", "SP")
    assert project.track_has_curve("TRACK_002", "SP")
    assert project.effective_curve_settings("DEMO-001", "SP", "TRACK_002")["source"] == "SP"
    project.assign_curve_to_track("TRACK_001", "SP")
    assert project.track_has_curve("TRACK_001", "SP")
    project.remove_curve_from_track("TRACK_002", "SP")
    assert not project.track_has_curve("TRACK_002", "SP")
    assert project.track_has_curve("TRACK_001", "SP")


def test_mirror_presentation_is_independent_for_each_track():
    project = create_demo_project()
    project.viewer_template["tracks"].append({"key": "TRACK_002", "width": 1.0})
    project.assign_curve_to_track("TRACK_002", "GR")
    project.set_curve_presentation("TRACK_001", "GR", "normal")
    project.set_curve_presentation("TRACK_002", "GR", "axis_inverted")
    assert project.effective_curve_settings("DEMO-001", "GR", "TRACK_001")["presentation"] == "normal"
    assert project.effective_curve_settings("DEMO-001", "GR", "TRACK_002")["presentation"] == "axis_inverted"
    project.set_curve_override("GR", {"xlim": [0, 200], "presentation": "normal"}, None)
    assert project.effective_curve_settings("DEMO-001", "GR", "TRACK_002")["presentation"] == "axis_inverted"


def test_duplicate_curve_as_mirror_keeps_source_normal():
    project = create_demo_project()
    project.viewer_template["tracks"].append({"key": "TRACK_002", "width": 1.0})
    project.duplicate_curve_as_mirror("GR", "TRACK_002")
    assert project.curve_presentation("TRACK_001", "GR") == "normal"
    assert project.curve_presentation("TRACK_002", "GR") == "axis_inverted"


def test_template_roundtrip_preserves_complete_correlation_state(tmp_path):
    from hmdcorr.viewer_template import load_template, save_template
    project = create_demo_project()
    project.viewer_template["tracks"].append({"key": "TRACK_002", "width": 1.0})
    project.duplicate_curve_as_mirror("GR", "TRACK_002")
    project.hidden_tracks.add("TRACK_001")
    project.show_lithology = False
    project.show_tops = False
    project.spacing_mode = "uniform"
    project.correlation_linewidth = 2.0
    project.top_colors["Fm. Alfa"] = "#112233"
    project.set_curve_override("GR", {"xlim": [0, 180], "scale": "linear"}, None)
    path = tmp_path / "complete.hmdtpl"
    save_template(path, project.template_payload())
    restored = create_demo_project()
    restored.apply_template(load_template(path))
    assert restored.hidden_tracks == {"TRACK_001"}
    assert restored.show_lithology is False
    assert restored.show_tops is False
    assert restored.spacing_mode == "uniform"
    assert restored.correlation_linewidth == 2.0
    assert restored.top_colors["Fm. Alfa"] == "#112233"
    assert restored.curve_presentation("TRACK_002", "GR") == "axis_inverted"
    assert restored.effective_curve_settings("DEMO-001", "GR", "TRACK_002")["xlim"] == [0, 180]


def test_successive_las_loads_accumulate_by_uwi():
    import numpy as np
    from hmdcorr.models import CorrelationProject, Well
    project=CorrelationProject()
    first=Well("Pozo A","UWI-A",np.array([1.0]),{"GR":np.array([50.0])})
    second=Well("Pozo B","UWI-B",np.array([1.0]),{"GR":np.array([60.0])})
    added,updated=project.add_or_replace_wells([first]);assert (added,updated)==(1,0)
    added,updated=project.add_or_replace_wells([second]);assert (added,updated)==(1,0)
    assert [well.uwi for well in project.wells]==["UWI-A","UWI-B"]
    refreshed=Well("Pozo A revisado","UWI-A",np.array([1.0]),{"GR":np.array([70.0])})
    added,updated=project.add_or_replace_wells([refreshed]);assert (added,updated)==(0,1)
    assert len(project.wells)==2 and project.wells[0].name=="Pozo A revisado"


def test_well_repository_persists_las_copy_and_index(tmp_path):
    import numpy as np
    from pathlib import Path
    from hmdcorr.models import Well
    from hmdcorr.well_repository import WellRepository
    source=tmp_path/"original.las";source.write_text("~Version\nVERS. 2.0",encoding="utf-8")
    well=Well("Pozo A","UWI-A",np.array([1.0]),{"GR":np.array([50.0])},x=100.0,y=200.0)
    repository=WellRepository(tmp_path/"repository");entry=repository.register(source,well)
    assert entry["uwi"]=="UWI-A"
    assert len(repository.entries())==1
    assert Path(entry["las_path"]).exists()


def test_tops_import_accepts_spanish_columns_and_normalized_uwi(tmp_path):
    from hmdcorr.demo import create_demo_project
    from hmdcorr.importers import load_tops
    project=create_demo_project();well=project.wells[0];well.uwi="49-021-21045-0000"
    path=tmp_path/"cimas.csv"
    path.write_text("POZO,CIMA,PROFUNDIDAD\n49021210450000,Fm. Prueba,150\n",encoding="utf-8")
    report=load_tops(path,project.wells,return_report=True)
    assert report["count"]==1 and not report["unmatched"]
    assert well.tops["Fm. Prueba"]==150.0


def test_renderer_labels_each_loaded_top_inside_well_track():
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from hmdcorr.renderer import draw_correlation_figure
    project=create_demo_project();figure=Figure(figsize=(8,5));FigureCanvasAgg(figure)
    draw_correlation_figure(figure,project,"GR",None)
    labels=[text.get_text() for axis in figure.axes for text in axis.texts]
    assert "Fm. Alfa" in labels and "Fm. Beta" in labels


def test_renderer_exposes_synchronized_axes_for_zoom():
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from hmdcorr.renderer import draw_correlation_figure
    project=create_demo_project();figure=Figure(figsize=(8,5));FigureCanvasAgg(figure)
    draw_correlation_figure(figure,project,"GR",None)
    assert len(figure._hmd_depth_axes)>=len(project.wells)*len(project.visible_tracks())
    assert len(figure._hmd_track_axis_groups)>=len(figure._hmd_depth_axes)


def test_zoom_modes_and_mouse_navigation_contract():
    from pathlib import Path
    root=Path(__file__).parents[1]
    canvas=(root/"hmdcorr"/"canvas.py").read_text(encoding="utf-8")
    window=(root/"hmdcorr"/"main_window.py").read_text(encoding="utf-8")
    for method in ("_on_press","_on_motion","_on_release","_on_scroll","reset_zoom"):
        assert f"def {method}" in canvas
    assert '"Zoom por intervalo"' in window and '"Zoom areal"' in window
    assert 'reset_zoom.setShortcut("R")' in window


def test_interval_zoom_follows_hmdlog_drag_contract():
    from pathlib import Path
    canvas=(Path(__file__).parents[1]/"hmdcorr"/"canvas.py").read_text(encoding="utf-8")
    assert 'self._drag={"kind":"interval"' in canvas
    assert 'drag["kind"]=="interval"' in canvas
    assert "self._selection_patch.set_height" in canvas
    assert 'top,base=sorted((drag["start_depth"],current))' in canvas
    assert "mantenga pulsado y arrastre" in canvas


def test_area_zoom_magnifies_complete_figure_rectangle():
    from pathlib import Path
    canvas=(Path(__file__).parents[1]/"hmdcorr"/"canvas.py").read_text(encoding="utf-8")
    assert "apply_area_viewport(self.figure,x0,x1,y0,y1)" in canvas
    assert "Zoom areal — recuadro" in canvas
    assert "transform=self.figure.transFigure" in canvas


def test_area_viewport_expands_selected_multiwell_region():
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from hmdcorr.renderer import draw_correlation_figure, apply_area_viewport
    project=create_demo_project();figure=Figure(figsize=(8,5));FigureCanvasAgg(figure)
    draw_correlation_figure(figure,project,"GR",None);figure.canvas.draw()
    first=figure._hmd_depth_axes[0].get_position();second=figure._hmd_depth_axes[1].get_position()
    x0=min(first.x0,second.x0);x1=max(first.x1,second.x1);y0=max(first.y0,.20);y1=min(first.y1,.80)
    apply_area_viewport(figure,x0,x1,y0,y1)
    expanded_first=figure._hmd_depth_axes[0].get_position();expanded_second=figure._hmd_depth_axes[1].get_position()
    assert expanded_first.width>first.width
    assert expanded_second.width>second.width
    assert expanded_first.height>first.height


def test_renderer_exposes_well_curve_metadata_for_data_cursor():
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from hmdcorr.renderer import draw_correlation_figure
    project=create_demo_project();figure=Figure(figsize=(8,5));FigureCanvasAgg(figure)
    draw_correlation_figure(figure,project,"GR","Fm. Beta")
    info=figure._hmd_group_info[figure._hmd_track_axis_groups[0][0]]
    assert info["well"].uwi=="DEMO-001"
    assert "GR" in info["sources"]
    assert len(info["depth"])==len(info["raw_depth"])
    assert info["well"].depth_unit=="ft"


def test_compact_data_cursor_and_status_contract():
    from pathlib import Path
    root=Path(__file__).parents[1]
    canvas=(root/"hmdcorr"/"canvas.py").read_text(encoding="utf-8")
    window=(root/"hmdcorr"/"main_window.py").read_text(encoding="utf-8")
    assert "MD real" not in canvas or "MD:" in canvas
    assert "Rel. {datum}" in canvas
    assert "right_side=event.x<axis.bbox.x0+axis.bbox.width/2" in canvas
    assert 'tag_lines.extend(values)' in canvas and '"\\n".join(tag_lines)' in canvas
    assert '"Cursor de datos"' in window
    assert "Ctrl+clic" in window


def test_correlation_lines_remain_attached_after_local_zoom():
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from hmdcorr.renderer import draw_correlation_figure, update_correlation_artists
    project=create_demo_project();figure=Figure(figsize=(8,5));FigureCanvasAgg(figure)
    draw_correlation_figure(figure,project,"GR",None);figure.canvas.draw()
    artist,_=figure._hmd_correlation_definitions[0];before=list(artist.get_ydata())
    figure._hmd_depth_axes[0].set_ylim(250,100);update_correlation_artists(figure)
    after=list(artist.get_ydata())
    assert before!=after


def test_assisted_top_transfer_is_traceable_and_reversible():
    project=create_demo_project();source,target=project.wells[:2]
    target.tops.pop("Fm. Alfa",None)
    record=project.transfer_top(source.uwi,target.uwi,"Fm. Alfa",1042.5,"GR",(-40,60))
    assert target.tops["Fm. Alfa"]==1042.5
    assert target.top_metadata["Fm. Alfa"]["method"]=="assisted_drag"
    assert record["curve"]=="GR"
    project.undo_last_correlation()
    assert "Fm. Alfa" not in target.tops


def test_assisted_correlation_persists_metadata_and_history(tmp_path):
    from hmdcorr.project_io import save_project,load_project
    project=create_demo_project();source,target=project.wells[:2]
    source.tops["Interpretada"]=1040.0
    project.transfer_top(source.uwi,target.uwi,"Interpretada",1090,"GR",(-50,50))
    path=tmp_path/"assist.hmdcorr";save_project(path,project);restored=load_project(path)
    assert restored.wells[1].top_metadata["Interpretada"]["source_uwi"]==source.uwi
    assert restored.correlation_history[-1]["target_depth"]==1090


def test_assisted_drag_ui_contract():
    from pathlib import Path
    root=Path(__file__).parents[1]
    canvas=(root/"hmdcorr"/"canvas.py").read_text(encoding="utf-8")
    window=(root/"hmdcorr"/"main_window.py").read_text(encoding="utf-8")
    assert "begin_assisted_correlation" in canvas and "_draw_ghost" in canvas
    assert "Correlación asistida por arrastre…" in window
    assert 'setShortcut("Ctrl+Z")' in window and 'event.key=="escape"' in canvas


def test_assisted_ghost_remains_visible_between_wells_contract():
    from pathlib import Path
    canvas=(Path(__file__).parents[1]/"hmdcorr"/"canvas.py").read_text(encoding="utf-8")
    assert "def _draw_free_ghost" in canvas
    assert "source_display_top" in canvas
    assert "EN TRÁNSITO" in canvas
    assert "self._draw_free_ghost(event)" in canvas
    assert 'state["target"]=None' in canvas
    assert "fuera de un track destino válido" in canvas


def test_assisted_ghost_cleanup_allows_consecutive_correlations():
    from pathlib import Path
    canvas=(Path(__file__).parents[1]/"hmdcorr"/"canvas.py").read_text(encoding="utf-8")
    assert "except (ValueError,AttributeError,NotImplementedError)" in canvas
    assert "self.cancel_assisted_correlation()\n            if payload" in canvas
    assert "if self.assisted_correlation:self.cancel_assisted_correlation(redraw=False)" in canvas


def test_cursor_top_adjustment_is_traceable_and_reversible():
    project=create_demo_project();well=project.wells[0];name="Fm. Alfa";old=well.tops[name]
    record=project.adjust_top(well.uwi,name,old+12.5,"cursor_adjustment")
    assert well.tops[name]==old+12.5
    assert well.top_metadata[name]["last_adjustment"]["previous_depth"]==old
    assert record["method"]=="cursor_adjustment"
    project.undo_last_correlation()
    assert well.tops[name]==old


def test_cursor_top_editor_ui_contract():
    from pathlib import Path
    root=Path(__file__).parents[1]
    canvas=(root/"hmdcorr"/"canvas.py").read_text(encoding="utf-8")
    window=(root/"hmdcorr"/"main_window.py").read_text(encoding="utf-8")
    for token in ("set_top_edit_enabled","_top_at","_draw_top_edit_preview","manual_request","protect_datum_top"):
        assert token in canvas
    assert '"Editar cimas con cursor"' in window
    assert '"Proteger cima usada como datum"' in window
    assert "Confirmar ajuste de cima" in window


def test_zoom_and_top_editor_coexist_without_reset_contract():
    from pathlib import Path
    root=Path(__file__).parents[1]
    canvas=(root/"hmdcorr"/"canvas.py").read_text(encoding="utf-8")
    window=(root/"hmdcorr"/"main_window.py").read_text(encoding="utf-8")
    assert "Outside the hit tolerance the event continues to the active zoom mode" in canvas
    assert "def capture_navigation_state" in canvas and "def restore_navigation_state" in canvas
    toggle=window[window.index("def _toggle_top_edit"):window.index("def _toggle_datum_protection")]
    assert "if tops_were_hidden" in toggle
    assert "self.canvas.restore_navigation_state(navigation)" in window


def test_vertical_navigation_has_fine_normal_and_fast_steps():
    from pathlib import Path
    canvas=(Path(__file__).parents[1]/"hmdcorr"/"canvas.py").read_text(encoding="utf-8")
    assert "_modifier_value(event,.05,.01,.15)" in canvas
    assert "_modifier_value(event,.45,.15,1.0)" in canvas
    assert "def _bounded_depth_shift" in canvas
    assert "Desplazamiento {label}" in canvas
    assert "np.clip(requested,lower,upper)" in canvas


def test_post_zoom_navigation_uses_stable_pixels_and_wheel_step():
    from pathlib import Path
    canvas=(Path(__file__).parents[1]/"hmdcorr"/"canvas.py").read_text(encoding="utf-8")
    assert "def _inside_depth_workspace" in canvas
    assert 'step=float(getattr(event,"step",0.0) or 0.0)' in canvas
    assert 'pixel_delta=float(event.y-drag["y"])' in canvas
    assert 'pixel_delta/drag["axis_height"]' in canvas
    assert "límite del registro" in canvas


def test_installer_stops_on_pip_failure_and_verifies_runtime():
    from pathlib import Path
    root=Path(__file__).parents[1]
    installer=(root/"Instalar.ps1").read_text(encoding="utf-8")
    launcher=(root/"Iniciar_HMDLog_Correlation.bat").read_text(encoding="utf-8")
    assert "Assert-LastCommand" in installer and "$LASTEXITCODE -ne 0" in installer
    assert "--prefer-binary" in installer
    assert "import matplotlib, PySide6, numpy, pandas, lasio, openpyxl, pyproj" in installer
    assert "Instalacion terminada y verificada" in installer
    assert "La instalacion esta incompleta o danada" in launcher
def test_track_properties_support_global_and_well_overrides(tmp_path):
    from hmdcorr.project_io import save_project,load_project
    project=create_demo_project();key=project.viewer_template["tracks"][0]["key"];uwi=project.wells[0].uwi
    project.set_track_properties(key,{"width":2.25,"background":"#EEEEEE"})
    project.set_track_properties(key,{"background":"#123456","min_width":240},uwi)
    assert project.effective_track_properties(key)["width"]==2.25
    assert project.effective_track_properties(key,uwi)["background"]=="#123456"
    path=tmp_path/"track-properties.hmdcorr";save_project(path,project);restored=load_project(path)
    assert restored.effective_track_properties(key,uwi)["min_width"]==240
    assert restored.effective_track_properties(key,project.wells[1].uwi)["background"]=="#EEEEEE"


def test_track_grid_properties_are_bounded_and_persisted(tmp_path):
    from hmdcorr.project_io import save_project,load_project
    project=create_demo_project();key=project.viewer_template["tracks"][0]["key"]
    project.set_track_properties(key,{"horizontal_grid_enabled":False,"horizontal_grid_interval":250,
        "horizontal_grid_subdivisions":3,"horizontal_grid_style":"dashed","vertical_grid_enabled":True,
        "vertical_grid_divisions":8,"vertical_grid_subdivisions":2,"vertical_grid_style":"dotted",
        "vertical_grid_reference":"AT90","vertical_grid_scale_mode":"auto",
        "vertical_grid_log_detail":"2_5","vertical_grid_show_labels":True,
        "grid_minor_color":"#D8DEE8","grid_minor_width":.3,"grid_minor_alpha":.25,
        "grid_same_color":False})
    path=tmp_path/"grid-properties.hmdcorr";save_project(path,project);restored=load_project(path)
    props=restored.effective_track_properties(key)
    assert props["horizontal_grid_enabled"] is False and props["horizontal_grid_interval"]==250
    assert props["horizontal_grid_subdivisions"]==3 and props["horizontal_grid_style"]=="dashed"
    assert props["vertical_grid_divisions"]==8 and props["vertical_grid_subdivisions"]==2
    assert props["vertical_grid_style"]=="dotted"
    assert props["vertical_grid_reference"]=="AT90" and props["vertical_grid_scale_mode"]=="auto"
    assert props["vertical_grid_log_detail"]=="2_5" and props["vertical_grid_show_labels"] is True
    assert props["grid_minor_color"]=="#D8DEE8" and props["grid_minor_width"]==.3
    assert props["grid_minor_alpha"]==.25 and props["grid_same_color"] is False


def test_track_and_curve_administrators_batch_expensive_redraws():
    from pathlib import Path
    root=Path(__file__).parents[1]
    manager=(root/"hmdcorr"/"track_manager.py").read_text(encoding="utf-8")
    window=(root/"hmdcorr"/"main_window.py").read_text(encoding="utf-8")
    staging=manager.split("def _stage_track",1)[1].split("def _populate_curves",1)[0]
    assert "preview_callback()" not in staging
    assert "se redibuja una sola vez al pulsar Aplicar" in manager
    assert "def _stage_curve_admin_changes" in window and "def _commit_curve_admin_changes" in window
    assert 'self.apply_track_curve_changes.setEnabled(True)' in window


def test_track_grid_configurator_edits_an_isolated_copy_and_coalesces_undo():
    from pathlib import Path
    manager=(Path(__file__).parents[1]/"hmdcorr"/"track_manager.py").read_text(encoding="utf-8")
    init=manager.split("def __init__",1)[1].split("def _friendly_track_label",1)[0]
    remember=manager.split("def _change_before",1)[1].split("def _stage_track",1)[0]
    apply=manager.split("def _apply_and_accept",1)[1].split("def reject",1)[0]
    reject=manager.split("def reject",1)[1].split("def ",1)[0]
    assert "self._target_project=project" in init and "self.project=copy.copy(project)" in init
    assert "self._undo_timer.setInterval(300)" in init
    assert "return self._pending_undo if self._pending_undo is not None else self._snapshot()" in remember
    assert "self._undo_timer.start()" in remember and "def _finish_undo_group" in remember
    assert "target.viewer_template=copy.deepcopy(self.project.viewer_template)" in apply
    assert "target.curve_overrides=copy.deepcopy(self.project.curve_overrides)" in apply
    assert "self._target_project" not in reject


def test_compact_track_configurator_has_curve_scales_and_tabs():
    from pathlib import Path
    root=Path(__file__).parents[1]
    manager=(root/"hmdcorr"/"track_manager.py").read_text(encoding="utf-8")
    template=(root/"hmdcorr"/"viewer_template.py").read_text(encoding="utf-8")
    assert "QTabWidget" in manager
    for tab in ('self._add_scroll_tab(page,"Track")','self._add_scroll_tab(page,"Curvas y escalas")','self._add_scroll_tab(page,"Retícula")'):
        assert tab in manager
    assert 'self.curve_scale.addItem("Lineal","linear")' in manager
    assert 'self.curve_scale.addItem("Logarítmica","log")' in manager
    assert "La escala logarítmica requiere límites mínimo y máximo positivos." in manager
    assert 'QPushButton("Restaurar valores recomendados")' in manager
    assert "default_curve_settings(source,key)" in manager
    assert 'source.startswith("AT")' in template


def test_track_configurator_keeps_action_buttons_visible_when_tabs_grow():
    from pathlib import Path
    manager=(Path(__file__).parents[1]/"hmdcorr"/"track_manager.py").read_text(encoding="utf-8")
    helper=manager.split("def _add_scroll_tab",1)[1].split("def _friendly_track_label",1)[0]
    init=manager.split("def __init__",1)[1].split("def _add_scroll_tab",1)[0]
    assert "QScrollArea" in manager and "scroll.setWidgetResizable(True)" in helper
    assert "scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)" in helper
    assert "root.addWidget(self.tabs,1)" in init
    assert "root.addLayout(actions)" in init


def test_at90_default_is_resistivity_log_scale():
    from hmdcorr.viewer_template import default_curve_settings
    settings=default_curve_settings("AT90","TRACK_002")
    assert settings["scale"]=="log"
    assert settings["xlim"]==[0.2,2000.0]
