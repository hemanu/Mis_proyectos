import numpy as np

from hmdcorr.models import CorrelationProject,Well
from hmdcorr.project_io import save_project,load_project


def _well():
    return Well("Pozo Norte","UWI-001",np.array([1.,2.]),{"GR":np.array([10.,20.])},well_metadata={"api_number":"42-001"})


def test_header_modes_and_aliases_preserve_source_identifiers():
    well=_well();project=CorrelationProject(wells=[well])
    assert project.well_header_label(well,"NAME")=="Pozo Norte"
    assert project.well_header_label(well,"UWI")=="UWI-001"
    assert project.well_header_label(well,"API")=="42-001"
    assert project.well_header_label(well,"NAME_API")=="Pozo Norte\n42-001"
    project.set_well_header_alias(well.uwi,"Norte-1");project.header_identifier_mode="CUSTOM"
    assert project.well_header_label(well)=="Norte-1"
    assert (well.name,well.uwi)==("Pozo Norte","UWI-001")


def test_header_configuration_roundtrip_and_template_scope(tmp_path):
    project=CorrelationProject(wells=[_well()],header_identifier_mode="CUSTOM",well_header_aliases={"UWI-001":"N-1"})
    path=tmp_path/"headers.hmdcorr";save_project(path,project);restored=load_project(path)
    assert restored.header_identifier_mode=="CUSTOM" and restored.well_header_aliases=={"UWI-001":"N-1"}
    template=project.template_payload()
    assert template["correlation_state"]["header_identifier_mode"]=="CUSTOM"
    assert "well_header_aliases" not in template and "well_header_aliases" not in template["correlation_state"]


def test_header_ui_contract():
    from pathlib import Path
    root=Path(__file__).parents[1]
    window=(root/"hmdcorr/main_window.py").read_text(encoding="utf-8")
    renderer=(root/"hmdcorr/renderer.py").read_text(encoding="utf-8")
    canvas=(root/"hmdcorr/canvas.py").read_text(encoding="utf-8")
    for label in ("Encabezados de pozos","NAME + UWI","NAME + API","Nombre personalizado","Editar nombres visibles…"):
        assert label in window
    assert "project.well_header_label(well)" in renderer
    assert "header_edit_callback" in canvas and "dblclick" in canvas
