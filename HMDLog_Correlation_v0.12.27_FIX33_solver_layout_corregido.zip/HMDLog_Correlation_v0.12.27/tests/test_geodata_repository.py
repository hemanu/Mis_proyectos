from pathlib import Path

import numpy as np

from hmdcorr.geodata_repository import GeoDataRepository
from hmdcorr.models import CorrelationProject, Well
from hmdcorr.project_io import load_project, save_project


def _project():
    well=Well("Pozo A","UWI-001",np.array([1000.,1001.,1002.]),{"GR":np.array([10.,20.,30.])},
              depth_unit="ft",tops={"Alfa":1001.},top_metadata={"Alfa":{"method":"file_import"}})
    return CorrelationProject(name="Ensayo",wells=[well])


def test_geodata_schema_is_extensible_and_syncs_tops(tmp_path):
    repository=GeoDataRepository(tmp_path/"geodata.db");project=_project()
    report=repository.sync_project(project,reason="test")
    assert report=={"created":1,"updated":0,"deleted":0}
    with repository.connect() as db:
        names={row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        assert {"projects","wells","tops","top_history","survey_stations","well_assets","well_intervals"}<=names
        assert db.execute("SELECT depth FROM tops").fetchone()[0]==1001.


def test_top_history_records_real_changes_and_restore(tmp_path):
    repository=GeoDataRepository(tmp_path/"geodata.db");project=_project();repository.sync_project(project)
    project.wells[0].tops["Alfa"]=1002.;project.wells[0].top_metadata["Alfa"]={"method":"cursor_adjustment"}
    report=repository.sync_project(project,reason="cursor_adjustment")
    assert report["updated"]==1
    rows=repository.top_history(project.project_id)
    assert rows[0]["previous_depth"]==1001. and rows[0]["new_depth"]==1002.
    project.wells[0].tops.clear();project.wells[0].top_metadata.clear()
    assert repository.restore_tops(project)==1
    assert project.wells[0].tops["Alfa"]==1002.


def test_project_snapshot_keeps_stable_project_id_and_tops(tmp_path):
    project=_project();path=tmp_path/"portable.hmdcorr";save_project(path,project);loaded=load_project(path)
    assert loaded.project_id==project.project_id
    assert loaded.wells[0].tops=={"Alfa":1001.}


def test_database_menu_contract():
    source=(Path(__file__).resolve().parents[1]/"hmdcorr"/"main_window.py").read_text(encoding="utf-8")
    assert 'addMenu("Base de datos de cimas")' in source
    assert '"Mostrar tabla de cimas…"' in source
    assert "Recuperar cimas para los pozos actuales" not in source
    for method in ("_save_tops_database","_show_tops_database","_show_top_history","_export_tops_database"):
        assert f"def {method}" in source


def test_catalog_preserves_style_and_selected_top_can_be_undone(tmp_path):
    repository=GeoDataRepository(tmp_path/"geodata.db");project=_project()
    project.top_colors["Alfa"]="#123456";project.set_top_style("Alfa",{"font_size":9,"italic":True})
    repository.sync_project(project)
    record=repository.tops_catalog()[0]
    assert record["top_name"]=="Alfa" and "font_size" in record["style_json"]
    project.wells[0].tops.pop("Alfa");project.wells[0].top_metadata.pop("Alfa")
    project.adopt_database_top("UWI-001","Alfa",1001.,{"source":"catalog"})
    assert project.wells[0].tops["Alfa"]==1001.
    project.undo_last_correlation();assert "Alfa" not in project.wells[0].tops
