from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CANVAS = (ROOT / "hmdcorr" / "canvas.py").read_text(encoding="utf-8")
WINDOW = (ROOT / "hmdcorr" / "main_window.py").read_text(encoding="utf-8")


def test_area_zoom_has_an_independent_navigable_viewport():
    assert "self._area_zoom_active" in CANVAS
    assert "self._area_viewport" in CANVAS
    assert "def _pan_area_by" in CANVAS
    assert '"kind":"area_pan"' in CANVAS
    assert "Desplazamiento areal" in CANVAS


def test_area_pan_transforms_the_complete_figure_view():
    method = CANVAS.split("def _pan_area_by", 1)[1].split("def set_data_cursor_enabled", 1)[0]
    assert "apply_area_viewport(self.figure" in method
    assert "self._area_viewport=" in method


def test_startup_policy_can_restore_last_project_or_open_clean():
    assert 'preferences_menu=appearance_menu.addMenu("Preferencias de aplicación")' in WINDOW
    assert 'addMenu("Comportamiento al iniciar")' in WINDOW
    assert '"Reabrir último proyecto","last"' in WINDOW
    assert '"Iniciar con ventana limpia","clean"' in WINDOW
    assert 'self.settings.value("startup/last_project"' in WINDOW
    assert "def _restore_startup_workspace" in WINDOW


def test_project_menu_replaces_file_menu_without_duplicate_commands():
    assert 'bar.addMenu("Archivo")' not in WINDOW
    assert 'bar.addMenu("Proyecto")' in WINDOW
    for command in ("Administrador de proyecto…","Pozos LAS…","Cimas o topes…","Panel SVG/PDF/PNG…","Salir"):
        assert command in WINDOW
    wells=WINDOW.split('wells_menu=bar.addMenu("Pozos")',1)[1].split('tracks_menu=bar.addMenu("Tracks y curvas")',1)[0]
    assert "Administrador de pozos…" not in wells


def test_unsaved_changes_are_protected_on_close():
    assert "def closeEvent" in WINDOW
    assert "QMessageBox.Save|QMessageBox.Discard|QMessageBox.Cancel" in WINDOW
    refresh = WINDOW.split("def refresh_plot", 1)[1].split("def _set_zoom_mode", 1)[0]
    assert "if not self._loading" in refresh
    assert "self._dirty=True" in refresh
