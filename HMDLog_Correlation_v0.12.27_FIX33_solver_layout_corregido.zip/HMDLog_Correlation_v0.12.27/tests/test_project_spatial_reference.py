import sqlite3

import numpy as np

from hmdcorr.coordinates import coordinate_data_from_values
from hmdcorr.geodata_repository import GeoDataRepository
from hmdcorr.models import CorrelationProject,Well
from hmdcorr.project_io import load_project,save_project
from hmdcorr.spatial_reference import (coordinates_in_project,original_coordinate_warning,practical_crs_catalog,
    practical_crs_category,recommend_crs_for_bounds,refresh_project_coordinate_cache)


def _project():
    data=coordinate_data_from_values("41.310000","-104.15000",latitude_field="LATI",longitude_field="LONG",source_file="a.las")
    well=Well("Pozo","UWI-1",np.asarray([1.]),{"GR":np.asarray([10.])},coordinate_data=data)
    project=CorrelationProject(name="Campo Norte",wells=[well],project_metadata={"field":"Norte"},
        spatial_reference={"horizontal_crs":"EPSG:4326","horizontal_name":"WGS 84","horizontal_type":"geographic","coordinate_units":"degrees",
            "transform_coordinates":True,"show_original_coordinates":True,"vertical_reference":"KB","vertical_units":"ft","default_elevation":1200.})
    refresh_project_coordinate_cache(project);return project


def test_project_crs_roundtrip_preserves_original_coordinates(tmp_path):
    project=_project();path=tmp_path/"crs.hmdcorr";save_project(path,project);loaded=load_project(path)
    assert loaded.spatial_reference["horizontal_crs"]=="EPSG:4326"
    assert loaded.spatial_reference["vertical_reference"]=="KB" and loaded.project_metadata["field"]=="Norte"
    assert loaded.wells[0].coordinate_data["source_y"]=="41.310000"
    assert coordinates_in_project(loaded.wells[0].coordinate_data,"EPSG:4326")==(-104.15,41.31)


def test_sign_discrepancy_is_reported_without_mutation():
    data=coordinate_data_from_values("41.31","-104.15",latitude_field="LATI",longitude_field="LONG")
    data["latitude"]=-41.31
    assert original_coordinate_warning(data)=="Revisar signo de latitud"
    assert data["source_y"]=="41.31" and data["latitude"]==-41.31


def test_project_metadata_and_spatial_reference_are_in_sqlite(tmp_path):
    repository=GeoDataRepository(tmp_path/"geo.db");project=_project();repository.sync_project(project)
    with sqlite3.connect(repository.path) as db:
        row=db.execute("SELECT metadata_json,spatial_reference_json FROM projects WHERE project_id=?",(project.project_id,)).fetchone()
    assert '"field": "Norte"' in row[0] and '"horizontal_crs": "EPSG:4326"' in row[1]


def test_project_properties_ui_contract():
    from pathlib import Path
    root=Path(__file__).parents[1]
    dialog=(root/"hmdcorr"/"well_manager.py").read_text(encoding="utf-8")
    main=(root/"hmdcorr"/"main_window.py").read_text(encoding="utf-8")
    for label in ("Datos generales","Referencia espacial","Referencia vertical","Sección"):
        assert label in dialog
    for command in ("Nuevo proyecto…","Guardar proyecto como…","Administrador de proyecto…","Cerrar proyecto"):
        assert command in main


def test_practical_crs_catalog_is_compact_extensible_and_has_expected_regions():
    catalog=practical_crs_catalog()
    assert set(("Globales","México","Norteamérica","ITRF","UTM WGS 84 — Norte","UTM WGS 84 — Sur","Manual / otro EPSG"))<=set(catalog)
    codes=[code for items in catalog.values() for code,_name in items]
    assert len(codes)==len(set(codes))
    assert {"EPSG:4326","EPSG:6365","EPSG:6372","EPSG:32613","EPSG:32713"}<=set(codes)
    assert practical_crs_category("EPSG:6368")=="México"
    assert practical_crs_category("EPSG:999999")=="Manual / otro EPSG"


def test_project_administrator_offers_category_selector_and_manual_epsg_entry():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr"/"well_manager.py").read_text(encoding="utf-8")
    assert '"Grupo de sistemas"' in source
    assert "self.project_crs.setEditable(True)" in source
    assert '"Manual / otro EPSG"' in (Path(__file__).parents[1]/"hmdcorr"/"spatial_reference.py").read_text(encoding="utf-8")


def test_visual_crs_recommendation_for_mexico_and_utm_crossing():
    local=recommend_crs_for_bounds(-105.8,22.0,-103.2,24.0)
    assert local["region"]=="México" and local["recommendations"][0]["code"]=="EPSG:6368"
    regional=recommend_crs_for_bounds(-109.0,18.0,-96.0,28.0)
    assert regional["crosses_utm_zones"] is True and regional["recommendations"][0]["code"]=="EPSG:6372"


def test_visual_crs_recommendation_for_northern_and_southern_utm():
    assert recommend_crs_for_bounds(10,40,12,42)["recommendations"][0]["code"]=="EPSG:32632"
    assert recommend_crs_for_bounds(10,-42,12,-40)["recommendations"][0]["code"]=="EPSG:32732"


def test_crs_globe_assistant_is_integrated_in_project_administrator():
    from pathlib import Path
    root=Path(__file__).parents[1];manager=(root/"hmdcorr"/"well_manager.py").read_text(encoding="utf-8")
    selector=(root/"hmdcorr"/"crs_map_selector.py").read_text(encoding="utf-8")
    assert '"🌐 Seleccionar área en mapa…"' in manager and "CrsMapSelectorDialog" in manager
    assert "RectangleSelector" in selector and '"Aplicar CRS seleccionado"' in selector
