from pathlib import Path

from hmdcorr.models import CorrelationProject
from hmdcorr.demo import create_demo_project
from hmdcorr.project_io import load_project, save_project
from hmdcorr.viewer_template import load_template, save_template


ROOT=Path(__file__).resolve().parents[1]


def test_top_style_has_safe_defaults_and_independent_text_color():
    project=CorrelationProject();style=project.effective_top_style("Alfa")
    assert style["font_size"]==5.2 and style["italic"] is False and style["bold"] is False
    project.set_top_style("Alfa",{"font_size":9,"italic":True,"bold":True,"text_color":"#123456","highlight":True})
    style=project.effective_top_style("Alfa")
    assert style["font_size"]==9 and style["text_color"]=="#123456" and style["highlight"] is True


def test_renderer_applies_all_top_text_properties():
    source=(ROOT/"hmdcorr"/"renderer.py").read_text(encoding="utf-8")
    for property_name in ("font_size","fontstyle","fontweight","text_color","background_color","highlight"):
        assert property_name in source


def test_direct_value_editor_contract():
    source=(ROOT/"hmdcorr"/"main_window.py").read_text(encoding="utf-8")
    assert 'addMenu("Base de datos de cimas")' in source
    assert '"Apariencia de cimas…"' in source
    assert 'dialog.setWindowTitle("Editar valor de la cima")' in source
    assert 'Ajustar a la muestra más cercana del LAS' in source
    assert 'method="direct_value_edit"' in source


def test_top_styles_are_portable_and_template_aware():
    project_io=(ROOT/"hmdcorr"/"project_io.py").read_text(encoding="utf-8")
    models=(ROOT/"hmdcorr"/"models.py").read_text(encoding="utf-8")
    assert project_io.count('"top_styles"')>=2
    assert models.count('"top_styles"')>=2


def test_top_style_roundtrips_in_project_and_template(tmp_path):
    project=create_demo_project();project.set_top_style("Fm. Alfa",{"font_size":10,"italic":True,"bold":True,"text_color":"#123456"})
    project_path=tmp_path/"style.hmdcorr";save_project(project_path,project)
    assert load_project(project_path).effective_top_style("Fm. Alfa")["font_size"]==10
    template_path=tmp_path/"style.hmdtpl";save_template(template_path,project.template_payload())
    restored=create_demo_project();restored.apply_template(load_template(template_path))
    assert restored.effective_top_style("Fm. Alfa")["italic"] is True
