import numpy as np
from matplotlib.figure import Figure

from hmdcorr.models import CorrelationProject,Well
from hmdcorr.project_io import save_project,load_project
from hmdcorr.renderer import _apply_track_discretization


def test_discretization_draws_reference_and_both_patterned_areas():
    well=Well("W","U",np.array([1.,2.,3.,4.]),{"SP":np.array([-20.,-5.,8.,25.])})
    project=CorrelationProject();config=project.default_track_discretization("SP");config.update(reference=0.0)
    figure=Figure();axis=figure.add_subplot(111);axis.set_xlim(-40,40)
    settings={"source":"SP","scale":"linear","presentation":"normal"}
    _apply_track_discretization(axis,well,well.depth,settings,config)
    assert len(axis.collections)==2 and len(axis.lines)==1
    assert axis.collections[0].get_hatch()==".." and axis.collections[1].get_hatch()=="--"
    assert np.allclose(axis.lines[0].get_xdata(),[0.,0.])


def test_track_discretization_persists_in_project_and_template(tmp_path):
    project=CorrelationProject();config=project.default_track_discretization("GR");config["reference"]=65.0;project.set_track_discretization("TRACK_001",config);project.set_well_track_discretization("U1","TRACK_001",config)
    path=tmp_path/"disc.hmdcorr";save_project(path,project);restored=load_project(path)
    assert restored.track_discretizations["TRACK_001"]["reference"]==65.0
    assert restored.well_track_discretizations["U1"]["TRACK_001"]["reference"]==65.0
    template=project.template_payload();assert template["correlation_state"]["track_discretizations"]["TRACK_001"]["left"]["lithology"]=="Arena"
    assert "well_track_discretizations" not in template["correlation_state"]
    other=CorrelationProject();other.apply_template(template);assert other.track_discretizations==project.track_discretizations


def test_discretization_ui_contract():
    from pathlib import Path
    root=Path(__file__).parents[1];window=(root/"hmdcorr/main_window.py").read_text(encoding="utf-8");renderer=(root/"hmdcorr/renderer.py").read_text(encoding="utf-8")
    for label in ("Discretización litológica por referencia…","Área izquierda","Área derecha","Valor de referencia","Símbolo/patrón","Quitar de este pozo","Pozos seleccionados…","Todos los pozos visibles"):
        assert label in window
    assert "values>=reference if inverted else values<=reference" in renderer
    assert "fill_betweenx" in renderer and "ax.axvline(reference" in renderer
    assert "project.well_track_discretization(well.uwi" in renderer


def test_applying_or_removing_discretization_preserves_navigation():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/main_window.py").read_text(encoding="utf-8")
    block=source.split("def _configure_track_discretization",1)[1].split("def _select_discretization_wells",1)[0]
    apply_block=block.split("def apply_settings",1)[1].split("def remove_settings",1)[0]
    remove_block=block.split("def remove_settings",1)[1].split("buttons=",1)[0]
    for operation in (apply_block,remove_block):
        assert "capture_navigation_state()" in operation
        assert "refresh_plot()" in operation
        assert "restore_navigation_state(navigation)" in operation
        assert operation.index("capture_navigation_state()") < operation.index("refresh_plot()")
        assert operation.index("refresh_plot()") < operation.index("restore_navigation_state(navigation)")


def test_cursor_uses_lightweight_blitting_contract():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/canvas.py").read_text(encoding="utf-8")
    assert "_capture_overlay_background" in source and "_blit_overlays" in source
    assert "animated=True" in source and "self.blit(self.figure.bbox)" in source
    track=source.split("def _track_cursor",1)[1].split("def _on_press",1)[0]
    assert "set_ydata" in track and "set_xdata" in track
    motion=source.split("def _on_motion",1)[1].split("def _on_release",1)[0]
    interval=motion.split('if drag["kind"]=="interval"',1)[1].split("width=max",1)[0]
    assert "_blit_overlays()" in interval and "draw_idle()" not in interval
    assert "animated=True" in source


def test_discretization_fills_are_rasterized_for_fast_zoom():
    from pathlib import Path
    source=(Path(__file__).parents[1]/"hmdcorr/renderer.py").read_text(encoding="utf-8")
    block=source.split("def _apply_track_discretization",1)[1].split("def _header",1)[0]
    assert "rasterized=True" in block and "antialiased=False" in block


def test_interval_navigation_temporarily_hides_only_heavy_fills():
    from pathlib import Path
    canvas=(Path(__file__).parents[1]/"hmdcorr/canvas.py").read_text(encoding="utf-8")
    renderer=(Path(__file__).parents[1]/"hmdcorr/renderer.py").read_text(encoding="utf-8")
    assert "_begin_fast_navigation" in canvas and "_end_fast_navigation" in canvas
    assert "_navigation_restore_timer" in canvas and "start(160)" in canvas
    assert 'event.button==2' in canvas and "self._begin_fast_navigation()" in canvas
    assert 'drag["kind"] in {"pan","area_pan"}' in canvas and "self._end_fast_navigation()" in canvas
    assert "_hmd_discretization_artists" in renderer and 'set_gid("hmd-discretization-fill")' in renderer
