# HMDLog Correlation v0.12.27

- Geometría horizontal única para encabezado, tracks, canvas y separadores.
- Cimas y cursores confinados a cada ViewBox; correlaciones confinadas al espacio interpozo.
- Eliminados los marcos globales redundantes que producían líneas y textos desplazados.
- Ancho técnico uniforme que impide el colapso del segundo track.
- Una sola cuadrícula raíz: encabezados, tracks y espacios comparten columnas.
- Eliminadas las cuadrículas anidadas y sus cálculos independientes.
- Encabezado interpozo dimensionado por sus filas, sin altura fija conflictiva.

### Editor de tracks

`Tracks y curvas > Configurar tracks y retícula…` permite modificar ancho relativo y mínimo, orden,
visibilidad, fondo, borde, cuadrícula, escala de profundidad, separación y encabezado. Los
cambios se realizan sobre una copia ligera, con deshacer, restauración de valores y alcance por
pozo, track o plantilla. Los controles continuos se agrupan en una sola operación de deshacer;
el proyecto y el visor sólo se actualizan una vez al pulsar **Aplicar**.
El mismo configurador se abre desde el icono de retícula con engranaje de la barra GPU y
selecciona automáticamente el último track señalado por el cursor. Las retículas horizontal
y vertical admiten activación independiente, divisiones, subdivisiones, estilo, color,
grosor y opacidad. VisPy agrupa cada orientación en un solo `LineVisual` para conservar el
rendimiento.

La ventana compacta separa **Track**, **Curvas y escalas** y **Retícula**. Cada curva puede
usar escala lineal o logarítmica, límites propios y eje invertido; las escalas logarítmicas
validan límites positivos. Las curvas de resistividad, incluidas las familias `AT` como AT90,
proponen automáticamente 0.2–2000 en escala logarítmica.
Cada pestaña dispone de desplazamiento vertical independiente: mostrar opciones avanzadas o
una retícula personalizada ya no agranda el diálogo ni oculta **Aplicar** y **Cancelar**.

La retícula vertical puede usar una curva de referencia y seguir automáticamente su escala.
En curvas logarítmicas dibuja décadas reales (1, 10, 100, 1000, etc.) y permite añadir
subdivisiones 2/5 o 2–9. Las líneas principales pueden rotularse en el encabezado y las
secundarias se procesan en un lote OpenGL separado, más tenue, sin crear una visual por línea.

Las claves internas (`TRACK_002`, `TRACK_004`, etc.) ya no se muestran como nombre principal:
el selector usa `Track 1`, `Track 2` y una descripción automática como GR o Resistividad. El
nombre sigue siendo editable. La pestaña Retícula mantiene visibles los colores principal y
secundario, sus grosores y opacidades, con opción de igualarlos o restaurar la paleta recomendada.

La actualización GPU omite por completo las geometrías de retícula vacías, evitando errores de
`bounds()` de VisPy. Los eventos de cámara se agrupan a 16 ms y cada track conserva en caché su
retícula mientras el rango no cambie; las actualizaciones de cimas y correlaciones ya no obligan
a reconstruirla.

El visor VisPy conserva una sola ventana, un solo `SceneCanvas` y el mismo contexto OpenGL durante
toda la sesión. Cambios de escala, color, grosor, cimas y líneas actualizan únicamente los visuales
afectados; las curvas y retículas sin cambios se omiten mediante firmas ligeras. Agregar o quitar
pozos, tracks o curvas reconstruye sólo la escena interna, sin cerrar ni recrear el contexto GPU.
La barra de estado informa si se realizó una actualización incremental o estructural y su duración.
Las propagaciones validan que cada cima continúe presente en ambos tracks antes de leer su
profundidad. Una referencia obsoleta se oculta sin interrumpir el visor; si una actualización
incremental presenta una inconsistencia, se intenta reconstruir la escena sobre el mismo canvas
antes de recurrir al motor de compatibilidad.

El encabezado técnico reserva filas independientes para nombre del track, nombre/tipo de curva,
límites extremos y etiquetas internas de retícula. En escala logarítmica, cada rótulo de década
se muestra sólo cuando cabe sin solaparse con los límites; al cambiar el ancho del track los
rótulos se ocultan o reaparecen automáticamente, pero sus líneas de retícula permanecen visibles.
Cada rótulo usa la misma coordenada normalizada que su línea vertical.

El visor VisPy construye cada track visible como una columna gráfica real dentro de cada pozo;
por ello el orden, ancho relativo, ancho mínimo, encabezado, borde y cuadrícula ya no son
metadatos sin efecto. Las curvas asignadas a un mismo track se dibujan juntas.

### Lectura contextual

La tabla fija de valores fue eliminada. Al situar el cursor sobre un track se presenta allí
mismo la profundidad MD, la profundidad relativa cuando existe datum y los valores con unidad
de todas sus curvas. La línea horizontal continúa sincronizada y `Ctrl + clic` fija o libera
la lectura para facilitar comparaciones.

### Eliminación del margen interno v0.12.12

- La cámara horizontal utiliza exactamente el dominio normalizado `0–1`.
- Se eliminó el margen `−0.05–1.05` que separaba visualmente la curva de los límites del track.
- El ViewBox deja de dibujar un segundo borde; permanece un único borde configurable coincidente con el track.
- Restablecer zoom y abandonar el zoom areal ya no recuperan el margen anterior.

### Optimización de secciones v0.12.12

- La escala de profundidad se integra dentro del primer track del pozo y deja de reservar una columna vacía.
- VisPy calcula separadores normalizados a partir de la distancia real entre pozos y respeta los modos proporcional y uniforme.
- La distancia real se muestra en el espacio correspondiente entre pozos.
- El Administrador de tracks acumula cambios y reconstruye la escena únicamente al pulsar Aplicar.
- El Administrador de curvas incorpora un botón Aplicar cambios para agrupar asignaciones, visibilidad y presentación.
- Cerrar el panel de curvas aplica automáticamente cualquier cambio pendiente.

### Motor gráfico seleccionable v0.12.12

- Se incorpora una capa de backends gráficos independiente del modelo geológico.
- `Apariencia > Motor gráfico > Abrir vista GPU experimental…` presenta los
  pozos visibles, una curva disponible por pozo y sus cimas mediante VisPy/OpenGL.
- La vista GPU utiliza una única escena, coordenadas `float32` y líneas OpenGL.
- La comprobación de VisPy es diferida: iniciar HMDLog no crea un contexto GPU.
- Matplotlib permanece como visor estable mientras se validan zoom, picking,
  simbología litológica y exportación antes de cambiar el motor predeterminado.
- Aplicar, modificar o quitar una discretización litológica conserva el zoom y
  la posición vertical actuales; únicamente `Restablecer zoom` recupera la vista completa.
- Cada pozo de la vista GPU es un grupo gráfico compuesto en una columna VisPy:
  un ViewBox superior contiene el encabezado, membrete y escala, y el ViewBox
  inferior contiene sus curvas y cimas. Ambos comparten exactamente ancho y posición.
- Las cámaras de los tracks están enlazadas verticalmente; el encabezado nunca
  se convierte en una barra general ni puede ser invadido por las curvas.
- Cada track GPU incorpora una escala de profundidad positiva y creciente hacia
  abajo. El cursor horizontal se sincroniza entre pozos y muestra MD real,
  profundidad relativa al datum y el valor de la curva sin redibujar la escena.
- La visibilidad de los objetos interactivos se configura después de crearlos,
  manteniendo compatibilidad con las versiones estables de `LineVisual` de VisPy.
- Cada pozo reside en una subcuadrícula con el mismo factor de expansión. El eje
  de profundidad conserva ancho fijo y todos los tracks reciben el mismo espacio,
  evitando que el último pozo absorba el ancho disponible.
- La lectura del cursor utiliza una tabla compacta con una columna por pozo. En
  cada track sólo aparece MD; los valores de curva y profundidad relativa quedan
  en la tabla para evitar cubrir los registros.
- La detección del cursor usa la transformación acumulada desde el canvas hasta
  cada SubScene, incluyendo cuadrícula y subcuadrícula, por lo que reconoce
  correctamente el interior de los tracks compuestos.
- Las cimas GPU respetan visibilidad, color, grosor, tamaño, negrita y cursiva
  del proyecto. Una capa superior conecta cimas equivalentes entre ViewBox y
  recalcula sus extremos durante zoom, desplazamiento y cambio de tamaño.
- El visor GPU incorpora zoom por intervalo (`I`), zoom areal (`A`) con recuadro,
  restauración (`R`), rueda y desplazamiento vertical amortiguado con botón
  intermedio. El modo areal convierte la selección en un enfoque de pantalla:
  colapsa pozos, tracks y separaciones exteriores, distribuye los tracks elegidos
  sobre el 95 % central del canvas, con márgenes laterales simétricos de 2.5 %;
  dentro del track conserva un margen técnico de datos del 2 %. Las cimas
  y correlaciones adoptan los bordes visibles; `R` restaura el layout original.
- Los atajos `I`, `A` y `R` se registran a nivel de ventana mediante Qt, por lo
  que funcionan aunque la tabla, el selector o el canvas tengan el foco.
- `E` activa la edición GPU de cimas con previsualización, ajuste a la muestra y
  confirmación. `C` configura un intervalo patrón y mantiene su fantasma visible
  desde el origen hasta el pozo destino; `Esc` cancela. Los cambios usan el mismo
  historial del proyecto y se sincronizan con la base geológica al cerrar.
- `Apariencia > Motor gráfico` permite elegir VisPy/OpenGL como canvas central o
  Matplotlib como compatibilidad. La elección persiste entre sesiones y ambos
  motores comparten el mismo proyecto; VisPy no necesita una ventana emergente.

### Optimización v0.12.3

- El desplazamiento arriba/abajo posterior al zoom por intervalo utiliza navegación progresiva.
- Durante el movimiento se ocultan temporalmente sólo los rellenos litológicos costosos; curvas, cimas, líneas de referencia y textos permanecen visibles.
- Al soltar el botón intermedio o detener la rueda, los patrones reaparecen automáticamente mediante un único renderizado final.
- Una prueba de carga con seis pozos y 12 000 muestras por pozo redujo el repintado medio de 1,76 s a 0,14 s durante la navegación, una mejora aproximada de 12,6 veces.

### Optimización v0.12.2

- El rectángulo del zoom areal y la banda del zoom por intervalo se mueven mediante *blitting* sin repintar tracks, curvas ni patrones durante el arrastre.
- El renderizado completo ocurre una sola vez al soltar el mouse y aplicar el zoom.
- Los rellenos litológicos se rasterizan internamente para acelerar cambios de escala y profundidad, manteniendo curvas, cimas y textos nítidos.
- Se desactivó el antialiasing innecesario de los polígonos tramados para reducir el costo gráfico.

### Corrección y optimización v0.12.1

- La discretización ahora pertenece a la combinación **pozo + track + curva** y deja de activarse automáticamente en toda la sección.
- El alcance predeterminado es **Sólo este pozo**; también puede copiarse expresamente a pozos seleccionados o a todos los pozos visibles.
- Los estilos permanecen disponibles como valores de plantilla, mientras los valores y activaciones particulares se guardan únicamente en el proyecto.
- Los proyectos v0.12.0 conservan el estilo previo como referencia, pero no lo imponen automáticamente a todos los pozos.
- El cursor utiliza una capa gráfica ligera con reutilización de artistas y blitting; moverlo ya no reconstruye los rellenos litológicos.
- Sólo se renderizan discretizaciones de pozos visibles.

### Actualización v0.12.0

- Nueva herramienta **Tracks y curvas > Discretización litológica por referencia…**.
- Cada track puede seleccionar su curva de control y un valor vertical de referencia.
- Las áreas geométricas izquierda y derecha admiten litología, color y patrón independientes.
- La clasificación respeta escalas lineales, logarítmicas y curvas con eje invertido.
- La línea de referencia permanece anclada al valor real durante zoom y desplazamiento.
- Las configuraciones se conservan en proyectos y plantillas HMDLog.

### Correcciones v0.11.13

- **Crear sección por pozos** fue reemplazado por **Trazar línea**.
- La sección finalizada muestra nombre y etiquetas de ambos extremos aun antes de guardarse.
- El selector identifica explícitamente la sección como **[Sin guardar]** y deshabilita su aplicación hasta guardarla.
- Al guardar, la sección aparece inmediatamente como línea activa.
- **Aplicar a correlación** conserva exclusivamente los pozos incluidos y su orden exacto a lo largo de la polilínea.
- El mapa resalta y numera los pozos pertenecientes a cada sección.

### Corrección v0.11.12

- El doble clic finaliza inmediatamente la polilínea sin agregar un vértice duplicado.
- El modo de trazado y la previsualización móvil se bloquean antes de abrir la revisión de la sección.
- Los eventos del cursor que quedan en la cola ya no pueden prolongar la línea después de finalizarla.

### Actualización v0.11.11

- **Finalizar** cierra el trazado para revisarlo y **Guardar sección** lo incorpora de forma persistente al proyecto.
- La barra genérica del mapa fue reemplazada por controles minimalistas: vista completa, vista anterior, desplazamiento, zoom, configuración del área, etiquetas y exportación.
- **Agregar etiqueta** crea anotaciones georreferenciadas; clic derecho permite editar texto, tamaño, negrita, cursiva, colores, moverlas o eliminarlas.
- Las etiquetas conservan su posición al desplazar o ampliar el mapa y al volver a abrir el proyecto.

### Actualización v0.11.10

- **Pozos > Encabezados de pozos** permite mostrar NAME, UWI, API, NAME + UWI, NAME + API o un nombre personalizado.
- Los alias visibles se guardan dentro del proyecto sin modificar los identificadores originales del LAS.
- Doble clic sobre el encabezado de un pozo permite renombrarlo directamente.
- La modalidad del encabezado se conserva en plantillas; los alias particulares no se transfieren entre proyectos.

### Actualización v0.11.9

- **Crear sección por pozos** es ahora el modo principal: cada clic sobre un pozo lo incorpora como vértice y prolonga la polilínea.
- Las secciones son poligonales abiertas con cualquier número de segmentos y conservan extremos A y A′.
- Doble clic o `Enter` finaliza; `Retroceso` deshace el último vértice y `Esc` cancela.
- El modo mixto permite combinar pozos con vértices libres.
- La estación de cada pozo se calcula acumulando la longitud de todos los segmentos desde A.
- Cada pozo cercano se proyecta contra el segmento más próximo.
- **Agregar/quitar pozos** permite editar posteriormente la pertenencia desde el mapa.
- Al quitar un pozo que funciona como vértice, los segmentos anterior y siguiente se reconectan automáticamente.
- Las inclusiones y exclusiones manuales se conservan durante los recálculos.
- Compatibilidad con las líneas rectas guardadas por v0.11.8.

### Actualización v0.11.8

- Trazado interactivo de líneas de sección A–A′ en la ventana Mapa mediante dos clics.
- Previsualización dinámica: verde para pozos tocados y naranja para pozos cercanos proyectados.
- Corredor de proyección configurable en kilómetros.
- Tabla de revisión para incluir o excluir pozos y consultar distancia lateral y posición desde A.
- Nombre alfanumérico editable, etiquetas automáticas en ambos extremos y protección contra duplicados.
- Renombrado y eliminación posterior sin alterar la geometría ni crear un identificador nuevo.
- Aplicación opcional a la correlación: ordena los pozos desde A hacia A′ y oculta de la sección los no incluidos.
- Las líneas, asociaciones y parámetros se conservan al guardar el proyecto.

### Actualización v0.11.7

- Nuevo icono de globo 🌐 en **Proyecto > Administrador de proyecto > Referencia espacial**.
- Ventana cartográfica independiente de internet con los pozos ubicados por LAT/LONG.
- Selección rectangular visible mediante arrastre del cursor.
- Cálculo automático de centro, región, hemisferio, zona UTM y cruce entre zonas.
- Recomendación explicada de CRS con alternativas; el usuario confirma antes de aplicarlo.
- Reglas iniciales especializadas para México ITRF2008 y reglas globales WGS 84/UTM, preparadas para ampliarse.

### Actualización v0.11.6

- Selector CRS práctico y ampliable dentro del Administrador de proyecto.
- Grupos: Globales, México, Norteamérica, ITRF y UTM WGS 84 para ambos hemisferios.
- México incluye ITRF2008 geográfico, LCC y zonas UTM 11N–16N.
- El selector permite escribir manualmente cualquier código EPSG no incluido en la lista breve.
- El nombre, tipo y unidad del sistema seleccionado se validan automáticamente con `pyproj`.

### Actualización v0.11.5

- El menú principal **Archivo** fue eliminado para evitar duplicidad; sus operaciones ahora están organizadas dentro de **Proyecto**.
- **Proyecto > Administrador de proyecto…** centraliza Datos generales, Referencia espacial/CRS, Pozos del proyecto, Sección, Mapa e Importar datos.
- **Proyecto > Importar** reúne pozos LAS y cimas/topes; **Proyecto > Exportar** contiene la salida del panel.
- **Proyectos recientes** permite reabrir el último archivo guardado desde el mismo menú.
- El comportamiento de inicio se reubicó en **Apariencia > Preferencias de aplicación**, porque es una preferencia global y no un dato del proyecto.
- Los pozos pueden agregarse o quitarse del proyecto sin eliminarlos de la base de datos.

### Actualización v0.11.4

- Nuevo menú principal **Proyecto** con Nuevo, Abrir, Guardar, Guardar como, Propiedades y Cerrar proyecto.
- **Propiedades del proyecto** centraliza identificación, CRS horizontal, referencia vertical y configuración inicial de la sección.
- El proyecto conserva nombre, área/cuenca, campo, operador, autor y descripción.
- Cada pozo conserva coordenadas y CRS originales; el mapa utiliza una transformación derivada al CRS del proyecto mediante `pyproj`.
- Compatibilidad con CRS geográficos y proyectados identificados mediante códigos EPSG.
- El mapa muestra el CRS activo y adapta sus ejes a longitud/latitud o X/Y proyectadas.
- Distancias calculadas según el CRS del proyecto, conservando Haversine para WGS 84.
- Detección explícita de discrepancias de signo entre los valores originales y normalizados, sin correcciones silenciosas.
- El comando independiente **Administrar coordenadas…** fue retirado del menú Pozos; la edición queda en **Datos básicos del pozo**.
- Metadatos y referencia espacial persisten en `.hmdcorr` (esquema 7) y SQLite (esquema 5).

### Actualización v0.11.3

- El Administrador de pozos se reorganizó por contexto en **Sección**, **Mapa**, **Catálogo general** e **Importar**.
- **Sección** contiene únicamente orden, LAS, cimas, visibilidad estratigráfica y retiro del proyecto.
- **Mapa** concentra LAT/LONG, CRS, validación de coordenadas, visibilidad y acceso a la ventana cartográfica.
- **Catálogo general** reúne creación, edición, incorporación al proyecto, exportación y eliminación definitiva.
- Se eliminó la repetición de controles de mapa dentro de la administración de la sección.
- Las tablas y barras horizontales se adaptan a la tarea activa y mantienen selección múltiple y doble clic contextual.

### Actualización v0.11.2

- Menú horizontal minimalista en **Pozos del proyecto**, con acciones compactas sobre la tabla.
- Los comandos cambian entre **Mostrar** y **Ocultar** según el estado del pozo seleccionado.
- Selección múltiple para modificar simultáneamente la visibilidad o quitar varios pozos del proyecto.
- Doble clic en las columnas **Sección** o **Mapa** para alternar directamente el estado.
- **Agregar pozos…** conduce al catálogo y **Quitar del proyecto…** queda separado como acción de advertencia.
- Tabla más compacta, columnas Nombre/Estado adaptables y botón **Cerrar** completamente en español.

### Actualización v0.11.1

- El Administrador de pozos permite **mostrar u ocultar cada pozo en la sección** sin borrarlo del proyecto ni de la base de datos.
- La presencia en el **Mapa de pozos** se controla de forma independiente.
- Las columnas Sección y Mapa indican claramente si cada pozo está Visible u Oculto.
- Las ventanas de mapa abiertas se actualizan inmediatamente al cambiar la selección.
- Ambas selecciones se conservan en el proyecto `.hmdcorr` y en SQLite.
- **Quitar del proyecto** sigue disponible como operación distinta; la eliminación definitiva continúa reservada al catálogo.

### Actualización v0.11.0

- **Pozos > Administrador de pozos…** reemplaza al antiguo repositorio y concentra el flujo completo.
- Pestañas **Pozos del proyecto**, **Base de datos de pozos** e **Importar pozos**.
- Creación y edición manual con UWI, nombre, operador, campo, LATI/LONG, CRS, elevación, estado y observaciones.
- Importación desde Excel, CSV y TXT con vista previa y asignación visual de columnas, sin depender de encabezados rígidos.
- Resolución de UWI duplicados: actualizar, omitir, aplicar a todos o cancelar.
- Los UWI se leen como texto para conservar ceros iniciales.
- Pozos sin LAS pueden registrarse, incorporarse al proyecto y mostrarse en el mapa; la correlación sólo dibuja aquellos con registros.
- Diferencia explícita entre **Quitar del proyecto** y **Eliminar definitivamente**.
- Ordenamiento de pozos, filtros del catálogo, exportación CSV y adición múltiple al proyecto.
- Metadatos del pozo persistentes en SQLite y en el proyecto portátil `.hmdcorr`.

### Corrección v0.10.1

- Se agregó reconocimiento explícito del par estándar LAS `LATI .DEG` / `LONG .DEG`.
- `LATI: 41.310000` se interpreta como latitud y `LONG: -104.15000` como longitud WGS 84 válida.
- Los pozos que contienen este par ahora se almacenan con `EPSG:4326` y aparecen automáticamente en la ventana **Mapa de pozos**.

### Actualización v0.10.0

- Nueva ventana emergente **Pozos > Mapa de pozos…**, independiente y no modal, con círculos, nombres, zoom, desplazamiento y tooltip de UWI/LAT/LON/CRS.
- Lectura automática desde LAS de `LAT`, `LATITUDE`, `LON`, `LONG`, `LOG`, `LONGITUDE` y variantes; acepta grados decimales y DMS con N/S/E/W.
- Valores `X/Y`, Easting/Northing se conservan, pero no se interpretan como geográficos sin conocer el CRS.
- Persistencia de coordenadas originales, normalizadas, CRS, campos fuente, archivo, formato, estado y mensaje de validación en `.hmdcorr` y SQLite.
- Nuevo **Pozos > Administrar coordenadas…** para revisar, corregir y restaurar el valor original del LAS.
- Conflictos LAS/base de datos se muestran al usuario antes de reemplazar una ubicación.
- Distancias LAT/LON calculadas mediante Haversine; los CRS desconocidos no producen distancias ficticias.
- Esquema preparado para representar posteriormente surveys, ubicaciones de fondo, capas cartográficas, polígonos e infraestructura.

### Actualización v0.9.3

- Se reemplazó **Recuperar cimas para los pozos actuales** por **Mostrar tabla de cimas…**.
- La tabla permite filtrar por proyecto, pozo, UWI, cima, fuente o método y muestra el estado frente al proyecto abierto.
- Estados explícitos: ya visible, no está en el proyecto, valor diferente y otro pozo.
- La acción contextual cambia entre **Mostrar cima seleccionada en el proyecto** y **Actualizar cima del proyecto**.
- Una actualización compara MD actual, MD almacenada y diferencia antes de solicitar confirmación.
- Al incorporar una cima se conservan color, apariencia y metadatos; la operación puede deshacerse con `Ctrl+Z` y queda auditada.

### Actualización v0.9.2

- Apariencia configurable por cima: tamaño, normal/cursiva, negrita, color de texto y resaltado con color seleccionable.
- El estilo puede aplicarse a una cima, a todos los horizontes o restaurarse al valor predeterminado.
- Los estilos se guardan en el proyecto `.hmdcorr` y en las plantillas HMDLog.
- En el editor de cimas, doble clic abre la edición numérica directa de MD con opción de ajustar a la muestra LAS más cercana.
- La edición exacta respeta la protección del datum, puede deshacerse con `Ctrl+Z` y queda registrada en la base de datos.

### Actualización v0.9.1

- Nuevo repositorio geocientífico SQLite indexado por UWI y por identificador estable de proyecto.
- Las cimas importadas, manuales, ajustadas con cursor o transferidas por correlación se conservan en el `.hmdcorr` y se sincronizan con la base local.
- Historial auditable de creación, modificación, eliminación y deshacer, con profundidad anterior/nueva, método y fecha UTC.
- Menú **Correlación > Base de datos de cimas** para guardar, recuperar, revisar historial y exportar CSV.
- Esquema preparado para survey, registros e imágenes complementarias, datos de buzamiento y conjuntos de intervalos como cañoneos, RST y saturación de agua.

### Actualización v0.9.0

- El zoom areal ajusta la selección a la ventana principal: ocupa el 94 % del área útil, queda centrada y amplía simultáneamente el intervalo vertical y los tracks seleccionados. El cálculo se repite después del layout y al redimensionar para que VisPy no conserve la geometría anterior.
- Restablecer (`R`) libera los anchos fijos del enfoque, recupera todos los pozos, separaciones y rangos de cámara, y fuerza dos pases del solver de VisPy para reconstruir completamente la sección.
- Encabezado, retícula vertical y curva usan ahora una sola transformación X, equivalente al criterio de Matplotlib. El zoom areal mantiene el dominio horizontal completo `0..1`, por lo que no altera escalas lineales, logarítmicas ni invertidas.
- Dos líneas continuas persistentes en `x=0` y `x=1` representan los valores mínimo y máximo de cada curva. El encabezado incorpora ticks extremos y principales alineados con ellas. La rueda y el desplazamiento quedan bloqueados horizontalmente en `0..1` y sólo modifican profundidad.
- Las cámaras de encabezado y track reciben ahora un rectángulo directo, en vez de `set_range`, para eliminar el margen horizontal implícito de VisPy. El dominio `0..1` coincide físicamente con ambos bordes después de rueda, zoom, restauración y redimensionamiento.
- Cada línea de correlación se dibuja en el ViewBox del espacio interpozo correspondiente, evitando que el fondo de una separación proporcional amplia oculte el primer segmento. Una línea neutral reforzada diferencia tracks contiguos sin aumentar el borde exterior del pozo.
- El ancho mínimo configurado se conserva cuando cabe en pantalla y se reduce proporcionalmente cuando la suma de tracks y separaciones supera el viewport. Esto evita que VisPy colapse las últimas columnas al mostrar cuatro o más pozos o un panel lateral.
- Los grids anidados de pozo, track y separación usan margen interno cero y se resuelven en un único ciclo geométrico. La implementación evita atributos ViewBox no disponibles en versiones estables de VisPy y conserva la inicialización OpenGL.
- Un fallo temporal de inicialización GPU ya no guarda Matplotlib como preferencia permanente. La siguiente ejecución reintenta VisPy automáticamente y recupera la barra completa de iconos; la selección explícita del usuario continúa siendo persistente.
- La rueda desplaza el área ampliada; el botón central permite arrastrarla con sensibilidad normal, fina (`Shift`) o rápida (`Ctrl`).
- Al cambiar de zoom areal a zoom por intervalo se recupera automáticamente la navegación por profundidad.
- En **Apariencia > Preferencias de aplicación > Comportamiento al iniciar** se puede elegir entre reabrir el último proyecto guardado o comenzar con una ventana limpia.
- Si existen cambios sin guardar, el cierre solicita guardar, descartar o cancelar.

### Corrección v0.8.5

El instalador comprueba el código de salida de cada comando, repara entornos
incompletos y verifica `matplotlib`, `PySide6`, `numpy`, `pandas`, `lasio` y
`openpyxl` antes de informar que terminó. El lanzador también detecta una
instalación incompleta y solicita ejecutar nuevamente `Instalar.ps1`.

### Corrección v0.8.4

El desplazamiento posterior al zoom utiliza el `step` real de la rueda y el
desplazamiento en píxeles del botón intermedio. Ya no depende de transformar
repetidamente un eje que se está moviendo. Puede iniciarse sobre tracks o sobre
el espacio vertical entre pozos y avisa cuando alcanza un límite del registro.

### Ajuste v0.8.3

Después de aplicar zoom, la rueda desplaza el 5 % del intervalo visible;
`Shift + rueda` desplaza el 1 % y `Ctrl + rueda` el 15 %. El arrastre con botón
intermedio tiene sensibilidad reducida (45 %), con variantes fina y rápida.
Todos los movimientos conservan el ancho del intervalo, sincronizan los pozos
y respetan los límites disponibles de profundidad.

### Corrección v0.8.2

El zoom por intervalo (`I`) funciona mediante arrastre: presione sobre la
profundidad inicial, mantenga el botón izquierdo, arrastre hasta la profundidad
final y suelte. Una banda azul muestra el intervalo antes de aplicar el
acercamiento. Si el arrastre comienza sobre una cima y el editor está activo,
se edita la cima; fuera de ella se ejecuta el zoom.

### Corrección v0.8.1

Activar **Editar cimas con cursor** ya no restablece ni desactiva el zoom. Un
clic próximo a una cima inicia su edición; un clic fuera de la tolerancia sigue
operando el zoom por intervalo o el zoom areal que esté activo. Después de
guardar un ajuste también se restaura exactamente la vista navegada.

### Actualización v0.8.0

Active **Correlación > Editar cimas con cursor** (`E`) y arrastre una cima
verticalmente dentro del pozo. La posición anterior queda punteada y la nueva
posición se ajusta a la muestra MD más cercana. Al soltar se solicita
confirmación. Un doble clic permite escribir el MD; `Esc` cancela y `Ctrl+Z`
deshace. Por seguridad, la cima utilizada como datum permanece protegida salvo
que el usuario desactive explícitamente esa opción.

### Corrección v0.7.2

La limpieza de la curva fantasma es ahora idempotente: puede ejecutarse aunque
Matplotlib ya haya retirado los artistas durante el redibujado. El estado del
arrastre se elimina antes de actualizar la sección, permitiendo realizar varias
correlaciones consecutivas sin `NotImplementedError`.

### Actualización v0.7.1

La curva fantasma aparece desde el pozo de origen y permanece visible durante
todo el arrastre, incluso en el espacio entre pozos. Al entrar en el track
compatible de un pozo vecino se acopla a su ancho y calcula la profundidad MD
propuesta. Soltarla fuera de un destino válido no modifica ninguna cima.

### Actualización v0.7.0

Correlación asistida por arrastre: abra **Correlación > Correlación asistida
por arrastre…** (atajo `C`), elija el pozo y la cima de origen, la curva patrón
y el intervalo. Pulse el tramo en el pozo de origen, mantenga pulsado,
arrástrelo al mismo tipo de curva de otro pozo y suelte. Confirme la profundidad
propuesta. `Esc` cancela y `Ctrl+Z` deshace la última cima transferida.

### Actualización v0.6.1

Cada track puede recibir cualquiera de las curvas disponibles en los archivos
LAS. Una misma curva puede estar presente en varios tracks y se puede agregar o
quitar desde el panel contextual sin modificar los demás tracks.

### Actualización v0.6.2

Cada asignación track–curva puede presentarse normal o como imagen especular.
La inversión afecta únicamente al eje X del track elegido y nunca modifica los
datos LAS. El comando «Duplicar curva como imagen especular…» permite seleccionar
la curva de origen y el track de destino.

### Actualización v0.6.3

Las plantillas guardan ahora la presentación completa: curvas por track,
imagen especular, escalas globales, tracks ocultos, litología, topes, separación,
colores y grosor de correlación. La última plantilla guardada o cargada se aplica
automáticamente al reiniciar y también al cargar nuevos pozos LAS.

### Actualización v0.6.4

Los archivos LAS importados se copian a un repositorio local persistente,
indexado por UWI. Las cargas sucesivas se acumulan en el área de trabajo; un UWI
repetido actualiza el pozo sin duplicarlo. Esta función histórica está ahora
integrada en «Pozos > Administrador de pozos…».

### Actualización v0.6.5

La importación de cimas reconoce encabezados en español e inglés y normaliza
UWI/nombres para asociarlos con el repositorio. Cada cima se dibuja y etiqueta
dentro del track de su pozo. El administrador manual permite crear, actualizar
y eliminar cimas con validación contra el intervalo de profundidad LAS.

### Actualización v0.6.6

Se incorporan dos modalidades excluyentes en «Correlación > Navegación y zoom»:
zoom por intervalo mediante arrastre vertical y zoom areal mediante rectángulo.
La rueda o el arrastre con botón intermedio desplazan sincronizadamente todos
los pozos arriba/abajo. Las teclas I, A y R activan intervalo, área y restaurar.

### Corrección v0.6.7

El zoom por intervalo replica el Visualizador LAS de HMDLog: cursor sincronizado,
primer clic para TOP, segundo clic para BASE y ajuste a la muestra de profundidad
más próxima. El zoom areal muestra cursor X–Y y un recuadro dinámico durante el
arrastre.

### Corrección v0.6.8

El recuadro del zoom areal opera sobre toda la sección en coordenadas de figura.
Puede abarcar varios pozos, espacios, encabezados, cimas y líneas de correlación.
Al soltar, todo lo encerrado se transforma para ocupar el área completa de trabajo;
el contenido exterior queda fuera de la vista hasta restablecer con R.

### Actualización v0.6.9

El cursor de datos muestra una etiqueta MD mínima que cambia de lado dentro del
track para evitar cubrir la curva. La barra inferior informa pozo/UWI, MD real,
profundidad relativa al datum y valores con unidades de todas las curvas del
track. Se activa desde Navegación y zoom y se fija/libera con Ctrl+clic.

## Interfaz minimalista

La barra permanente de controles fue sustituida por los menús Archivo, Pozos,
Tracks y curvas, Correlación, Plantillas, Apariencia y Ayuda. La lista
de pozos y los editores de tracks, curvas y escalas son paneles contextuales
plegables, ocultos al iniciar.

La apariencia ofrece temas Claro técnico, Gris profesional, Oscuro y Alto
contraste, además de colores independientes para el área de trabajo, tracks y
cuadrícula. Los proyectos completos pueden guardarse y abrirse con la extensión
`.hmdcorr`.

Esta versión compacta y permite ocultar la lista de pozos, elimina UWI duplicados
y ajusta automáticamente la altura del encabezado a las curvas activas. El ancho
del panel se redistribuye al encender o apagar tracks y la gráfica recibe el
máximo espacio disponible.

Prototipo independiente para correlación estratigráfica y petrofísica entre pozos.
No modifica ni depende del proyecto principal HMDLog.

## Funciones incluidas

- Demostración inmediata con cinco pozos y curva GR.
- Track y escala de profundidad independientes para cada pozo.
- Relleno bilateral de curva alrededor de una línea central.
- Distancias calculadas entre pozos y mostradas en la cabecera.
- Sombreado de unidades correlacionadas y columna estratigráfica lateral.
- Plantillas visuales `.hmdtpl` compatibles con el visualizador LAS de HMDLog.
- Varios tracks y varias curvas por track para cada pozo.
- Escalas editables por curva, globalmente o solo para el pozo activo, centralizadas en
  **Tracks y curvas → Configurar tracks y retícula → Curvas y escalas**.
- Encendido y apagado reversible de curvas y tracks.
- Track litológico HMDLog por pozo cuando existe LITHOLOGY/LITHO/LITH/LITO.
- Separación entre pozos proporcional a coordenadas o uniforme.
- Líneas de cimas ajustadas a los bordes de los tracks visibles.
- Línea única por cima: horizontal dentro del pozo y oblicua solo entre pozos.
- Datum común Alfa/Beta/Gamma con la misma posición vertical en todos los pozos.
- El selector de datum ofrece únicamente topes presentes en todos los pozos.
- Las líneas alcanzan el borde derecho del último pozo con cualquier escala X.
- Carga y guardado compatible de plantillas `.hmdtpl`.
- Importación de varios archivos LAS.
- Importación de topes desde CSV o Excel.
- Conexión de topes equivalentes entre pozos.
- Visualización en profundidad MD.
- Alineación por cualquier tope disponible.
- Exportación del panel a SVG, PDF o PNG.

## Instalación en Windows

Abra PowerShell dentro de la carpeta y ejecute:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Instalar.ps1
```

Después abra:

```powershell
.\Iniciar_HMDLog_Correlation.bat
```

## Archivo de topes

Columnas mínimas:

```text
UWI,WELL_NAME,FORMATION,TOP
```

Debe existir `UWI` o `WELL_NAME` para relacionar cada registro con su pozo.

## Alcance de esta versión

La versión 0.2 valida el panel multiponzo: tracks independientes, GR, topes, datum estratigráfico y distancias.
La edición interactiva, TVD/TVDSS, distancias, rellenos SVG y guardado de proyecto
se incorporarán después de validar esta primera base.
